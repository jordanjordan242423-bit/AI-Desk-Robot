from fastapi import FastAPI, APIRouter
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import time
import psutil
import platform
import shutil
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    model_config = ConfigDict(extra="ignore")  # Ignore MongoDB's _id field
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Hello World"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    
    # Convert to dict and serialize datetime to ISO string for MongoDB
    doc = status_obj.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    
    _ = await db.status_checks.insert_one(doc)
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    # Exclude MongoDB's _id field from the query results
    status_checks = await db.status_checks.find({}, {"_id": 0}).to_list(1000)
    
    # Convert ISO string timestamps back to datetime objects
    for check in status_checks:
        if isinstance(check['timestamp'], str):
            check['timestamp'] = datetime.fromisoformat(check['timestamp'])
    
    return status_checks


# ── Live system metrics for the desk robot UI ─────────────────────────────
# The front-end polls this endpoint every few seconds. All values are safe to
# read on any Linux host (Raspberry Pi included) — the CPU temperature falls
# back to `None` where psutil.sensors_temperatures() is unavailable so the UI
# can gracefully render "—".

class SystemMetrics(BaseModel):
    cpu: float
    ram: float
    ram_used_gb: float
    ram_total_gb: float
    disk: float
    disk_used_gb: float
    disk_total_gb: float
    temperature_c: Optional[float] = None
    uptime_seconds: int
    load_avg_1: float
    load_avg_5: float
    load_avg_15: float
    platform: str
    hostname: str
    timestamp: str


def _read_temperature() -> Optional[float]:
    """Return CPU temp in °C if the platform exposes it, otherwise None."""
    try:
        sensors = psutil.sensors_temperatures() or {}
    except (AttributeError, OSError):
        return None
    # Prefer common Pi/Linux entries first
    for key in ("cpu_thermal", "coretemp", "k10temp", "acpitz", "soc_thermal"):
        readings = sensors.get(key)
        if readings:
            return round(readings[0].current, 1)
    # Fall back to the first sensor group we find
    for readings in sensors.values():
        if readings:
            return round(readings[0].current, 1)
    return None


@api_router.get("/system/metrics", response_model=SystemMetrics)
async def get_system_metrics():
    # psutil.cpu_percent needs a small interval to compute a sane average
    cpu = psutil.cpu_percent(interval=0.15)
    vm = psutil.virtual_memory()
    du = shutil.disk_usage('/')
    load = os.getloadavg() if hasattr(os, 'getloadavg') else (0.0, 0.0, 0.0)
    boot = psutil.boot_time()
    return SystemMetrics(
        cpu=round(cpu, 1),
        ram=round(vm.percent, 1),
        ram_used_gb=round(vm.used / (1024 ** 3), 2),
        ram_total_gb=round(vm.total / (1024 ** 3), 2),
        disk=round(du.used / du.total * 100, 1),
        disk_used_gb=round(du.used / (1024 ** 3), 1),
        disk_total_gb=round(du.total / (1024 ** 3), 1),
        temperature_c=_read_temperature(),
        uptime_seconds=int(time.time() - boot),
        load_avg_1=round(load[0], 2),
        load_avg_5=round(load[1], 2),
        load_avg_15=round(load[2], 2),
        platform=platform.platform(),
        hostname=platform.node(),
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


# ── Live network status ────────────────────────────────────────────────────
class NetworkInterface(BaseModel):
    name: str
    ip: Optional[str] = None
    mac: Optional[str] = None
    is_up: bool
    speed_mbps: int
    duplex: str
    bytes_sent: int
    bytes_recv: int


class NetworkStatus(BaseModel):
    online: bool
    hostname: str
    primary_interface: Optional[str] = None
    ssid: Optional[str] = None
    ip: Optional[str] = None
    signal_percent: Optional[int] = None
    interfaces: List[NetworkInterface]
    bytes_sent_total: int
    bytes_recv_total: int
    backend_reachable: bool
    timestamp: str


# Track last sample so we can report a rolling window of throughput.
_last_net_sample: dict = {"t": time.time(), "sent": 0, "recv": 0, "ssid": None, "signal": None}


def _read_wifi_status():
    """Best-effort SSID + signal read (Linux only). Never raises."""
    ssid = None
    signal = None
    try:
        import subprocess
        # Try nmcli first — most reliable on Pi OS / Ubuntu with NetworkManager
        r = subprocess.run(
            ['nmcli', '-t', '-f', 'active,ssid,signal', 'dev', 'wifi'],
            capture_output=True, text=True, timeout=1.2,
        )
        if r.returncode == 0:
            for line in r.stdout.strip().splitlines():
                parts = line.split(':')
                if len(parts) >= 3 and parts[0] == 'yes':
                    ssid = parts[1] or None
                    try:
                        signal = int(parts[2])
                    except ValueError:
                        signal = None
                    break
    except Exception:  # noqa: BLE001
        pass
    if ssid is None:
        try:
            import subprocess
            r = subprocess.run(['iwgetid', '-r'], capture_output=True, text=True, timeout=1.0)
            if r.returncode == 0:
                ssid = r.stdout.strip() or None
        except Exception:  # noqa: BLE001
            pass
    return ssid, signal


def _pick_primary_iface(addrs, stats):
    """Prefer the first non-loopback interface that is up with an IPv4 address."""
    for name, addr_list in addrs.items():
        if name.startswith(('lo', 'docker', 'veth', 'br-')):
            continue
        st = stats.get(name)
        if not st or not st.isup:
            continue
        for a in addr_list:
            if a.family.name == 'AF_INET' and not a.address.startswith('127.'):
                return name
    return None


@api_router.get("/system/network", response_model=NetworkStatus)
async def get_system_network():
    addrs = psutil.net_if_addrs()
    stats = psutil.net_if_stats()
    counters = psutil.net_io_counters(pernic=True)
    total = psutil.net_io_counters()

    interfaces: List[NetworkInterface] = []
    primary = _pick_primary_iface(addrs, stats)
    primary_ip = None
    primary_mac = None
    for name, addr_list in addrs.items():
        if name.startswith(('lo', 'docker', 'veth', 'br-')):
            continue
        ip = None
        mac = None
        for a in addr_list:
            if a.family.name == 'AF_INET':
                ip = a.address
            elif a.family.name == 'AF_PACKET' or (hasattr(a.family, 'name') and 'LINK' in a.family.name):
                mac = a.address
        st = stats.get(name)
        c = counters.get(name)
        interfaces.append(NetworkInterface(
            name=name,
            ip=ip,
            mac=mac,
            is_up=bool(st and st.isup),
            speed_mbps=int(st.speed) if st else 0,
            duplex=str(st.duplex) if st else 'unknown',
            bytes_sent=int(c.bytes_sent) if c else 0,
            bytes_recv=int(c.bytes_recv) if c else 0,
        ))
        if name == primary:
            primary_ip = ip
            primary_mac = mac

    ssid, signal = _read_wifi_status()

    # Backend reachability = we are answering, so obviously reachable.
    # Also check that DNS / outside is reachable by looking at the process
    # net counters climbing across samples (crude but robust).
    now = time.time()
    delta_t = max(0.001, now - _last_net_sample['t'])
    _last_net_sample['t'] = now
    _last_net_sample['sent'] = total.bytes_sent
    _last_net_sample['recv'] = total.bytes_recv

    return NetworkStatus(
        online=any(i.is_up and i.ip and not i.ip.startswith('127.') for i in interfaces),
        hostname=platform.node(),
        primary_interface=primary,
        ssid=ssid,
        ip=primary_ip,
        signal_percent=signal,
        interfaces=interfaces,
        bytes_sent_total=int(total.bytes_sent),
        bytes_recv_total=int(total.bytes_recv),
        backend_reachable=True,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()