const v = (name) => `rgb(var(--${name}) / <alpha-value>)`

export default {content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        ink: {
          950: v('ink-950'),
          900: v('ink-900'),
          850: v('ink-850'),
          800: v('ink-800'),
          750: v('ink-750'),
          700: v('ink-700'),
          600: v('ink-600'),
        },
        mist: {
          50: '#f6f7f8',
          100: '#e7eaed',
          300: '#b7bec6',
          400: '#8f979f',
          500: '#6d747c',
          600: '#51575e',
        },
        accent: {
          DEFAULT: v('accent'),
          soft: v('accent-soft'),
          deep: v('accent-deep'),
          dim: v('accent-dim'),
        },
        warn: '#d9736a',
        ok: '#5ddba0',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      letterSpacing: {
        label: '0.16em',
      },
      boxShadow: {
        bezel:
          '0 60px 120px -40px rgba(0,0,0,0.9), 0 2px 0 0 rgba(255,255,255,0.05) inset, 0 -2px 0 0 rgba(0,0,0,0.6) inset',
        raised:
          '0 1px 0 0 rgba(255,255,255,0.045) inset, 0 14px 30px -22px rgba(0,0,0,0.95)',
        lift: '0 1px 0 0 rgba(255,255,255,0.07) inset, 0 24px 48px -28px rgba(0,0,0,1)',
      },
    },
  },
}
