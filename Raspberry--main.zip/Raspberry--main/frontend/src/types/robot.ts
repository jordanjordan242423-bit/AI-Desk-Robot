import type { Tone } from './settings';

export type RobotMood =
'idle' |
'searching' |
'thinking' |
'writing' |
'speaking' |
'media' |
'curious' |
'rendering' |
'success' |
'error' |
'waiting' |
'upload' |
'sleeping';

export type StateId =
'bereit' |
'recherche' |
'denken' |
'fakten' |
'schreiben' |
'sprache' |
'medien' |
'video' |
'qualitaet' |
'upload' |
'fertig' |
'fehler';

export type StateTone = 'neutral' | 'accent' | 'warn';

export interface RobotStateDef {
  id: StateId;
  /** Short technical status, shown in caps */
  label: string;
  /** The robot speaking to its owner, first person, German — one per tone */
  lines: Record<Tone, string>;
  /** Two or three words for the fullscreen robot stage */
  short: Record<Tone, string>;
  mood: RobotMood;
  tone: StateTone;
  /** How long this stage runs in the autonomous loop (ms) */
  duration: number;
}

export interface Expression {
  eyeW: number;
  eyeH: number;
  dy: number;
  /** Biases where the eyes wander */
  gaze: 'still' | 'scan' | 'up' | 'down';
  mouth: string;
  /** Head tilt in degrees, for curious or concerned looks */
  tilt?: number;
  arcEyes?: boolean;
  talk?: boolean;
  brow?: boolean;
}

export type ScreenId =
'home' |
'videos' |
'statistik' |
'themen' |
'system' |
'wetter' |
'prozess' |
'netzwerk' |
'zeit' |
'settings';