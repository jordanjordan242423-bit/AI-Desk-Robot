export type AccentId = 'cyan' | 'blue' | 'purple' | 'green' | 'orange' | 'white' | 'red';
export type BackgroundId = 'dark' | 'black' | 'charcoal';
export type UiStyleId = 'standard' | 'glass' | 'bubble' | 'solid' | 'minimal';
export type Density = 'kompakt' | 'normal' | 'luftig';
export type Intensity = 'ruhig' | 'normal' | 'lebhaft';
export type EyeShape = 'rund' | 'pille' | 'balken' | 'kristall';
export type MouthStyle = 'weich' | 'linie' | 'punkt' | 'keine';
export type BodyColorId = 'perlweiss' | 'sand' | 'graphit' | 'mint' | 'schiefer';
export type ArmStyle = 'rund' | 'flach' | 'gelenk';
export type AntennaStyle = 'keine' | 'einzel' | 'doppel' | 'bogen';
export type PersonalityId = 'friendly' | 'curious' | 'calm' | 'playful' | 'energetic' | 'focused';
export type IdleBehavior = 'still' | 'natuerlich' | 'neugierig';
export type Tone = 'sachlich' | 'freundlich' | 'verspielt';

/* ── Accent palette ─────────────────────────────────────── */

export interface AccentDef {
  id: AccentId;
  label: string;
  rgb: string;
  softRgb: string;
  deepRgb: string;
  dimRgb: string;
  hex: string;
}

export const accents: Record<AccentId, AccentDef> = {
  cyan: { id: 'cyan', label: 'Cyan', rgb: '79 209 224', softRgb: '126 224 234', deepRgb: '42 159 176', dimRgb: '29 93 104', hex: '#4fd1e0' },
  blue: { id: 'blue', label: 'Blau', rgb: '96 158 255', softRgb: '146 189 255', deepRgb: '48 110 214', dimRgb: '27 58 104', hex: '#609eff' },
  purple: { id: 'purple', label: 'Violett', rgb: '167 139 250', softRgb: '196 177 253', deepRgb: '124 92 240', dimRgb: '59 44 102', hex: '#a78bfa' },
  green: { id: 'green', label: 'Grün', rgb: '93 219 160', softRgb: '142 233 192', deepRgb: '47 174 120', dimRgb: '29 82 64', hex: '#5ddba0' },
  orange: { id: 'orange', label: 'Orange', rgb: '255 168 104', softRgb: '255 197 152', deepRgb: '224 123 52', dimRgb: '107 60 28', hex: '#ffa868' },
  white: { id: 'white', label: 'Weiß', rgb: '226 232 238', softRgb: '243 247 250', deepRgb: '170 180 189', dimRgb: '74 80 87', hex: '#e2e8ee' },
  red: { id: 'red', label: 'Rot', rgb: '232 116 108', softRgb: '243 158 151', deepRgb: '191 74 66', dimRgb: '92 41 37', hex: '#e8746c' }
};

/* ── Background scales ──────────────────────────────────── */

export interface BackgroundDef {
  id: BackgroundId;
  label: string;
  caption: string;
  ink: Record<'950' | '900' | '850' | '800' | '750' | '700' | '600', string>;
}

export const backgrounds: Record<BackgroundId, BackgroundDef> = {
  dark: {
    id: 'dark',
    label: 'Dunkel',
    caption: 'Warmes Anthrazit',
    ink: { '950': '7 8 9', '900': '11 12 15', '850': '15 17 20', '800': '21 24 29', '750': '27 31 37', '700': '35 40 47', '600': '46 52 60' }
  },
  black: {
    id: 'black',
    label: 'Tiefschwarz',
    caption: 'Maximaler Kontrast',
    ink: { '950': '0 0 0', '900': '4 4 5', '850': '8 9 10', '800': '13 14 16', '750': '18 19 21', '700': '25 27 30', '600': '34 37 42' }
  },
  charcoal: {
    id: 'charcoal',
    label: 'Charcoal',
    caption: 'Weicher, heller',
    ink: { '950': '17 19 22', '900': '21 24 28', '850': '26 30 35', '800': '32 37 43', '750': '39 45 53', '700': '48 55 64', '600': '60 68 78' }
  }
};

/* ── UI styles ──────────────────────────────────────────── */

export const uiStyles: {id: UiStyleId;label: string;caption: string;}[] = [
{ id: 'standard', label: 'Standard', caption: 'Ruhige, flache Flächen' },
{ id: 'glass', label: 'Glas', caption: 'Transparent mit Tiefenunschärfe' },
{ id: 'bubble', label: 'Bubble', caption: 'Weich, rund, greifbar' },
{ id: 'solid', label: 'Solid', caption: 'Volle Flächen, klarer Kontrast' },
{ id: 'minimal', label: 'Minimal', caption: 'Nur Typografie und Linien' }];


/* ── Robot body finishes ────────────────────────────────── */

export interface BodyColorDef {
  id: BodyColorId;
  label: string;
  /** light → mid → deep, used for the shell gradients */
  light: string;
  mid: string;
  deep: string;
  collar: string;
}

export const bodyColors: Record<BodyColorId, BodyColorDef> = {
  perlweiss: { id: 'perlweiss', label: 'Perlweiß', light: '#ffffff', mid: '#eeece6', deep: '#bcb9b1', collar: '#8fe3d8' },
  sand: { id: 'sand', label: 'Sand', light: '#fdf7ec', mid: '#efe3cd', deep: '#c0ae92', collar: '#e8c79a' },
  graphit: { id: 'graphit', label: 'Graphit', light: '#7e848c', mid: '#585f68', deep: '#32373e', collar: '#7fd6cc' },
  mint: { id: 'mint', label: 'Mint', light: '#f3fbf8', mid: '#dcefe9', deep: '#a6c4bc', collar: '#7fd6cc' },
  schiefer: { id: 'schiefer', label: 'Schiefer', light: '#c5ccd4', mid: '#9aa3ad', deep: '#5f6874', collar: '#8fb6e3' }
};

/* ── Personalities: these genuinely change behaviour ────── */

export interface PersonalityDef {
  id: PersonalityId;
  label: string;
  caption: string;
  tone: Tone;
  /** multiplies every animation duration target */
  speed: number;
  /** multiplies movement amplitude */
  amplitude: number;
  /** multiplies the pause between eye movements — lower means more looking around */
  gazeGap: number;
  /** multiplies the pause between expressive idle moments */
  flourishGap: number;
  /** biases the resting mouth towards a smile */
  smile: number;
}

export const personalities: Record<PersonalityId, PersonalityDef> = {
  friendly: { id: 'friendly', label: 'Freundlich', caption: 'Lächelt oft, sucht Blickkontakt', tone: 'freundlich', speed: 1, amplitude: 1, gazeGap: 0.9, flourishGap: 0.85, smile: 1 },
  curious: { id: 'curious', label: 'Neugierig', caption: 'Schaut sich viel um', tone: 'freundlich', speed: 1.05, amplitude: 1.15, gazeGap: 0.5, flourishGap: 0.6, smile: 0.4 },
  calm: { id: 'calm', label: 'Ruhig', caption: 'Langsame, weiche Bewegungen', tone: 'sachlich', speed: 0.62, amplitude: 0.65, gazeGap: 1.7, flourishGap: 1.6, smile: 0.3 },
  playful: { id: 'playful', label: 'Verspielt', caption: 'Viele kleine Einfälle', tone: 'verspielt', speed: 1.2, amplitude: 1.3, gazeGap: 0.6, flourishGap: 0.45, smile: 0.9 },
  energetic: { id: 'energetic', label: 'Energisch', caption: 'Schnell und wach', tone: 'verspielt', speed: 1.45, amplitude: 1.35, gazeGap: 0.55, flourishGap: 0.7, smile: 0.6 },
  focused: { id: 'focused', label: 'Fokussiert', caption: 'Konzentriert, wenig Ablenkung', tone: 'sachlich', speed: 0.85, amplitude: 0.5, gazeGap: 2.2, flourishGap: 2.6, smile: 0 }
};

export const intensityFactor: Record<Intensity, number> = { ruhig: 0.45, normal: 1, lebhaft: 1.6 };
export const densityScale: Record<Density, number> = { kompakt: 0.86, normal: 1, luftig: 1.12 };

/* ── The settings object itself ─────────────────────────── */

export interface Settings {
  // General
  language: 'Deutsch' | 'English';
  timeFormat: '24 h' | '12 h';
  dateFormat: 'TT.MM.JJJJ' | 'JJJJ-MM-TT';
  startup: 'home' | 'robot' | 'prozess';
  sound: boolean;
  volume: number;
  notifications: boolean;

  // Display
  brightness: number;
  autoBrightness: boolean;
  screenTimeout: '1 Min' | '5 Min' | '15 Min' | 'Nie';
  sleepMode: boolean;
  uiScale: number;
  animation: Intensity;

  // Appearance
  accent: AccentId;
  background: BackgroundId;
  uiStyle: UiStyleId;
  transparency: number;
  blur: number;
  radius: number;
  shadow: number;
  glow: number;
  density: Density;

  // Robot
  robotSize: number;
  eyeColor: AccentId | 'auto';
  eyeSize: number;
  eyeSpacing: number;
  eyeShape: EyeShape;
  eyeBrightness: number;
  faceBrightness: number;
  mouthStyle: MouthStyle;
  mouthSize: number;
  bodyColor: BodyColorId;
  bodyBrightness: number;
  armStyle: ArmStyle;
  antennaStyle: AntennaStyle;
  antennaMotion: boolean;
  robotGlow: number;
  animationSpeed: number;
  idle: IdleBehavior;
  personality: PersonalityId;
  greeting: 'Hey 👋' | 'Moin' | 'Ich bin bereit.' | 'Stumm';
  sleepBehavior: 'Augen schließen' | 'Nur dimmen' | 'Display aus';
  voice: 'Nova' | 'Kai' | 'Mara';

  // Network
  wifi: boolean;
  autoConnect: boolean;
  hotspot: boolean;

  // AI
  model: 'llama3' | 'mistral' | 'qwen2';
  creativity: number;
  research: 'breit' | 'fokussiert' | 'aktuell';
  factCheck: 'streng' | 'normal' | 'aus';
  autoTopic: boolean;
  aiLanguage: 'de-DE' | 'en-US';
  responseStyle: 'kurz' | 'normal' | 'ausführlich';

  // Content
  perDay: number;
  publishTimes: string[];
  videoLength: '30 s' | '45 s' | '60 s';
  categories: string[];
  autoPublish: boolean;
  manualFallback: boolean;
  subtitles: boolean;
  subtitleSize: 'klein' | 'normal' | 'groß';

  // Location (Wetter, and later any location-aware feature)
  weatherPlace: string;
  weatherLat: number;
  weatherLon: number;
  weatherUseBrowserLocation: boolean;

  /** Which weather details are shown on the Home screen weather tile.
      Each entry is a key like 'humidity', 'wind', 'uv', 'sunset'. */
  homeWeatherPins: string[];
}

export const defaultSettings: Settings = {
  language: 'Deutsch',
  timeFormat: '24 h',
  dateFormat: 'TT.MM.JJJJ',
  startup: 'home',
  sound: true,
  volume: 55,
  notifications: true,

  brightness: 88,
  autoBrightness: false,
  screenTimeout: '5 Min',
  sleepMode: true,
  uiScale: 100,
  animation: 'normal',

  accent: 'cyan',
  background: 'dark',
  uiStyle: 'standard',
  transparency: 26,
  blur: 14,
  radius: 22,
  shadow: 55,
  glow: 34,
  density: 'normal',

  robotSize: 100,
  eyeColor: 'auto',
  eyeSize: 100,
  eyeSpacing: 100,
  eyeShape: 'rund',
  eyeBrightness: 88,
  faceBrightness: 26,
  mouthStyle: 'weich',
  mouthSize: 100,
  bodyColor: 'perlweiss',
  bodyBrightness: 100,
  armStyle: 'gelenk',
  antennaStyle: 'einzel',
  antennaMotion: true,
  robotGlow: 60,
  animationSpeed: 100,
  idle: 'natuerlich',
  personality: 'friendly',
  greeting: 'Hey 👋',
  sleepBehavior: 'Augen schließen',
  voice: 'Nova',

  wifi: true,
  autoConnect: true,
  hotspot: false,

  model: 'llama3',
  creativity: 62,
  research: 'breit',
  factCheck: 'streng',
  autoTopic: true,
  aiLanguage: 'de-DE',
  responseStyle: 'normal',

  perDay: 3,
  publishTimes: ['11:00', '20:00'],
  videoLength: '45 s',
  categories: ['Wissenschaft', 'Technik & KI', 'Natur & Tiere', 'Raumfahrt'],
  autoPublish: true,
  manualFallback: true,
  subtitles: true,
  subtitleSize: 'normal',

  weatherPlace: 'Sassenburg',
  weatherLat: 52.5,
  weatherLon: 10.6,
  weatherUseBrowserLocation: false,

  homeWeatherPins: ['rain', 'wind']
};

export const STORAGE_KEY = 'eilik.settings.v2';