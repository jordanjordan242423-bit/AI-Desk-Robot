import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { DeviceShell } from './components/DeviceShell';
import { StatusBar } from './components/StatusBar';
import { NavBar } from './components/NavBar';
import { RobotStage } from './components/RobotStage';
import { Home } from './pages/Home';
import { Videos } from './pages/Videos';
import { Statistik } from './pages/Statistik';
import { Themen } from './pages/Themen';
import { System } from './pages/System';
import { Wetter } from './pages/Wetter';
import { Prozess } from './pages/Prozess';
import { Netzwerk } from './pages/Netzwerk';
import { Zeit } from './pages/Zeit';
import { Settings } from './pages/Settings';
import { SettingsProvider, useSettings } from './contexts/SettingsContext';
import { AttentionProvider, useAttention } from './contexts/AttentionContext';
import { usePipeline } from './hooks/usePipeline';
import type { IdlePhase } from './hooks/useRobotLife';
import type { ScreenId, StateId } from './types/robot';

type RobotStateControl =
'auto' |
'bereit' |
'recherche' |
'schreiben' |
'sprache' |
'medien' |
'video' |
'upload' |
'fertig' |
'fehler';

interface AppProps {
  /** Hold the robot in one state instead of letting it run its own loop */
  robotState?: RobotStateControl;
  /** Show the physical enclosure around the 7" panel */
  deviceFrame?: boolean;
}

const EASE = [0.23, 1, 0.32, 1] as const;
const TIMEOUTS: Record<string, number> = { '1 Min': 40, '5 Min': 55, '15 Min': 70, Nie: Infinity };

export function App({ robotState = 'auto', deviceFrame = true }: AppProps) {
  return (
    <SettingsProvider>
      <AttentionProvider>
        <Device robotState={robotState} deviceFrame={deviceFrame} />
      </AttentionProvider>
    </SettingsProvider>);

}

function Device({
  robotState,
  deviceFrame



}: {robotState: RobotStateControl;deviceFrame: boolean;}) {
  const { settings } = useSettings();
  const { idleSec, react } = useAttention();
  const override = robotState === 'auto' ? undefined : robotState as StateId;
  const { state, progress, retry } = usePipeline(override);

  const [stack, setStack] = useState<ScreenId[]>([settings.startup === 'prozess' ? 'prozess' : 'home']);
  const [dir, setDir] = useState(1);
  const [robotOpen, setRobotOpen] = useState(settings.startup === 'robot');
  const screen = stack[stack.length - 1];

  const push = useCallback((id: ScreenId) => {
    setDir(1);
    setStack((s) => s[s.length - 1] === id ? s : [...s, id]);
  }, []);
  const back = useCallback(() => {
    setDir(-1);
    setStack((s) => s.length > 1 ? s.slice(0, -1) : s);
  }, []);
  const tab = useCallback((id: ScreenId) => {
    setDir(1);
    setStack([id]);
  }, []);

  /* ── Idle, drowsy, asleep ─────────────────────────────── */
  const working = state !== 'bereit' && state !== 'fertig' && state !== 'fehler';
  const sleepAt = TIMEOUTS[settings.screenTimeout] ?? 55;
  let phase: IdlePhase = 'awake';
  if (settings.sleepMode) {
    if (idleSec >= sleepAt && !working) phase = 'asleep';else
    if (idleSec >= 30 && !working) phase = 'drowsy';else
    if (idleSec >= 14) phase = 'calm';
  }

  // The robot notices when you come back
  const prev = useRef<IdlePhase>(phase);
  useEffect(() => {
    if ((prev.current === 'asleep' || prev.current === 'drowsy') && phase === 'awake') {
      react('surprise');
    }
    prev.current = phase;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const dimmed =
  phase === 'asleep' && settings.sleepBehavior !== 'Augen schließen' ?
  settings.sleepBehavior === 'Display aus' ?
  0.78 :
  0.42 :
  0;

  const enter = dir > 0 ? { y: 14, scale: 0.99 } : { y: -10, scale: 1.004 };
  const leave = dir > 0 ? { y: -10, scale: 1.004 } : { y: 14, scale: 0.99 };
  const deep = stack.length > 1;

  return (
    <DeviceShell framed={deviceFrame}>
      <div className="relative flex h-full w-full flex-col text-mist-100">
        <StatusBar
          onOpenSettings={() => screen === 'settings' ? back() : push('settings')}
          onOpenClock={() => push('zeit')}
          onOpenNetwork={() => push('netzwerk')}
          settingsActive={screen === 'settings'} />
        

        <AnimatePresence mode="wait" initial={false}>
          <motion.main
            key={screen}
            initial={{ opacity: 0, ...enter }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, ...leave }}
            transition={{ duration: 0.24, ease: EASE }}
            className="flex min-h-0 flex-1 flex-col overflow-hidden">
            
            {screen === 'home' &&
            <Home
              state={state}
              progress={progress}
              phase={phase}
              onRetry={retry}
              onOpenRobot={() => setRobotOpen(true)}
              onOpen={push} />

            }
            {screen === 'videos' && <Videos onBack={deep ? back : undefined} />}
            {screen === 'statistik' && <Statistik onBack={deep ? back : undefined} />}
            {screen === 'themen' && <Themen onBack={deep ? back : undefined} />}
            {screen === 'system' &&
            <System onBack={deep ? back : undefined} onOpenNetwork={() => push('netzwerk')} />
            }
            {screen === 'wetter' && <Wetter onBack={back} />}
            {screen === 'prozess' && <Prozess state={state} progress={progress} onBack={back} />}
            {screen === 'netzwerk' && <Netzwerk onBack={back} />}
            {screen === 'zeit' && <Zeit onBack={back} />}
            {screen === 'settings' &&
            <Settings onBack={back} onOpenNetwork={() => push('netzwerk')} />
            }
          </motion.main>
        </AnimatePresence>

        <NavBar
          active={screen}
          onChange={(id) => {
            tab(id);
            setRobotOpen(false);
          }} />
        

        <AnimatePresence>
          {robotOpen &&
          <RobotStage
            state={state}
            progress={progress}
            phase={phase}
            onClose={() => setRobotOpen(false)} />

          }
        </AnimatePresence>

        {/* Display sleep, as configured — any touch wakes it */}
        <motion.div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-40 bg-black"
          animate={{ opacity: dimmed }}
          transition={{ duration: 1.1, ease: EASE }} />
        
      </div>
    </DeviceShell>);

}