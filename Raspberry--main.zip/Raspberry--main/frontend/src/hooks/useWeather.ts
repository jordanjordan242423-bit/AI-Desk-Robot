import { useEffect, useState } from 'react';

/**
 * Live weather via Open-Meteo — no API key required. Returns the same shape as
 * the mock in data/content.ts so pages don't need to change. Falls back to
 * `null` while loading and if the network fails; callers should keep the mock
 * as a safe default in that case.
 */

export type Sky = 'sun' | 'cloud' | 'rain' | 'night';

export interface WeatherHour {
  time: string;
  temp: string;
  rain: string;
  sky: Sky;
}

export interface WeatherDay {
  day: string;
  text: string;
  high: number;
  low: number;
  rain: string;
  sky: Sky;
}

export interface LiveWeather {
  place: string;
  temp: string;
  feels: string;
  text: string;
  rain: string;
  wind: string;
  humidity: string;
  pressure: string;
  uv: string;
  sunrise: string;
  sunset: string;
  high: string;
  low: string;
  hours: WeatherHour[];
  days: WeatherDay[];
}

/** Default: Sassenburg, Niedersachsen. Overridable by the caller. */
const DEFAULTS = { lat: 52.5, lon: 10.6, place: 'Sassenburg' };
const STORAGE_KEY = 'eilik.weather.v1';
const REFRESH_MS = 20 * 60 * 1000; // 20 minutes

const WMO_TEXT: Record<number, { text: string; sky: Sky }> = {
  0: { text: 'Sonnig', sky: 'sun' },
  1: { text: 'Überwiegend sonnig', sky: 'sun' },
  2: { text: 'Leicht bewölkt', sky: 'cloud' },
  3: { text: 'Bewölkt', sky: 'cloud' },
  45: { text: 'Nebel', sky: 'cloud' },
  48: { text: 'Nebel', sky: 'cloud' },
  51: { text: 'Leichter Nieselregen', sky: 'rain' },
  53: { text: 'Nieselregen', sky: 'rain' },
  55: { text: 'Starker Niesel', sky: 'rain' },
  61: { text: 'Leichter Regen', sky: 'rain' },
  63: { text: 'Regen', sky: 'rain' },
  65: { text: 'Starker Regen', sky: 'rain' },
  71: { text: 'Leichter Schnee', sky: 'rain' },
  73: { text: 'Schnee', sky: 'rain' },
  75: { text: 'Starker Schnee', sky: 'rain' },
  80: { text: 'Regenschauer', sky: 'rain' },
  81: { text: 'Regenschauer', sky: 'rain' },
  82: { text: 'Kräftige Schauer', sky: 'rain' },
  95: { text: 'Gewitter', sky: 'rain' },
  96: { text: 'Gewitter mit Hagel', sky: 'rain' },
  99: { text: 'Gewitter mit Hagel', sky: 'rain' }
};

const describeCode = (code: number, isDay: boolean): { text: string; sky: Sky } => {
  const entry = WMO_TEXT[code] ?? { text: 'Wechselhaft', sky: 'cloud' as Sky };
  if (!isDay && entry.sky === 'cloud') return { ...entry, sky: 'night' };
  return entry;
};

const DAY_LABELS = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
const asTime = (iso: string) => {
  const d = new Date(iso);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};
const asHour = (iso: string) => `${pad(new Date(iso).getHours())}`;
const uvLabel = (v: number) =>
  v < 3 ? 'Niedrig' : v < 6 ? 'Mittel' : v < 8 ? 'Hoch' : v < 11 ? 'Sehr hoch' : 'Extrem';

async function reverseGeocode(lat: number, lon: number): Promise<string | null> {
  try {
    const url = `https://geocoding-api.open-meteo.com/v1/reverse?latitude=${lat}&longitude=${lon}&language=de&count=1`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const j = await res.json();
    return j?.results?.[0]?.name ?? null;
  } catch {
    return null;
  }
}

async function fetchOpenMeteo(lat: number, lon: number, place: string): Promise<LiveWeather> {
  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,pressure_msl,is_day` +
    `&hourly=temperature_2m,weather_code,precipitation_probability` +
    `&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset,uv_index_max` +
    `&timezone=auto&forecast_days=6`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`weather ${res.status}`);
  const j = await res.json();

  const cur = j.current;
  const nowIdx = j.hourly.time.findIndex((t: string) => new Date(t).getTime() > Date.now() - 30 * 60 * 1000);
  const startIdx = Math.max(0, nowIdx);
  const hours: WeatherHour[] = [];
  for (let i = startIdx; i < startIdx + 8 && i < j.hourly.time.length; i++) {
    const desc = describeCode(j.hourly.weather_code[i], cur.is_day === 1);
    hours.push({
      time: asHour(j.hourly.time[i]),
      temp: `${Math.round(j.hourly.temperature_2m[i])}°`,
      rain: `${j.hourly.precipitation_probability[i] ?? 0} %`,
      sky: desc.sky
    });
  }

  const days: WeatherDay[] = j.daily.time.map((t: string, i: number) => {
    const d = new Date(t);
    const desc = describeCode(j.daily.weather_code[i], true);
    return {
      day: DAY_LABELS[d.getDay()],
      text: desc.text,
      high: Math.round(j.daily.temperature_2m_max[i]),
      low: Math.round(j.daily.temperature_2m_min[i]),
      rain: `${j.daily.precipitation_probability_max[i] ?? 0} %`,
      sky: desc.sky
    };
  });

  const nowDesc = describeCode(cur.weather_code, cur.is_day === 1);

  return {
    place,
    temp: `${Math.round(cur.temperature_2m)}°`,
    feels: `${Math.round(cur.apparent_temperature)}°`,
    text: nowDesc.text,
    rain: `${Math.round(cur.precipitation || 0)} %`,
    wind: `${Math.round(cur.wind_speed_10m)} km/h`,
    humidity: `${Math.round(cur.relative_humidity_2m)} %`,
    pressure: `${Math.round(cur.pressure_msl)} hPa`,
    uv: uvLabel(Math.round(j.daily.uv_index_max?.[0] ?? 0)),
    sunrise: asTime(j.daily.sunrise[0]),
    sunset: asTime(j.daily.sunset[0]),
    high: `${Math.round(j.daily.temperature_2m_max[0])}°`,
    low: `${Math.round(j.daily.temperature_2m_min[0])}°`,
    hours,
    days
  };
}

interface CachePayload {
  when: number;
  data: LiveWeather;
}

function readCache(): CachePayload | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CachePayload;
  } catch {
    return null;
  }
}

function writeCache(data: LiveWeather) {
  try {
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ when: Date.now(), data } satisfies CachePayload)
    );
  } catch {
    /* storage full or unavailable — silently ignore */
  }
}

export interface UseWeatherOptions {
  lat?: number;
  lon?: number;
  place?: string;
  /** If true, try navigator.geolocation once on first mount */
  useBrowserLocation?: boolean;
}

/** React hook: returns the newest weather, or null while first-loading. */
export function useWeather(opts: UseWeatherOptions = {}): LiveWeather | null {
  const initialCache = readCache();
  const [data, setData] = useState<LiveWeather | null>(initialCache?.data ?? null);

  useEffect(() => {
    let cancelled = false;
    const cache = readCache();
    if (cache && Date.now() - cache.when < REFRESH_MS) {
      setData(cache.data);
      return () => {
        cancelled = true;
      };
    }

    const doFetch = async (lat: number, lon: number, place: string) => {
      try {
        const w = await fetchOpenMeteo(lat, lon, place);
        if (cancelled) return;
        setData(w);
        writeCache(w);
      } catch {
        // Keep the previous cache/mock — never surface an error to the UI
      }
    };

    const startWith = (lat: number, lon: number, place: string) => {
      doFetch(lat, lon, place);
      const id = window.setInterval(() => doFetch(lat, lon, place), REFRESH_MS);
      return id;
    };

    let intervalId = 0;
    if (opts.useBrowserLocation && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          if (cancelled) return;
          const name = (await reverseGeocode(pos.coords.latitude, pos.coords.longitude)) ?? 'Zuhause';
          if (cancelled) return;
          intervalId = startWith(pos.coords.latitude, pos.coords.longitude, name);
        },
        () => {
          if (cancelled) return;
          intervalId = startWith(
            opts.lat ?? DEFAULTS.lat,
            opts.lon ?? DEFAULTS.lon,
            opts.place ?? DEFAULTS.place
          );
        },
        { timeout: 4000, maximumAge: 15 * 60 * 1000 }
      );
    } else {
      intervalId = startWith(
        opts.lat ?? DEFAULTS.lat,
        opts.lon ?? DEFAULTS.lon,
        opts.place ?? DEFAULTS.place
      );
    }

    return () => {
      cancelled = true;
      if (intervalId) window.clearInterval(intervalId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [opts.lat, opts.lon, opts.place, opts.useBrowserLocation]);

  return data;
}
