import { useEffect, useState } from 'react';

export interface NetworkInterface {
  name: string;
  ip: string | null;
  mac: string | null;
  is_up: boolean;
  speed_mbps: number;
  duplex: string;
  bytes_sent: number;
  bytes_recv: number;
}

export interface NetworkStatus {
  online: boolean;
  hostname: string;
  primary_interface: string | null;
  ssid: string | null;
  ip: string | null;
  signal_percent: number | null;
  interfaces: NetworkInterface[];
  bytes_sent_total: number;
  bytes_recv_total: number;
  backend_reachable: boolean;
  timestamp: string;
}

const BACKEND_URL =
  (typeof import.meta !== 'undefined' &&
    ((import.meta as unknown as { env: Record<string, string> }).env?.VITE_BACKEND_URL ||
      (import.meta as unknown as { env: Record<string, string> }).env?.REACT_APP_BACKEND_URL)) ||
  '';

interface UseNetworkStatus extends NetworkStatus {
  /** Bytes per second sent since the previous sample */
  download_kbps: number;
  upload_kbps: number;
}

export function useNetworkStatus(refreshMs = 4000): UseNetworkStatus | null {
  const [data, setData] = useState<UseNetworkStatus | null>(null);

  useEffect(() => {
    let cancelled = false;
    let prev: { t: number; sent: number; recv: number } | null = null;

    const fetchOnce = async () => {
      try {
        const res = await fetch(`${BACKEND_URL}/api/system/network`, { cache: 'no-store' });
        if (!res.ok) throw new Error('bad');
        const j = (await res.json()) as NetworkStatus;
        const now = Date.now();
        let up = 0;
        let down = 0;
        if (prev) {
          const dt = Math.max(0.001, (now - prev.t) / 1000);
          up = Math.max(0, ((j.bytes_sent_total - prev.sent) / dt) * 8) / 1000;
          down = Math.max(0, ((j.bytes_recv_total - prev.recv) / dt) * 8) / 1000;
        }
        prev = { t: now, sent: j.bytes_sent_total, recv: j.bytes_recv_total };
        if (cancelled) return;
        setData({ ...j, download_kbps: down, upload_kbps: up });
      } catch {
        if (!cancelled)
          setData((d) =>
            d ? { ...d, backend_reachable: false, online: false } : null
          );
      }
    };
    fetchOnce();
    const id = window.setInterval(fetchOnce, refreshMs);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [refreshMs]);

  return data;
}

export function formatBitrate(kbps: number): string {
  if (kbps >= 1000) return `${(kbps / 1000).toFixed(1)} Mbit/s`;
  if (kbps >= 1) return `${kbps.toFixed(0)} kbit/s`;
  return '0';
}

export function formatBytes(bytes: number): string {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  return `${n.toFixed(n > 100 ? 0 : 1)} ${units[i]}`;
}
