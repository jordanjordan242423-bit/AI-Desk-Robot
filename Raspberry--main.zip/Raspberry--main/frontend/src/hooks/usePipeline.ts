import { useEffect, useMemo, useRef, useState } from 'react';
import { pipeline, robotStates } from '../data/robotStates';
import type { StateId } from '../types/robot';

interface PipelineResult {
  state: StateId;
  progress: number;
  goTo: (id: StateId) => void;
  retry: () => void;
}

/**
 * Drives the robot through its autonomous content loop. When `override` is set
 * the loop is paused and the robot holds that single state.
 */
export function usePipeline(override?: StateId): PipelineResult {
  const [index, setIndex] = useState(0);
  const [manual, setManual] = useState<StateId | null>(null);
  const [progress, setProgress] = useState(0);
  const raf = useRef<number>();

  const state: StateId = override ?? manual ?? pipeline[index];
  const duration = robotStates[state].duration;

  useEffect(() => {
    setProgress(0);
    const start = performance.now();
    let cancelled = false;

    const tick = (now: number) => {
      if (cancelled) return;
      const p = Math.min(1, (now - start) / duration);
      setProgress(p);
      if (p < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);

    const advance = window.setTimeout(() => {
      if (override) return;
      if (manual) {
        setManual(null);
        return;
      }
      setIndex((i) => (i + 1) % pipeline.length);
    }, duration);

    return () => {
      cancelled = true;
      if (raf.current) cancelAnimationFrame(raf.current);
      window.clearTimeout(advance);
    };
  }, [state, duration, override, manual]);

  return useMemo(
    () => ({
      state,
      progress,
      goTo: (id: StateId) => setManual(id),
      retry: () => {
        setManual(null);
        setIndex(pipeline.indexOf('recherche'));
      }
    }),
    [state, progress]
  );
}