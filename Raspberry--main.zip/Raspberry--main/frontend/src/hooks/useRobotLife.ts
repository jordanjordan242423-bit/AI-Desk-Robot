import { useEffect, useRef, useState } from 'react';
import { animate, useMotionValue, useReducedMotion } from 'framer-motion';
import type { MotionValue } from 'framer-motion';
import { expressions } from '../data/robotStates';
import type { RobotMood } from '../types/robot';
import type { IdleBehavior } from '../types/settings';
import type { RobotMotionProfile } from '../contexts/SettingsContext';
import type { Glance, Reaction } from '../contexts/AttentionContext';

export type Flourish = 'none' | 'curious' | 'happy' | 'stretch' | 'glance';
export type IdlePhase = 'awake' | 'calm' | 'drowsy' | 'asleep';

export interface RobotLife {
  /** Vertical lid scale — drives blinking */
  lid: MotionValue<number>;
  eyeX: MotionValue<number>;
  eyeY: MotionValue<number>;
  eyeScale: MotionValue<number>;
  headTilt: MotionValue<number>;
  headX: MotionValue<number>;
  headY: MotionValue<number>;
  lean: MotionValue<number>;
  podTwitch: MotionValue<number>;
  antenna: MotionValue<number>;
  flourish: Flourish;
  live: boolean;
  /** Clamped speed multiplier */
  speed: number;
  amp: number;
}

interface Options {
  mood: RobotMood;
  profile: RobotMotionProfile;
  idle: IdleBehavior;
  phase: IdlePhase;
  glance: Glance | null;
  reaction: Reaction | null;
}

const EASE = [0.23, 1, 0.32, 1] as const;

const gazeBias: Record<'still' | 'scan' | 'up' | 'down', {r: number;bias: number;gap: number;}> = {
  still: { r: 2.6, bias: 0, gap: 3400 },
  scan: { r: 8, bias: -0.6, gap: 1500 },
  up: { r: 2.8, bias: -3.8, gap: 2800 },
  down: { r: 2.8, bias: 3.6, gap: 2800 }
};

const idleGap: Record<IdleBehavior, number> = { still: 2.2, natuerlich: 1, neugierig: 0.6 };
const phaseGap: Record<IdlePhase, number> = { awake: 1, calm: 1.5, drowsy: 2.3, asleep: 3.4 };
const phaseAmp: Record<IdlePhase, number> = { awake: 1, calm: 0.78, drowsy: 0.46, asleep: 0.2 };

/**
 * Keeps the robot alive. Every behaviour runs on its own randomised timer, so it
 * never settles into a visible loop: irregular blinks, small eye movements,
 * posture shifts, antenna sway, and occasional moments of character. Personality
 * and the idle phase change the rates and the distances, not just the copy.
 */
export function useRobotLife({ mood, profile, idle, phase, glance, reaction }: Options): RobotLife {
  const reduced = useReducedMotion();
  const live = !reduced;
  const speed = Math.max(0.25, profile.speed);
  const amp = Math.max(0.15, profile.amplitude) * phaseAmp[phase];
  const gapScale = Math.max(0.3, profile.gazeGap) * phaseGap[phase] * idleGap[idle];
  const asleep = phase === 'asleep';

  const lid = useMotionValue(1);
  const eyeX = useMotionValue(0);
  const eyeY = useMotionValue(0);
  const eyeScale = useMotionValue(1);
  const headTilt = useMotionValue(0);
  const headX = useMotionValue(0);
  const headY = useMotionValue(0);
  const lean = useMotionValue(0);
  const podTwitch = useMotionValue(0);
  const antenna = useMotionValue(0);

  const [flourish, setFlourish] = useState<Flourish>('none');
  const hold = useRef(0);
  const gaze = expressions[mood].gaze;

  /** Randomised, self-rescheduling behaviour loop with clean teardown. */
  type Again = (ms: number) => void;
  type Delay = (ms: number, run: () => void) => void;
  const useLoop = (fn: (again: Again, delay: Delay) => void, deps: unknown[]) => {
    useEffect(() => {
      if (!live) return;
      let dead = false;
      const ids = new Set<number>();
      const delay: Delay = (ms, run) => {
        const id = window.setTimeout(() => {
          ids.delete(id);
          if (!dead) run();
        }, ms);
        ids.add(id);
      };
      const again: Again = (ms) => {
        if (dead) return;
        const id = window.setTimeout(() => {
          ids.delete(id);
          if (!dead) fn(again, delay);
        }, Math.max(200, ms));
        ids.add(id);
      };
      fn(again, delay);
      return () => {
        dead = true;
        ids.forEach((id) => window.clearTimeout(id));
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [live, ...deps]);
  };

  // ── Blinking ──────────────────────────────────────────────
  useLoop(
    (again, delay) => {
      const wait = asleep ?
      4600 + Math.random() * 3200 :
      (2100 + Math.random() * 4000) * phaseGap[phase] / speed;
      again(wait);
      if (asleep) {
        animate(lid, 0.1, { duration: 1.3, ease: 'easeInOut' });
        delay(1400, () => animate(lid, 0.3, { duration: 1.5, ease: 'easeInOut' }));
        return;
      }
      if (phase === 'drowsy') {
        animate(lid, 0.05, { duration: 0.22, ease: 'easeInOut' });
        delay(340, () => animate(lid, 1, { duration: 0.42, ease: 'easeOut' }));
        return;
      }
      animate(lid, 0.04, { duration: 0.06, ease: 'easeIn' });
      delay(66, () => animate(lid, 1, { duration: 0.11, ease: 'easeOut' }));
      if (Math.random() < 0.2) {
        delay(210, () => animate(lid, 0.06, { duration: 0.055, ease: 'easeIn' }));
        delay(270, () => animate(lid, 1, { duration: 0.1, ease: 'easeOut' }));
      }
    },
    [asleep, phase, speed]
  );

  // ── Eye movement: small saccades, occasional wider looks ──
  useLoop(
    (again) => {
      const g = gazeBias[gaze];
      again((g.gap + Math.random() * 2400) * gapScale / speed);
      if (Date.now() < hold.current || asleep) return;
      const wide = Math.random() < 0.24 ? 1.8 : 1;
      animate(eyeX, (Math.random() * 2 - 1) * g.r * wide * amp, { duration: 0.3 / speed, ease: EASE });
      animate(eyeY, g.bias + (Math.random() * 2 - 1) * g.r * 0.45 * amp, {
        duration: 0.34 / speed,
        ease: EASE
      });
    },
    [gaze, gapScale, amp, asleep, speed]
  );

  // ── Posture: head and body re-aimed rather than looped ────
  useLoop(
    (again) => {
      again((6800 + Math.random() * 6800) * phaseGap[phase] / speed);
      if (asleep) {
        animate(lean, 0, { duration: 2.6, ease: 'easeInOut' });
        animate(headTilt, -5, { duration: 2.8, ease: 'easeInOut' });
        animate(headX, 0, { duration: 2.4, ease: 'easeInOut' });
        animate(headY, 3, { duration: 2.8, ease: 'easeInOut' });
        return;
      }
      const r = () => Math.random() * 2 - 1;
      animate(lean, r() * 1.5 * amp, { duration: 3.1 / speed, ease: 'easeInOut' });
      animate(headTilt, r() * 2 * amp, { duration: 3.4 / speed, ease: 'easeInOut' });
      animate(headX, r() * 2.6 * amp, { duration: 3.2 / speed, ease: 'easeInOut' });
      animate(headY, r() * 1.2 * amp, { duration: 3.4 / speed, ease: 'easeInOut' });
    },
    [asleep, phase, amp, speed]
  );

  // ── Sensor pods and antenna move now and then ─────────────
  useLoop(
    (again, delay) => {
      again((7500 + Math.random() * 11000) * phaseGap[phase] / speed);
      if (asleep) return;
      animate(podTwitch, 1, { duration: 0.17, ease: 'easeOut' });
      delay(300, () => animate(podTwitch, 0, { duration: 0.5, ease: EASE }));
      animate(antenna, (Math.random() * 2 - 1) * 9 * amp, { duration: 0.7 / speed, ease: EASE });
      delay(1400, () => animate(antenna, 0, { duration: 1.1, ease: EASE }));
    },
    [asleep, phase, amp, speed]
  );

  // ── Occasional moments of character ───────────────────────
  useLoop(
    (again, delay) => {
      const base = (15000 + Math.random() * 18000) * Math.max(0.35, profile.flourishGap);
      again(base * phaseGap[phase] / speed);
      if (asleep || idle === 'still') return;
      const calmMoods: RobotMood[] = ['idle', 'waiting'];
      if (!calmMoods.includes(mood)) return;
      const pool: Flourish[] = profile.smile > 0.6 ? ['happy', 'curious', 'stretch'] : ['curious', 'stretch', 'glance'];
      const next = pool[Math.floor(Math.random() * pool.length)];
      setFlourish(next);
      if (next === 'glance') {
        animate(eyeX, (Math.random() > 0.5 ? 1 : -1) * 9 * amp, { duration: 0.26, ease: EASE });
        hold.current = Date.now() + 1400;
      }
      delay(next === 'stretch' ? 1500 : 1700, () => setFlourish('none'));
    },
    [asleep, idle, mood, phase, speed, profile.flourishGap, profile.smile, amp]
  );

  // ── React to what the owner just touched ──────────────────
  useEffect(() => {
    if (!glance || !live || asleep) return;
    hold.current = Date.now() + 1600;
    animate(eyeX, glance.x * 8.5, { duration: 0.24, ease: EASE });
    animate(eyeY, glance.y * 5, { duration: 0.24, ease: EASE });
    animate(headX, glance.x * 3.4 * amp, { duration: 0.48, ease: EASE });
    animate(headTilt, glance.x * 1.8 * amp, { duration: 0.48, ease: EASE });
    const id = window.setTimeout(() => {
      animate(headX, 0, { duration: 1.1, ease: EASE });
      animate(headTilt, 0, { duration: 1.1, ease: EASE });
    }, 1400);
    return () => window.clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [glance?.key, live, asleep]);

  // ── One-off reactions triggered by the interface ──────────
  useEffect(() => {
    if (!reaction || !live) return;
    const timers: number[] = [];
    const later = (ms: number, run: () => void) => timers.push(window.setTimeout(run, ms));

    if (reaction.kind === 'nod') {
      animate(headY, 4, { duration: 0.16, ease: 'easeOut' });
      later(170, () => animate(headY, -1.5, { duration: 0.22, ease: EASE }));
      later(400, () => animate(headY, 0, { duration: 0.3, ease: EASE }));
    }
    if (reaction.kind === 'excited') {
      setFlourish('happy');
      animate(eyeScale, 1.14, { duration: 0.2, ease: 'easeOut' });
      later(260, () => animate(eyeScale, 1, { duration: 0.5, ease: EASE }));
      later(1500, () => setFlourish('none'));
    }
    if (reaction.kind === 'surprise') {
      animate(eyeScale, 1.22, { duration: 0.13, ease: 'easeOut' });
      animate(lid, 1, { duration: 0.1 });
      later(120, () => animate(antenna, 8, { duration: 0.2, ease: 'easeOut' }));
      later(420, () => animate(eyeScale, 1, { duration: 0.44, ease: EASE }));
      later(620, () => animate(antenna, 0, { duration: 0.7, ease: EASE }));
    }
    return () => timers.forEach((t) => window.clearTimeout(t));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reaction?.key, live]);

  // Settle into a neutral pose when motion is off
  useEffect(() => {
    if (live) return;
    [lid, eyeScale].forEach((v) => v.set(1));
    [eyeX, eyeY, headTilt, headX, headY, lean, podTwitch, antenna].forEach((v) => v.set(0));
    setFlourish('none');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [live]);

  return {
    lid,
    eyeX,
    eyeY,
    eyeScale,
    headTilt,
    headX,
    headY,
    lean,
    podTwitch,
    antenna,
    flourish,
    live,
    speed,
    amp
  };
}