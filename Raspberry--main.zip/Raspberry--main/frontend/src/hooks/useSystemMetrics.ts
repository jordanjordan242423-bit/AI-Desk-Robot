import { useEffect, useState } from 'react';

export interface SystemMetrics {
  cpu: number;
  ram: number;
  ram_used_gb: number;
  ram_total_gb: number;
  disk: number;
  disk_used_gb: number;
  disk_total_gb: number;
  temperature_c: number | null;
  uptime_seconds: number;
  load_avg_1: number;
  load_avg_5: number;
  load_avg_15: number;
  platform: string;
  hostname: string;
  timestamp: string;
}

const BACKEND_URL =
  (typeof import.meta !== 'undefined' &&
    ((import.meta as unknown as { env: Record<string, string> }).env?.VITE_BACKEND_URL ||
      (import.meta as unknown as { env: Record<string, string> }).env?.REACT_APP_BACKEND_URL)) ||
  '';

/**
 * Polls `/api/system/metrics` every `refreshMs`. Returns null on first mount /
 * during outages so the caller can fall back to their static mock without a
 * jarring "0 %" flash.
 */
export function useSystemMetrics(refreshMs = 4000): SystemMetrics | null {
  const [data, setData] = useState<SystemMetrics | null>(null);

  useEffect(() => {
    let cancelled = false;
    const fetchOnce = async () => {
      try {
        const res = await fetch(`${BACKEND_URL}/api/system/metrics`, { cache: 'no-store' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = (await res.json()) as SystemMetrics;
        if (!cancelled) setData(j);
      } catch {
        // Silently keep the previous value; callers use their mock while null
      }
    };
    fetchOnce();
    const id = window.setInterval(fetchOnce, refreshMs);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [refreshMs]);

  return data;
}

export function formatUptime(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d} T ${h} h`;
  if (h > 0) return `${h} h ${m} min`;
  return `${m} min`;
}
