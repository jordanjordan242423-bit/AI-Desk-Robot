import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2Icon, HelpCircleIcon, SparklesIcon, TriangleAlertIcon } from 'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { TouchCard } from '../components/TouchCard';
import { Reveal, ScrollArea } from '../components/ScrollArea';
import { topics } from '../data/content';
import type { TopicItem } from '../data/content';

const EASE = [0.23, 1, 0.32, 1] as const;

const statusTone: Record<TopicItem['status'], string> = {
  'in Arbeit': 'text-accent',
  geprüft: 'text-ok',
  geplant: 'text-mist-300',
  verworfen: 'text-mist-600'
};

const verifyIcon = {
  bestätigt: { Icon: CheckCircle2Icon, tone: 'text-ok' },
  offen: { Icon: HelpCircleIcon, tone: 'text-mist-400' },
  widersprüchlich: { Icon: TriangleAlertIcon, tone: 'text-warn' }
};

function ScoreRing({ score }: {score: number;}) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-[86px] w-[86px] shrink-0">
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="rgb(255 255 255 / 0.07)" strokeWidth="4" />
        <motion.circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          stroke="rgb(var(--accent))"
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - score / 100 * c }}
          transition={{ duration: 0.7, ease: EASE }} />
        
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="tabular text-[24px] font-extralight leading-none text-mist-50">{score}</span>
        <span className="mt-1 font-mono text-[7.5px] uppercase tracking-label text-mist-600">Score</span>
      </div>
    </div>);

}

export function Themen({ onBack }: {onBack?: () => void;}) {
  const [selected, setSelected] = useState<TopicItem>(topics.find((t) => t.picked) ?? topics[0]);
  const verify = verifyIcon[selected.verified];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="Themen"
        meta={`${topics.length} selbst gefunden · ${topics.filter((t) => t.verified === 'bestätigt').length} bestätigt`}
        onBack={onBack} />
      

      <div className="flex min-h-0 flex-1 gap-4 px-6 pb-5">
        {/* Selected topic */}
        <Panel className="flex w-[330px] shrink-0 flex-col px-6 py-5">
          <div className="flex items-start justify-between">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
              {selected.picked ? 'In Recherche' : 'Gefunden'}
            </span>
            {selected.picked &&
            <span className="flex items-center gap-1.5 rounded-full bg-accent/[0.14] px-2.5 py-1 font-mono text-[8.5px] uppercase tracking-label text-accent-soft">
                <SparklesIcon className="h-3 w-3" strokeWidth={1.8} aria-hidden="true" />
                KI-Auswahl
              </span>
            }
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={selected.id}
              initial={{ opacity: 0, y: 10, filter: 'blur(4px)' }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: -8, filter: 'blur(4px)' }}
              transition={{ duration: 0.26, ease: EASE }}
              className="flex min-h-0 flex-1 flex-col">
              
              <p className="mt-4 text-[21px] font-extralight leading-snug tracking-tight text-mist-50">
                {selected.title}
              </p>
              <p className="mt-3 text-[12.5px] font-light leading-relaxed text-mist-500">
                {selected.note}
              </p>

              <div className="mt-6 flex items-center gap-6">
                <ScoreRing score={selected.score} />
                <div className="space-y-3.5">
                  <div>
                    <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                      Prüfung
                    </p>
                    <p className={`mt-1.5 flex items-center gap-1.5 text-[12.5px] font-light leading-none ${verify.tone}`}>
                      <verify.Icon className="h-3.5 w-3.5" strokeWidth={1.7} aria-hidden="true" />
                      {selected.verified}
                    </p>
                  </div>
                  <div>
                    <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                      Quellen
                    </p>
                    <p className="tabular mt-1.5 text-[12.5px] font-light leading-none text-mist-200">
                      {selected.sources} geprüft
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-auto flex items-center justify-between border-t border-white/[0.04] pt-4">
                <span className={`font-mono text-[9px] uppercase tracking-label ${statusTone[selected.status]}`}>
                  {selected.status}
                </span>
                <span className="font-mono text-[9.5px] text-mist-600">{selected.category}</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </Panel>

        {/* Everything the robot found */}
        <div className="flex min-h-0 flex-1 flex-col">
          <ScrollArea className="pr-3">
            <div className="space-y-2">
              {topics.map((t, i) => {
                const active = t.id === selected.id;
                return (
                  <Reveal key={t.id} delay={Math.min(i, 6) * 0.03}>
                    <TouchCard
                      onPress={() => setSelected(t)}
                      label={`${t.title} auswählen`}
                      className={`px-5 py-3.5 ${active ? 'border-accent/35 bg-accent/[0.055]' : ''}`}>
                      
                      <div className="flex items-center gap-4">
                        <div className="min-w-0 flex-1">
                          <p
                            className={`truncate text-[14px] font-light leading-none ${
                            t.status === 'verworfen' ? 'text-mist-600' : 'text-mist-100'}`
                            }>
                            
                            {t.title}
                          </p>
                          <div className="mt-2 flex items-center gap-3">
                            <span className={`font-mono text-[8.5px] uppercase tracking-label ${statusTone[t.status]}`}>
                              {t.status}
                            </span>
                            <span className="font-mono text-[8.5px] text-mist-600">{t.category}</span>
                            {t.picked &&
                            <SparklesIcon className="h-3 w-3 text-accent" strokeWidth={1.8} aria-hidden="true" />
                            }
                          </div>
                        </div>
                        <div className="flex w-[132px] shrink-0 items-center gap-3">
                          <div className="h-[3px] min-w-0 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
                            <motion.div
                              className={`h-full rounded-full ${t.score >= 70 ? 'bg-accent/75' : 'bg-white/20'}`}
                              initial={{ width: 0 }}
                              animate={{ width: `${t.score}%` }}
                              transition={{ duration: 0.55, ease: EASE, delay: 0.08 }} />
                            
                          </div>
                          <span className="tabular w-6 shrink-0 text-right font-mono text-[11px] text-mist-400">
                            {t.score}
                          </span>
                        </div>
                      </div>
                    </TouchCard>
                  </Reveal>);

              })}
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>);

}