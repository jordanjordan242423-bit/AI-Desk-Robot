import React from 'react';
import { Segmented } from '../../components/controls/Segmented';
import { Slider } from '../../components/controls/Slider';
import { SwatchPicker } from '../../components/controls/SwatchPicker';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { ThemesPreviewGrid } from '../../components/ThemesPreviewGrid';
import { useSettings } from '../../contexts/SettingsContext';
import { accents, backgrounds, uiStyles } from '../../types/settings';
import type { AccentId } from '../../types/settings';

export function SettingsAppearance() {
  const { settings, set, accent } = useSettings();
  const style = uiStyles.find((s) => s.id === settings.uiStyle);

  return (
    <>
      <SettingGroup title="Farbe">
        <SettingRow
          label="Akzentfarbe"
          hint={`Färbt die gesamte Oberfläche — aktuell ${accent.label}`}
          stacked>
          
          <SwatchPicker
            value={settings.accent}
            options={Object.values(accents).map((a) => ({ value: a.id, label: a.label, hex: a.hex }))}
            onChange={(v) => set('accent', v as AccentId)} />
          
        </SettingRow>
        <SettingRow label="Hintergrund" hint={backgrounds[settings.background].caption}>
          <Segmented
            id="bg"
            value={settings.background}
            onChange={(v) => set('background', v)}
            options={Object.values(backgrounds).map((b) => ({ value: b.id, label: b.label }))} />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Material">
        <SettingRow label="UI-Stil" hint={style?.caption} stacked>
          <ThemesPreviewGrid />
        </SettingRow>
        <SettingRow label="Transparenz" hint="Wie stark Flächen durchscheinen">
          <div className="w-[300px]">
            <Slider
              label="Transparenz"
              value={settings.transparency}
              onChange={(v) => set('transparency', v)}
              readout={`${settings.transparency} %`} />
            
          </div>
        </SettingRow>
        <SettingRow
          label="Unschärfe"
          hint={settings.uiStyle === 'glass' ? 'Tiefenunschärfe hinter Flächen' : 'Wirkt im Stil „Glas"'}>
          
          <div className={`w-[300px] ${settings.uiStyle === 'glass' ? '' : 'opacity-50'}`}>
            <Slider
              label="Unschärfe"
              value={settings.blur}
              min={0}
              max={28}
              onChange={(v) => set('blur', v)}
              readout={`${settings.blur} px`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Ecken" hint="Radius aller Flächen">
          <div className="w-[300px]">
            <Slider
              label="Eckenradius"
              value={settings.radius}
              min={6}
              max={34}
              onChange={(v) => set('radius', v)}
              readout={`${settings.radius} px`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Schatten" hint="Tiefe unter den Flächen">
          <div className="w-[300px]">
            <Slider
              label="Schatten"
              value={settings.shadow}
              onChange={(v) => set('shadow', v)}
              readout={`${settings.shadow} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Leuchten" hint="Akzentglanz an aktiven Elementen">
          <div className="w-[300px]">
            <Slider
              label="Leuchten"
              value={settings.glow}
              onChange={(v) => set('glow', v)}
              readout={`${settings.glow} %`} />
            
          </div>
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Größe & Bewegung">
        <SettingRow label="Dichte" hint="Abstände der Oberfläche">
          <Segmented
            id="density"
            value={settings.density}
            onChange={(v) => set('density', v)}
            options={[
            { value: 'kompakt', label: 'Kompakt' },
            { value: 'normal', label: 'Normal' },
            { value: 'luftig', label: 'Luftig' }]
            } />
          
        </SettingRow>
        <SettingRow label="Schriftgröße" hint="Skaliert Text und Abstände gemeinsam">
          <div className="w-[300px]">
            <Slider
              label="Schriftgröße"
              value={settings.uiScale}
              min={88}
              max={114}
              step={2}
              onChange={(v) => set('uiScale', v)}
              readout={`${settings.uiScale} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Animationen" hint="Wie stark sich alles bewegt">
          <Segmented
            id="anim"
            value={settings.animation}
            onChange={(v) => set('animation', v)}
            options={[
            { value: 'ruhig', label: 'Ruhig' },
            { value: 'normal', label: 'Normal' },
            { value: 'lebhaft', label: 'Lebhaft' }]
            } />
          
        </SettingRow>
      </SettingGroup>
    </>);

}