import React, { useState } from 'react';
import { TouchButton } from '../../components/TouchButton';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';
import { device, metrics, systemInfo } from '../../data/content';
import { STORAGE_KEY } from '../../types/settings';

type ResetKind = null | 'settings' | 'everything';

export function SettingsAbout() {
  const { reset, personality, accent, settings } = useSettings();
  const [confirm, setConfirm] = useState<ResetKind>(null);

  const doResetSettings = () => {
    reset();
    setConfirm(null);
  };

  const doResetEverything = () => {
    // Wipe every UI-owned key so we start truly fresh on the next boot
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      // Also drop any other eilik.* keys we may have added
      Object.keys(window.localStorage)
        .filter((k) => k.startsWith('eilik.'))
        .forEach((k) => window.localStorage.removeItem(k));
    } catch {
      /* storage unavailable — the reload below still resets in-memory state */
    }
    setConfirm(null);
    // Full reload guarantees every subsystem re-reads defaults
    window.setTimeout(() => window.location.reload(), 40);
  };

  return (
    <>
      <div className="surface px-6 py-5">
        <p className="font-mono text-[9px] uppercase tracking-label text-mist-600">Gerät</p>
        <p className="mt-3 text-[24px] font-extralight leading-none tracking-tight text-mist-50">
          {device.model}
        </p>
        <p className="mt-2.5 text-[12.5px] font-light text-mist-500">
          {device.name} · {device.subtitle}
        </p>
      </div>

      <SettingGroup title="Technische Daten">
        {[
        { label: 'Modell', value: device.model },
        { label: 'Plattform', value: device.board },
        { label: 'Firmware', value: device.firmware },
        { label: 'Seriennummer', value: device.serial },
        { label: 'Speicher', value: metrics[4].display },
        { label: 'Laufzeit', value: systemInfo[0].value },
        { label: 'Letztes Backup', value: systemInfo[3].value }].
        map((r) =>
        <SettingRow key={r.label} label={r.label}>
            <span className="tabular font-mono text-[11px] text-mist-300">{r.value}</span>
          </SettingRow>
        )}
      </SettingGroup>

      <SettingGroup title="Aktuelle Konfiguration">
        {[
        { label: 'Persönlichkeit', value: personality.label },
        { label: 'Akzent', value: accent.label },
        { label: 'UI-Stil', value: settings.uiStyle },
        { label: 'Modell', value: settings.model },
        { label: 'Videos pro Tag', value: String(settings.perDay) }].
        map((r) =>
        <SettingRow key={r.label} label={r.label}>
            <span className="font-mono text-[11px] text-mist-300">{r.value}</span>
          </SettingRow>
        )}
      </SettingGroup>

      <SettingGroup title="Zurücksetzen">
        <SettingRow
          label="Einstellungen zurücksetzen"
          hint={
          confirm === 'settings' ?
          'Darstellung, Roboter, KI und Inhalte gehen auf die Werkswerte zurück.' :
          'Gerätedaten, Videos und Statistiken bleiben erhalten.'
          }>
          {confirm === 'settings' ?
          <div className="flex items-center gap-2.5">
              <TouchButton variant="quiet" onClick={() => setConfirm(null)} data-testid="reset-settings-cancel">
                Abbrechen
              </TouchButton>
              <TouchButton variant="primary" onClick={doResetSettings} data-testid="reset-settings-confirm">
                Zurücksetzen
              </TouchButton>
            </div> :
          <TouchButton onClick={() => setConfirm('settings')} data-testid="reset-settings">Zurücksetzen</TouchButton>
          }
        </SettingRow>

        <SettingRow
          label="Alles zurücksetzen"
          hint={
          confirm === 'everything' ?
          'Alle Präferenzen werden gelöscht und die Oberfläche startet komplett neu.' :
          'Löscht auch alle lokal gespeicherten UI-Daten und lädt die App neu.'
          }>
          {confirm === 'everything' ?
          <div className="flex items-center gap-2.5">
              <TouchButton variant="quiet" onClick={() => setConfirm(null)} data-testid="reset-everything-cancel">
                Abbrechen
              </TouchButton>
              <TouchButton variant="primary" onClick={doResetEverything} data-testid="reset-everything-confirm">
                Alles löschen
              </TouchButton>
            </div> :
          <TouchButton variant="quiet" onClick={() => setConfirm('everything')} data-testid="reset-everything">
              Alles zurücksetzen
            </TouchButton>
          }
        </SettingRow>
      </SettingGroup>
    </>);

}
