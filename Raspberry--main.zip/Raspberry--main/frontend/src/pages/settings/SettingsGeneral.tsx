import React from 'react';
import { Segmented } from '../../components/controls/Segmented';
import { Toggle } from '../../components/controls/Toggle';
import { Slider } from '../../components/controls/Slider';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';

export function SettingsGeneral() {
  const { settings, set } = useSettings();

  return (
    <>
      <SettingGroup title="Sprache & Zeit">
        <SettingRow label="Sprache" hint="Oberfläche und Sprachausgabe">
          <Segmented
            id="lang"
            value={settings.language}
            onChange={(v) => set('language', v)}
            options={[
            { value: 'Deutsch', label: 'Deutsch' },
            { value: 'English', label: 'English' }]
            } />
          
        </SettingRow>
        <SettingRow label="Zeitformat" hint="Gilt für die Statusleiste">
          <Segmented
            id="time"
            value={settings.timeFormat}
            onChange={(v) => set('timeFormat', v)}
            options={[
            { value: '24 h', label: '24 h' },
            { value: '12 h', label: '12 h' }]
            } />
          
        </SettingRow>
        <SettingRow label="Datumsformat">
          <Segmented
            id="date"
            value={settings.dateFormat}
            onChange={(v) => set('dateFormat', v)}
            options={[
            { value: 'TT.MM.JJJJ', label: 'TT.MM.JJJJ' },
            { value: 'JJJJ-MM-TT', label: 'JJJJ-MM-TT' }]
            } />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Start & Ruhe">
        <SettingRow label="Startbildschirm" hint="Was nach dem Einschalten erscheint">
          <Segmented
            id="startup"
            value={settings.startup}
            onChange={(v) => set('startup', v)}
            options={[
            { value: 'home', label: 'Home' },
            { value: 'robot', label: 'Roboter' },
            { value: 'prozess', label: 'Prozess' }]
            } />
          
        </SettingRow>
        <SettingRow label="Schlafmodus" hint="Der Roboter wird nach längerer Ruhe müde">
          <Toggle label="Schlafmodus" checked={settings.sleepMode} onChange={(v) => set('sleepMode', v)} />
        </SettingRow>
        <SettingRow label="Bildschirm-Timeout" hint="Wann der Roboter einschläft">
          <Segmented
            id="timeout"
            value={settings.screenTimeout}
            onChange={(v) => set('screenTimeout', v)}
            options={[
            { value: '1 Min', label: '1 Min' },
            { value: '5 Min', label: '5 Min' },
            { value: '15 Min', label: '15 Min' },
            { value: 'Nie', label: 'Nie' }]
            } />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Ton & Hinweise">
        <SettingRow label="Töne" hint="Kurze Quittungen bei Ereignissen">
          <Toggle label="Töne" checked={settings.sound} onChange={(v) => set('sound', v)} />
        </SettingRow>
        <SettingRow label="Lautstärke" hint={settings.sound ? undefined : 'Töne sind aus'}>
          <div className={`w-[300px] ${settings.sound ? '' : 'pointer-events-none opacity-40'}`}>
            <Slider
              label="Lautstärke"
              value={settings.volume}
              onChange={(v) => set('volume', v)}
              readout={`${settings.volume} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Mitteilungen" hint="Fertige Videos und Fehler melden">
          <Toggle
            label="Mitteilungen"
            checked={settings.notifications}
            onChange={(v) => set('notifications', v)} />
          
        </SettingRow>
      </SettingGroup>
    </>);

}