import React from 'react';
import { Segmented } from '../../components/controls/Segmented';
import { Toggle } from '../../components/controls/Toggle';
import { Slider } from '../../components/controls/Slider';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';

export function SettingsDisplay() {
  const { settings, set } = useSettings();

  return (
    <>
      <SettingGroup title="Helligkeit">
        <SettingRow
          label="Helligkeit"
          hint={settings.autoBrightness ? 'Wird automatisch geregelt' : 'Wirkt sofort auf das Panel'}>
          
          <div className={`w-[300px] ${settings.autoBrightness ? 'pointer-events-none opacity-40' : ''}`}>
            <Slider
              label="Helligkeit"
              value={settings.brightness}
              min={15}
              max={100}
              onChange={(v) => set('brightness', v)}
              readout={`${settings.brightness} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Automatisch" hint="Passt sich dem Umgebungslicht an">
          <Toggle
            label="Automatische Helligkeit"
            checked={settings.autoBrightness}
            onChange={(v) => set('autoBrightness', v)} />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Ruhezustand">
        <SettingRow label="Bildschirm-Timeout" hint="Danach wird der Roboter müde">
          <Segmented
            id="dtimeout"
            value={settings.screenTimeout}
            onChange={(v) => set('screenTimeout', v)}
            options={[
            { value: '1 Min', label: '1 Min' },
            { value: '5 Min', label: '5 Min' },
            { value: '15 Min', label: '15 Min' },
            { value: 'Nie', label: 'Nie' }]
            } />
          
        </SettingRow>
        <SettingRow label="Display-Ruhe" hint="Wie sich das Gerät im Schlaf verhält">
          <Segmented
            id="dsleep"
            value={settings.sleepBehavior}
            onChange={(v) => set('sleepBehavior', v)}
            options={[
            { value: 'Augen schließen', label: 'Augen zu' },
            { value: 'Nur dimmen', label: 'Dimmen' },
            { value: 'Display aus', label: 'Aus' }]
            } />
          
        </SettingRow>
        <SettingRow label="Schlafmodus" hint="Schaltet den Ruhezustand ganz ab">
          <Toggle label="Schlafmodus" checked={settings.sleepMode} onChange={(v) => set('sleepMode', v)} />
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Skalierung">
        <SettingRow label="UI-Skalierung" hint="Vergrößert die ganze Oberfläche">
          <div className="w-[300px]">
            <Slider
              label="UI-Skalierung"
              value={settings.uiScale}
              min={88}
              max={114}
              step={2}
              onChange={(v) => set('uiScale', v)}
              readout={`${settings.uiScale} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Animationsstärke" hint="Gilt für Oberfläche und Roboter">
          <Segmented
            id="danim"
            value={settings.animation}
            onChange={(v) => set('animation', v)}
            options={[
            { value: 'ruhig', label: 'Ruhig' },
            { value: 'normal', label: 'Normal' },
            { value: 'lebhaft', label: 'Lebhaft' }]
            } />
          
        </SettingRow>
      </SettingGroup>
    </>);

}