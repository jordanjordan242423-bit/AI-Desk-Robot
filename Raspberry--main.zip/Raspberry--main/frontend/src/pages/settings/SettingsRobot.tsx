import React, { useEffect, useRef, useState } from 'react';
import { RobotViewport } from '../../components/RobotViewport';
import { Segmented } from '../../components/controls/Segmented';
import { Toggle } from '../../components/controls/Toggle';
import { Slider } from '../../components/controls/Slider';
import { SwatchPicker } from '../../components/controls/SwatchPicker';
import { ChipPicker } from '../../components/controls/ChipPicker';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';
import { useAttention } from '../../contexts/AttentionContext';
import { accents, personalities } from '../../types/settings';
import type { RobotMood } from '../../types/robot';

const moodOptions: {label: string;mood: RobotMood;}[] = [
{ label: 'Ruhig', mood: 'idle' },
{ label: 'Neugierig', mood: 'curious' },
{ label: 'Denken', mood: 'thinking' },
{ label: 'Sprechen', mood: 'speaking' },
{ label: 'Glücklich', mood: 'success' },
{ label: 'Sorge', mood: 'error' },
{ label: 'Schlafen', mood: 'sleeping' }];


export function SettingsRobot() {
  const { settings, set, accent, personality } = useSettings();
  const { react } = useAttention();
  const [preview, setPreview] = useState<RobotMood>('idle');

  // The robot acknowledges it when you change how it looks or behaves
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    react('excited');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.eyeColor, settings.eyeShape, settings.personality, settings.bodyColor, settings.antennaStyle]);

  const accentOptions = Object.values(accents).map((a) => ({
    value: a.id,
    label: a.label,
    hex: a.hex
  }));

  return (
    <>
      {/* Live preview — every control below changes this immediately */}
      <div className="surface flex items-center gap-6 px-6 py-4">
        <div className="shrink-0">
          <RobotViewport
            mood={preview === 'sleeping' ? 'idle' : preview}
            height={132}
            phase={preview === 'sleeping' ? 'asleep' : 'awake'}
            label="Roboter-Vorschau — wischen zum Drehen" />
          
        </div>
        <div className="min-w-0">
          <p className="text-[15px] font-light text-mist-100">Vorschau</p>
          <p className="mt-1.5 text-[11.5px] font-light leading-relaxed text-mist-500">
            Wischen dreht den Roboter. Jede Einstellung wirkt sofort — {personality.label}:{' '}
            {personality.caption.toLowerCase()}.
          </p>
          <div className="mt-3">
            <ChipPicker
              label="Ausdruck der Vorschau"
              values={[moodOptions.find((m) => m.mood === preview)?.label ?? 'Ruhig']}
              options={moodOptions.map((m) => m.label)}
              onChange={(next) => {
                const picked = next[next.length - 1];
                const found = moodOptions.find((m) => m.label === picked);
                if (found) setPreview(found.mood);
              }} />
            
          </div>
        </div>
      </div>

      <SettingGroup title="Größe">
        <SettingRow label="Robotergröße" hint="Wie groß er auf dem Display sitzt">
          <div className="w-[300px]">
            <Slider
              label="Robotergröße"
              value={settings.robotSize}
              min={80}
              max={130}
              onChange={(v) => set('robotSize', v)}
              readout={`${settings.robotSize} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Voreinstellung">
          <Segmented
            id="rsize"
            value={settings.robotSize <= 90 ? 'klein' : settings.robotSize >= 115 ? 'gross' : 'normal'}
            onChange={(v) => set('robotSize', v === 'klein' ? 86 : v === 'gross' ? 122 : 100)}
            options={[
            { value: 'klein', label: 'Klein' },
            { value: 'normal', label: 'Normal' },
            { value: 'gross', label: 'Groß' }]
            } />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Augen">
        <SettingRow label="Form">
          <Segmented
            id="eyeshape"
            value={settings.eyeShape}
            onChange={(v) => set('eyeShape', v)}
            options={[
            { value: 'rund', label: 'Rund' },
            { value: 'pille', label: 'Pille' },
            { value: 'balken', label: 'Balken' },
            { value: 'kristall', label: 'Kristall' }]
            } />
          
        </SettingRow>
        <SettingRow label="Farbe" hint="Auto folgt der Akzentfarbe" stacked>
          <SwatchPicker
            value={settings.eyeColor}
            options={[{ value: 'auto' as const, label: 'Auto', hex: accent.hex }, ...accentOptions]}
            onChange={(v) => set('eyeColor', v)} />
          
        </SettingRow>
        <SettingRow label="Größe">
          <div className="w-[300px]">
            <Slider
              label="Augengröße"
              value={settings.eyeSize}
              min={70}
              max={140}
              onChange={(v) => set('eyeSize', v)}
              readout={`${settings.eyeSize} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Abstand">
          <div className="w-[300px]">
            <Slider
              label="Augenabstand"
              value={settings.eyeSpacing}
              min={78}
              max={128}
              onChange={(v) => set('eyeSpacing', v)}
              readout={`${settings.eyeSpacing} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Leuchtkraft">
          <div className="w-[300px]">
            <Slider
              label="Leuchtkraft der Augen"
              value={settings.eyeBrightness}
              min={30}
              max={100}
              onChange={(v) => set('eyeBrightness', v)}
              readout={`${settings.eyeBrightness} %`} />
            
          </div>
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Gesicht & Mund">
        <SettingRow label="Displayhelligkeit" hint="Wie hell das Glas im Gesicht ist">
          <div className="w-[300px]">
            <Slider
              label="Gesichtshelligkeit"
              value={settings.faceBrightness}
              min={0}
              max={100}
              onChange={(v) => set('faceBrightness', v)}
              readout={`${settings.faceBrightness} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Mundform">
          <Segmented
            id="mouth"
            value={settings.mouthStyle}
            onChange={(v) => set('mouthStyle', v)}
            options={[
            { value: 'weich', label: 'Weich' },
            { value: 'linie', label: 'Linie' },
            { value: 'punkt', label: 'Punkt' },
            { value: 'keine', label: 'Kein' }]
            } />
          
        </SettingRow>
        <SettingRow label="Mundgröße">
          <div className={`w-[300px] ${settings.mouthStyle === 'keine' ? 'pointer-events-none opacity-40' : ''}`}>
            <Slider
              label="Mundgröße"
              value={settings.mouthSize}
              min={70}
              max={130}
              onChange={(v) => set('mouthSize', v)}
              readout={`${settings.mouthSize} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Leuchten" hint="Glanz von Augen, Antenne und Ladefläche">
          <div className="w-[300px]">
            <Slider
              label="Leuchtintensität"
              value={settings.robotGlow}
              onChange={(v) => set('robotGlow', v)}
              readout={`${settings.robotGlow} %`} />
            
          </div>
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Körper, Arme & Antenne">
        <SettingRow label="Gehäusefarbe">
          <Segmented
            id="bodycol"
            value={settings.bodyColor}
            onChange={(v) => set('bodyColor', v)}
            options={[
            { value: 'perlweiss', label: 'Perlweiß' },
            { value: 'sand', label: 'Sand' },
            { value: 'mint', label: 'Mint' },
            { value: 'schiefer', label: 'Schiefer' },
            { value: 'graphit', label: 'Graphit' }]
            } />
          
        </SettingRow>
        <SettingRow label="Gehäusehelligkeit">
          <div className="w-[300px]">
            <Slider
              label="Gehäusehelligkeit"
              value={settings.bodyBrightness}
              min={70}
              max={120}
              onChange={(v) => set('bodyBrightness', v)}
              readout={`${settings.bodyBrightness} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Arme">
          <Segmented
            id="arms"
            value={settings.armStyle}
            onChange={(v) => set('armStyle', v)}
            options={[
            { value: 'gelenk', label: 'Gelenk' },
            { value: 'rund', label: 'Rund' },
            { value: 'flach', label: 'Flach' }]
            } />
          
        </SettingRow>
        <SettingRow label="Antenne">
          <Segmented
            id="antenna"
            value={settings.antennaStyle}
            onChange={(v) => set('antennaStyle', v)}
            options={[
            { value: 'einzel', label: 'Einzeln' },
            { value: 'doppel', label: 'Doppelt' },
            { value: 'bogen', label: 'Bogen' },
            { value: 'keine', label: 'Keine' }]
            } />
          
        </SettingRow>
        <SettingRow label="Antennenbewegung" hint="Sie zuckt und schwingt beim Drehen">
          <Toggle
            label="Antennenbewegung"
            checked={settings.antennaMotion}
            onChange={(v) => set('antennaMotion', v)} />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Verhalten">
        <SettingRow label="Persönlichkeit" hint={personality.caption} stacked>
          <Segmented
            id="pers"
            wide
            value={settings.personality}
            onChange={(v) => set('personality', v)}
            options={Object.values(personalities).map((p) => ({ value: p.id, label: p.label }))} />
          
        </SettingRow>
        <SettingRow label="Leerlaufverhalten" hint="Wie oft er sich umschaut">
          <Segmented
            id="idle"
            value={settings.idle}
            onChange={(v) => set('idle', v)}
            options={[
            { value: 'still', label: 'Still' },
            { value: 'natuerlich', label: 'Natürlich' },
            { value: 'neugierig', label: 'Neugierig' }]
            } />
          
        </SettingRow>
        <SettingRow label="Bewegungstempo">
          <div className="w-[300px]">
            <Slider
              label="Animationstempo"
              value={settings.animationSpeed}
              min={60}
              max={160}
              onChange={(v) => set('animationSpeed', v)}
              readout={`${settings.animationSpeed} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Bewegungsstärke">
          <Segmented
            id="ranim"
            value={settings.animation}
            onChange={(v) => set('animation', v)}
            options={[
            { value: 'ruhig', label: 'Ruhig' },
            { value: 'normal', label: 'Normal' },
            { value: 'lebhaft', label: 'Lebhaft' }]
            } />
          
        </SettingRow>
        <SettingRow label="Stimme">
          <Segmented
            id="voice"
            value={settings.voice}
            onChange={(v) => set('voice', v)}
            options={[
            { value: 'Nova', label: 'Nova' },
            { value: 'Kai', label: 'Kai' },
            { value: 'Mara', label: 'Mara' }]
            } />
          
        </SettingRow>
        <SettingRow label="Begrüßung" hint="Erscheint im Roboter-Modus">
          <Segmented
            id="greet"
            value={settings.greeting}
            onChange={(v) => set('greeting', v)}
            options={[
            { value: 'Hey 👋', label: 'Hey' },
            { value: 'Moin', label: 'Moin' },
            { value: 'Ich bin bereit.', label: 'Bereit' },
            { value: 'Stumm', label: 'Stumm' }]
            } />
          
        </SettingRow>
        <SettingRow label="Schlafverhalten">
          <Segmented
            id="rsleep"
            value={settings.sleepBehavior}
            onChange={(v) => set('sleepBehavior', v)}
            options={[
            { value: 'Augen schließen', label: 'Augen zu' },
            { value: 'Nur dimmen', label: 'Dimmen' },
            { value: 'Display aus', label: 'Aus' }]
            } />
          
        </SettingRow>
      </SettingGroup>
    </>);

}