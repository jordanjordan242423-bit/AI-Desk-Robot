import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { RotateCcwIcon, ScrollTextIcon, SearchCheckIcon } from 'lucide-react';
import { TouchButton } from '../../components/TouchButton';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { activity, metrics, services, systemInfo } from '../../data/content';

const EASE = [0.23, 1, 0.32, 1] as const;

export function SettingsSystem() {
  const [logsOpen, setLogsOpen] = useState(false);
  const [updateNote, setUpdateNote] = useState<string | null>(null);
  const [restart, setRestart] = useState<'idle' | 'confirm' | 'running'>('idle');

  const now = () => new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });

  return (
    <>
      <SettingGroup title="Auslastung">
        {metrics.map((m) =>
        <SettingRow key={m.id} label={m.label} hint={m.detail}>
            <div className="flex items-center gap-4">
              <div className="h-[4px] w-[150px] overflow-hidden rounded-full bg-white/[0.07]">
                <motion.div
                className={`h-full rounded-full ${m.value > 80 ? 'bg-warn' : 'bg-accent/80'}`}
                initial={{ width: 0 }}
                animate={{ width: `${m.value}%` }}
                transition={{ duration: 0.5, ease: EASE }} />
              
              </div>
              <span className="tabular w-[86px] text-right font-mono text-[11px] text-mist-300">
                {m.display}
              </span>
            </div>
          </SettingRow>
        )}
      </SettingGroup>

      <SettingGroup title="Dienste">
        {services.map((s) =>
        <SettingRow key={s.id} label={s.label} hint={s.detail}>
            <div className="flex items-center gap-2.5">
              <span
              className={`h-1.5 w-1.5 rounded-full ${
              s.state === 'ok' ? 'bg-ok' : s.state === 'busy' ? 'bg-accent' : 'bg-warn'}`
              }
              aria-hidden="true" />
            
              <span className="font-mono text-[11px] text-mist-300">{s.value}</span>
            </div>
          </SettingRow>
        )}
      </SettingGroup>

      <SettingGroup title="Wartung">
        <SettingRow
          label="Software"
          hint={updateNote ?? `${systemInfo[1].value} · zuletzt geprüft heute`}>
          
          <TouchButton
            onClick={() => setUpdateNote(`Keine neue Version · geprüft ${now()}`)}
            icon={<SearchCheckIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
            
            Prüfen
          </TouchButton>
        </SettingRow>

        <SettingRow label="Protokolle" hint={`${activity.length} Einträge von heute`}>
          <TouchButton
            onClick={() => setLogsOpen((v) => !v)}
            icon={<ScrollTextIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
            
            {logsOpen ? 'Schließen' : 'Anzeigen'}
          </TouchButton>
        </SettingRow>

        <AnimatePresence initial={false}>
          {logsOpen &&
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.26, ease: EASE }}
            className="overflow-hidden">
            
              <div className="divide-y divide-white/[0.03] px-[18px] pb-3 pt-1">
                {activity.map((a) =>
              <div key={a.time} className="flex items-center gap-5 py-2">
                    <span className="tabular w-11 shrink-0 font-mono text-[10px] text-mist-600">
                      {a.time}
                    </span>
                    <p className="truncate font-mono text-[10.5px] text-mist-400">{a.text}</p>
                  </div>
              )}
              </div>
            </motion.div>
          }
        </AnimatePresence>

        <SettingRow
          label="Neu starten"
          hint={
          restart === 'running' ?
          'Neustart eingeleitet — Dienste werden beendet …' :
          restart === 'confirm' ?
          'Sicher? Laufende Produktion wird abgebrochen.' :
          `Laufzeit ${systemInfo[0].value}`
          }>
          
          {restart === 'confirm' ?
          <div className="flex items-center gap-2.5">
              <TouchButton variant="quiet" onClick={() => setRestart('idle')}>
                Abbrechen
              </TouchButton>
              <TouchButton
              variant="primary"
              onClick={() => {
                setRestart('running');
                window.setTimeout(() => setRestart('idle'), 3200);
              }}>
              
                Bestätigen
              </TouchButton>
            </div> :

          <TouchButton
            onClick={() => setRestart('confirm')}
            icon={<RotateCcwIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
            
              {restart === 'running' ? 'Läuft …' : 'Neustart'}
            </TouchButton>
          }
        </SettingRow>
      </SettingGroup>
    </>);

}