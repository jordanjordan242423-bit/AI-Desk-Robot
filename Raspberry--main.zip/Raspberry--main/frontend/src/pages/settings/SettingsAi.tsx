import React from 'react';
import { Segmented } from '../../components/controls/Segmented';
import { Toggle } from '../../components/controls/Toggle';
import { Slider } from '../../components/controls/Slider';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';

export function SettingsAi() {
  const { settings, set } = useSettings();

  const creativityNote =
  settings.creativity < 35 ?
  'Bleibt sehr nah an den Quellen' :
  settings.creativity > 75 ?
  'Formuliert freier, mehr eigene Bilder' :
  'Ausgewogen zwischen Quelle und Erzählung';

  return (
    <>
      <SettingGroup title="Modell">
        <SettingRow label="Sprachmodell" hint="Läuft lokal über Ollama">
          <Segmented
            id="model"
            value={settings.model}
            onChange={(v) => set('model', v)}
            options={[
            { value: 'llama3', label: 'llama3' },
            { value: 'mistral', label: 'mistral' },
            { value: 'qwen2', label: 'qwen2' }]
            } />
          
        </SettingRow>
        <SettingRow label="Kreativität" hint={creativityNote}>
          <div className="w-[300px]">
            <Slider
              label="Kreativität"
              value={settings.creativity}
              onChange={(v) => set('creativity', v)}
              readout={`${settings.creativity} %`} />
            
          </div>
        </SettingRow>
        <SettingRow label="Antwortlänge" hint="Wie ausführlich der Roboter erklärt">
          <Segmented
            id="respstyle"
            value={settings.responseStyle}
            onChange={(v) => set('responseStyle', v)}
            options={[
            { value: 'kurz', label: 'Kurz' },
            { value: 'normal', label: 'Normal' },
            { value: 'ausführlich', label: 'Lang' }]
            } />
          
        </SettingRow>
        <SettingRow label="Ausgabesprache">
          <Segmented
            id="ailang"
            value={settings.aiLanguage}
            onChange={(v) => set('aiLanguage', v)}
            options={[
            { value: 'de-DE', label: 'de-DE' },
            { value: 'en-US', label: 'en-US' }]
            } />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Recherche">
        <SettingRow label="Recherchetiefe" hint="Woher die Themen kommen">
          <Segmented
            id="research"
            value={settings.research}
            onChange={(v) => set('research', v)}
            options={[
            { value: 'breit', label: 'Breit' },
            { value: 'fokussiert', label: 'Fokussiert' },
            { value: 'aktuell', label: 'Aktuell' }]
            } />
          
        </SettingRow>
        <SettingRow
          label="Themen selbst wählen"
          hint={settings.autoTopic ? 'Der Roboter entscheidet allein' : 'Themen werden nur vorgeschlagen'}>
          
          <Toggle
            label="Automatische Themenwahl"
            checked={settings.autoTopic}
            onChange={(v) => set('autoTopic', v)} />
          
        </SettingRow>
        <SettingRow label="Faktencheck" hint="Wie streng Quellen geprüft werden">
          <Segmented
            id="fact"
            value={settings.factCheck}
            onChange={(v) => set('factCheck', v)}
            options={[
            { value: 'streng', label: 'Streng' },
            { value: 'normal', label: 'Normal' },
            { value: 'aus', label: 'Aus' }]
            } />
          
        </SettingRow>
      </SettingGroup>
    </>);

}