import React from 'react';
import { Segmented } from '../../components/controls/Segmented';
import { Toggle } from '../../components/controls/Toggle';
import { Slider } from '../../components/controls/Slider';
import { ChipPicker } from '../../components/controls/ChipPicker';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';
import { topicTags } from '../../data/content';

export function SettingsContent() {
  const { settings, set } = useSettings();

  return (
    <>
      <SettingGroup title="Produktion">
        <SettingRow label="Videos pro Tag" hint="Wie viel der Roboter produziert">
          <div className="w-[300px]">
            <Slider
              label="Videos pro Tag"
              value={settings.perDay}
              min={1}
              max={6}
              onChange={(v) => set('perDay', v)}
              readout={String(settings.perDay)} />
            
          </div>
        </SettingRow>
        <SettingRow label="Videolänge">
          <Segmented
            id="len"
            value={settings.videoLength}
            onChange={(v) => set('videoLength', v)}
            options={[
            { value: '30 s', label: '30 s' },
            { value: '45 s', label: '45 s' },
            { value: '60 s', label: '60 s' }]
            } />
          
        </SettingRow>
        <SettingRow label="Uploadzeiten" hint="Wann veröffentlicht wird" stacked>
          <ChipPicker
            label="Uploadzeiten"
            values={settings.publishTimes}
            options={['08:00', '11:00', '14:00', '17:00', '20:00', '22:00']}
            onChange={(v) => set('publishTimes', v)} />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Veröffentlichung">
        <SettingRow
          label="Automatisch veröffentlichen"
          hint={settings.autoPublish ? 'Fertige Videos gehen direkt online' : 'Videos warten auf dich'}>
          
          <Toggle
            label="Automatisch veröffentlichen"
            checked={settings.autoPublish}
            onChange={(v) => set('autoPublish', v)} />
          
        </SettingRow>
        <SettingRow
          label="Manueller Upload"
          hint="Zeigt Download, Handy-Übertragung und Upload-Infos im Video">
          
          <Toggle
            label="Manueller Upload"
            checked={settings.manualFallback}
            onChange={(v) => set('manualFallback', v)} />
          
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Untertitel">
        <SettingRow label="Untertitel" hint="Werden fest ins Video gerendert">
          <Toggle label="Untertitel" checked={settings.subtitles} onChange={(v) => set('subtitles', v)} />
        </SettingRow>
        <SettingRow label="Untertitelgröße">
          <div className={settings.subtitles ? '' : 'pointer-events-none opacity-40'}>
            <Segmented
              id="subsize"
              value={settings.subtitleSize}
              onChange={(v) => set('subtitleSize', v)}
              options={[
              { value: 'klein', label: 'Klein' },
              { value: 'normal', label: 'Normal' },
              { value: 'groß', label: 'Groß' }]
              } />
            
          </div>
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Themenfelder">
        <SettingRow
          label="Kategorien"
          hint={`${settings.categories.length} von ${topicTags.length} aktiv`}
          stacked>
          
          <ChipPicker
            label="Kategorien"
            values={settings.categories}
            options={topicTags}
            onChange={(v) => set('categories', v)} />
          
        </SettingRow>
      </SettingGroup>
    </>);

}