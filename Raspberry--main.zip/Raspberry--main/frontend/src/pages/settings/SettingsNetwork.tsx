import React from 'react';
import { motion } from 'framer-motion';
import { Toggle } from '../../components/controls/Toggle';
import { TouchButton } from '../../components/TouchButton';
import { SettingGroup, SettingRow } from '../../components/controls/SettingRow';
import { useSettings } from '../../contexts/SettingsContext';
import { network } from '../../data/content';

export function SettingsNetwork({ onOpenNetwork }: {onOpenNetwork: () => void;}) {
  const { settings, set } = useSettings();
  const on = settings.wifi;

  return (
    <>
      <SettingGroup title="Verbindung">
        <SettingRow
          label="WLAN"
          hint={on ? `Verbunden mit ${network.ssid}` : 'Ausgeschaltet — nichts wird hochgeladen'}>
          
          <Toggle label="WLAN" checked={on} onChange={(v) => set('wifi', v)} />
        </SettingRow>
        <SettingRow label="Automatisch verbinden" hint="Beim Start bekannte Netze nutzen">
          <div className={on ? '' : 'pointer-events-none opacity-40'}>
            <Toggle
              label="Automatisch verbinden"
              checked={settings.autoConnect}
              onChange={(v) => set('autoConnect', v)} />
            
          </div>
        </SettingRow>
        <SettingRow label="Hotspot" hint="Eigenes Netz für die lokale Seite">
          <Toggle label="Hotspot" checked={settings.hotspot} onChange={(v) => set('hotspot', v)} />
        </SettingRow>
      </SettingGroup>

      <SettingGroup title="Status">
        <SettingRow label="Signal" hint={on ? network.type : 'Keine Verbindung'} stacked>
          <div className="h-[4px] overflow-hidden rounded-full bg-white/[0.07]">
            <motion.div
              className={`h-full rounded-full ${on ? 'bg-accent' : 'bg-mist-600'}`}
              animate={{ width: on ? `${network.signal}%` : '0%' }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }} />
            
          </div>
        </SettingRow>
        {[
        { label: 'Download', value: on ? network.down : '—' },
        { label: 'Upload', value: on ? network.up : '—' },
        { label: 'Latenz', value: on ? network.latency : '—' },
        { label: 'IP-Adresse', value: on ? network.ip : '—' },
        { label: 'Datenvolumen heute', value: on ? network.today : '—' }].
        map((r) =>
        <SettingRow key={r.label} label={r.label}>
            <span className="tabular font-mono text-[11px] text-mist-300">{r.value}</span>
          </SettingRow>
        )}
      </SettingGroup>

      <SettingGroup title="Details">
        <SettingRow label="Alle Netzwerkdaten" hint="Gateway, DNS, MAC und Durchsatz">
          <TouchButton onClick={onOpenNetwork}>Öffnen</TouchButton>
        </SettingRow>
      </SettingGroup>
    </>);

}