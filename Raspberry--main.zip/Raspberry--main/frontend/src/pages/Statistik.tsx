import React from 'react';
import { motion } from 'framer-motion';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { Reveal, ScrollArea } from '../components/ScrollArea';
import { activity, stats, week } from '../data/content';

const EASE = [0.23, 1, 0.32, 1] as const;

export function Statistik({ onBack }: {onBack?: () => void;}) {
  const max = Math.max(...week.map((w) => w.count));

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Statistik" meta="Letzte 7 Tage" onBack={onBack} />

      <ScrollArea className="px-6 pb-5">
        <div className="flex gap-4">
          <Panel className="flex w-[252px] shrink-0 flex-col justify-between px-6 py-5">
            <div>
              <p className="font-mono text-[9px] uppercase tracking-label text-mist-600">
                Videos heute
              </p>
              <p className="tabular mt-3 text-[68px] font-extralight leading-none tracking-tighter text-mist-50">
                {stats.heute}
              </p>
            </div>
            <div className="mt-6 flex gap-8 border-t border-white/[0.04] pt-4">
              {[
              { label: 'Woche', value: stats.woche },
              { label: 'Gesamt', value: stats.gesamt }].
              map((m) =>
              <div key={m.label}>
                  <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {m.label}
                  </p>
                  <p className="tabular mt-1.5 text-[20px] font-light leading-none text-mist-100">
                    {m.value}
                  </p>
                </div>
              )}
            </div>
          </Panel>

          <Panel title="Verlauf der Woche" className="min-w-0 flex-1 px-6 pb-5">
            <div className="flex h-[104px] items-end gap-3 pt-3">
              {week.map((d, i) =>
              <div key={d.day} className="flex flex-1 flex-col items-center gap-2.5">
                  <motion.div
                  className={`w-full rounded-[3px] ${
                  i === week.length - 1 ? 'bg-accent/70' : 'bg-white/[0.12]'}`
                  }
                  initial={{ height: 2 }}
                  animate={{ height: 6 + d.count / max * 66 }}
                  transition={{ duration: 0.5, ease: EASE, delay: i * 0.04 }} />
                
                  <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
                    {d.day}
                  </span>
                </div>
              )}
            </div>
            <div className="mt-4 grid grid-cols-4 gap-4 border-t border-white/[0.04] pt-4">
              {[
              { label: 'Erfolgreich', value: String(stats.erfolgreich) },
              { label: 'Fehlgeschlagen', value: String(stats.fehler) },
              { label: 'Hochgeladen', value: String(stats.hochgeladen) },
              { label: 'Erfolgsquote', value: stats.erfolgsquote }].
              map((f) =>
              <div key={f.label}>
                  <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {f.label}
                  </p>
                  <p className="tabular mt-1.5 text-[16px] font-light leading-none text-mist-100">
                    {f.value}
                  </p>
                </div>
              )}
            </div>
          </Panel>
        </div>

        <Panel title="Aktivität" className="mt-4 px-6 pb-3">
          <div className="divide-y divide-white/[0.04] pt-1">
            {activity.map((a) =>
            <Reveal key={a.time}>
                <div className="flex items-center gap-6 py-3">
                  <span className="tabular w-11 shrink-0 font-mono text-[10.5px] text-mist-600">
                    {a.time}
                  </span>
                  <p className="truncate text-[13px] font-light text-mist-200">{a.text}</p>
                </div>
              </Reveal>
            )}
          </div>
        </Panel>
      </ScrollArea>
    </div>);

}