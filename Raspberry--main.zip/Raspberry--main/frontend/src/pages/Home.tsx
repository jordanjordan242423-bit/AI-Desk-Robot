import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ChevronRightIcon,
  CloudSunIcon,
  FilmIcon,
  PlayIcon,
  RotateCcwIcon } from
'lucide-react';
import { RobotViewport } from '../components/RobotViewport';
import { TouchCard } from '../components/TouchCard';
import { TouchButton } from '../components/TouchButton';
import { WeatherPinPicker, weatherPinOptions } from '../components/WeatherPinPicker';
import { activeStep, robotStates, trail } from '../data/robotStates';
import { metrics as mockMetrics, stats, topics, weather as fallbackWeather } from '../data/content';
import { useSettings } from '../contexts/SettingsContext';
import { useWeather } from '../hooks/useWeather';
import { useSystemMetrics } from '../hooks/useSystemMetrics';
import type { IdlePhase } from '../hooks/useRobotLife';
import type { ScreenId, StateId } from '../types/robot';

interface HomeProps {
  state: StateId;
  progress: number;
  phase: IdlePhase;
  onRetry: () => void;
  onOpenRobot: () => void;
  onOpen: (screen: ScreenId) => void;
}

const EASE = [0.23, 1, 0.32, 1] as const;
const shortLabel: Record<string, string> = { cpu: 'CPU', ram: 'RAM', gpu: 'GPU', temp: 'Temp' };

export function Home({ state, progress, phase, onRetry, onOpenRobot, onOpen }: HomeProps) {
  const { personality, settings } = useSettings();
  const live = useWeather({
    lat: settings.weatherLat,
    lon: settings.weatherLon,
    place: settings.weatherPlace,
    useBrowserLocation: settings.weatherUseBrowserLocation
  });
  const weather = live ?? fallbackWeather;
  const sys = useSystemMetrics(4000);
  const homeMetrics = sys
    ? [
        { id: 'cpu', label: 'CPU', value: sys.cpu, display: `${sys.cpu.toFixed(0)} %` },
        { id: 'ram', label: 'RAM', value: sys.ram, display: `${sys.ram.toFixed(0)} %` },
        {
          id: 'disk',
          label: 'Disk',
          value: sys.disk,
          display: `${sys.disk.toFixed(0)} %`
        },
        {
          id: 'temp',
          label: 'Temp',
          value: sys.temperature_c ?? 0,
          display: sys.temperature_c !== null ? `${sys.temperature_c.toFixed(0)}°C` : '—'
        }
      ]
    : mockMetrics.slice(0, 4).map((m) => ({
        id: m.id,
        label: shortLabel[m.id] ?? m.label,
        value: m.value,
        display: m.id === 'temp' ? m.display : `${m.value} %`
      }));
  const def = robotStates[state];
  const step = activeStep(state);
  const stage = trail.findIndex((t) => t.steps.includes(step));
  const topic = topics.find((t) => t.picked) ?? topics[0];
  const asleep = phase === 'asleep';
  const isError = state === 'fehler';
  const isDone = state === 'fertig';
  const running = !asleep && !isError && !isDone && state !== 'bereit';

  return (
    <div
      className="grid min-h-0 flex-1"
      style={{
        gridTemplateColumns: 'calc(244px * var(--ui)) 1fr calc(244px * var(--ui))',
        gap: 'calc(15px * var(--ui))',
        padding: '0 calc(20px * var(--ui)) calc(4px * var(--ui))'
      }}>
      
      {/* ── Left: quiet context, one tap from its own screen ── */}
      <div className="flex min-h-0 flex-col" style={{ gap: 'calc(14px * var(--ui))' }}>
        <TouchCard
          onPress={() => onOpen('wetter')}
          label="Wetter öffnen"
          className="min-h-0 flex-1 justify-between px-[18px] py-4">
          
          <div className="flex items-start justify-between">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
              {weather.place}
            </span>
            <div className="flex items-center gap-2">
              <WeatherPinPicker />
              <CloudSunIcon className="h-[18px] w-[18px] text-mist-500" strokeWidth={1.4} aria-hidden="true" />
            </div>
          </div>
          <div>
            <p className="tabular text-[38px] font-extralight leading-none tracking-tight text-mist-50">
              {weather.temp}
            </p>
            <p className="mt-2 truncate text-[12px] font-light text-mist-400">{weather.text}</p>
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-white/[0.04] pt-3">
            {(settings.homeWeatherPins.length > 0
              ? settings.homeWeatherPins
              : ['rain', 'wind']
            )
              .map((pinKey) => weatherPinOptions.find((o) => o.key === pinKey))
              .filter((o): o is (typeof weatherPinOptions)[number] => !!o)
              .slice(0, 4)
              .map((opt) => (
                <span
                  key={opt.key}
                  data-testid={`home-weather-pin-${opt.key}`}
                  className="flex items-center gap-1.5 font-mono text-[9.5px] text-mist-500">
                  <span className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {opt.label}
                  </span>
                  <span className="tabular text-mist-300">
                    {opt.value(weather as unknown as Record<string, string | number>)}
                  </span>
                </span>
              ))}
          </div>
        </TouchCard>

        <TouchCard
          onPress={() => onOpen('videos')}
          label="Videos öffnen"
          className="min-h-0 flex-1 justify-between px-[18px] py-4">
          
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">Videos</span>
            <FilmIcon className="h-[18px] w-[18px] text-mist-500" strokeWidth={1.4} aria-hidden="true" />
          </div>
          <div className="flex items-end gap-5">
            <div>
              <p className="tabular text-[38px] font-extralight leading-none tracking-tight text-mist-50">
                {stats.heute}
              </p>
              <p className="mt-2 font-mono text-[9px] uppercase tracking-label text-mist-600">Heute</p>
            </div>
            <div className="pb-1">
              <p className="tabular text-[17px] font-light leading-none text-mist-300">{stats.woche}</p>
              <p className="mt-1.5 font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                Woche
              </p>
            </div>
            <div className="pb-1">
              <p className="tabular text-[17px] font-light leading-none text-mist-300">{stats.gesamt}</p>
              <p className="mt-1.5 font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                Gesamt
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between border-t border-white/[0.04] pt-3">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
              Nächster Upload
            </span>
            <span className="tabular font-mono text-[11.5px] text-accent">{stats.nextUpload}</span>
          </div>
        </TouchCard>
      </div>

      {/* ── Centre: the robot, with nothing competing ── */}
      <div className="flex min-h-0 flex-col items-center justify-center">
        <motion.div layoutId="robot-body" transition={{ duration: 0.44, ease: EASE }}>
          <RobotViewport
            mood={def.mood}
            height={236}
            phase={phase}
            onTap={onOpenRobot}
            persistKey="eilik.robot.rotY"
            label="Roboter — tippen für Roboter-Modus, wischen zum Drehen" />
          
        </motion.div>

        <div className="mt-1 flex h-[90px] w-full flex-col items-center">
          <AnimatePresence mode="wait">
            <motion.p
              key={asleep ? 'sleep' : def.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.24, ease: EASE }}
              className={`font-mono text-[9.5px] uppercase tracking-label ${
              isError ? 'text-warn' : asleep ? 'text-mist-600' : 'text-accent'}`
              }>
              
              {asleep ? 'Schlafmodus' : def.label}
            </motion.p>
          </AnimatePresence>

          <AnimatePresence mode="wait">
            <motion.p
              key={asleep ? 'sleepline' : def.id + personality.tone}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.28, ease: EASE }}
              className="mt-2.5 max-w-[372px] text-center text-[17px] font-extralight leading-snug tracking-tight text-mist-50">
              
              {asleep ? 'Ich ruhe kurz. Tippe mich an.' : def.lines[personality.tone]}
            </motion.p>
          </AnimatePresence>

          <div className="mt-auto flex h-8 items-center">
            {running &&
            <div className="flex items-center gap-3">
                <div className="h-[2px] w-[180px] overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                  className="h-full rounded-full bg-accent"
                  style={{ width: `${Math.round(progress * 100)}%`, transition: 'width 120ms linear' }} />
                
                </div>
                <span className="tabular font-mono text-[9.5px] text-mist-600">
                  {Math.round(progress * 100)} %
                </span>
              </div>
            }
            {isDone &&
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.26, ease: EASE }}>
              
                <TouchButton
                variant="primary"
                onClick={() => onOpen('videos')}
                icon={<PlayIcon className="h-3.5 w-3.5" strokeWidth={1.8} />}>
                
                  Video öffnen
                </TouchButton>
              </motion.div>
            }
            {isError &&
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.26, ease: EASE }}>
              
                <TouchButton
                variant="primary"
                onClick={onRetry}
                icon={<RotateCcwIcon className="h-3.5 w-3.5" strokeWidth={1.8} />}>
                
                  Erneut versuchen
                </TouchButton>
              </motion.div>
            }
          </div>
        </div>
      </div>

      {/* ── Right: what the robot is doing, and how it is holding up ── */}
      <div className="flex min-h-0 flex-col" style={{ gap: 'calc(14px * var(--ui))' }}>
        <TouchCard
          onPress={() => onOpen('prozess')}
          label="Prozess öffnen"
          className="min-h-0 flex-1 px-[18px] py-4">
          
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">Prozess</span>
            <ChevronRightIcon className="h-4 w-4 text-mist-600" strokeWidth={1.6} aria-hidden="true" />
          </div>

          <ol className="mt-4 flex flex-1 flex-col justify-between">
            {trail.map((t, i) => {
              const active = i === stage && !asleep;
              const past = stage > i || isDone;
              return (
                <li key={t.label} className="flex items-center gap-3">
                  <span className="relative flex h-3 w-3 shrink-0 items-center justify-center">
                    {active ?
                    <>
                        <motion.span
                        className="absolute inset-0 rounded-full border border-accent"
                        animate={{ opacity: [0.2, 0.75, 0.2], scale: [0.85, 1.2, 0.85] }}
                        transition={{ duration: 2.6, repeat: Infinity, ease: 'easeInOut' }} />
                      
                        <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                      </> :

                    <span className={`h-1.5 w-1.5 rounded-full ${past ? 'bg-accent/50' : 'bg-white/[0.14]'}`} />
                    }
                  </span>
                  <span
                    className={`text-[13px] font-light leading-none ${
                    active ? 'text-mist-50' : past ? 'text-mist-400' : 'text-mist-600'}`
                    }>
                    
                    {t.label}
                  </span>
                </li>);

            })}
          </ol>

          <div className="mt-3 border-t border-white/[0.04] pt-3">
            <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">Thema</p>
            <p className="mt-1.5 truncate text-[12px] font-light text-mist-300">{topic.title}</p>
          </div>
        </TouchCard>

        <TouchCard
          onPress={() => onOpen('system')}
          label="System öffnen"
          className="min-h-0 flex-1 px-[18px] py-4">
          
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">System</span>
            <ChevronRightIcon className="h-4 w-4 text-mist-600" strokeWidth={1.6} aria-hidden="true" />
          </div>
          <div className="mt-4 flex flex-1 flex-col justify-between">
            {homeMetrics.map((m) =>
            <div key={m.id} className="flex items-center gap-3">
                <span className="w-[34px] shrink-0 font-mono text-[9px] uppercase tracking-label text-mist-600">
                  {m.label}
                </span>
                <div className="h-[3px] min-w-0 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                  className={`h-full rounded-full ${m.value > 80 ? 'bg-warn' : 'bg-accent/70'}`}
                  style={{ width: `${Math.min(100, Math.max(0, m.value))}%` }} />
                
                </div>
                <span className="tabular w-[42px] shrink-0 text-right font-mono text-[9.5px] text-mist-500">
                  {m.display}
                </span>
              </div>
            )}
          </div>
        </TouchCard>
      </div>
    </div>);

}