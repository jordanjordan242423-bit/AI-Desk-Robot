import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckIcon } from 'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { activeStep, processSteps, robotStates } from '../data/robotStates';
import { topics } from '../data/content';
import { useSettings } from '../contexts/SettingsContext';
import type { StateId } from '../types/robot';

interface ProzessProps {
  state: StateId;
  progress: number;
  onBack: () => void;
}

const EASE = [0.23, 1, 0.32, 1] as const;

export function Prozess({ state, progress, onBack }: ProzessProps) {
  const { personality } = useSettings();
  const def = robotStates[state];
  const step = activeStep(state);
  const current = processSteps[Math.max(step, 0)];
  const topic = topics.find((t) => t.picked) ?? topics[0];
  const done = state === 'fertig';

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="Prozess"
        meta={`${processSteps.length} Schritte · ${done ? 'abgeschlossen' : def.label}`}
        onBack={onBack} />
      

      <div className="flex min-h-0 flex-1 gap-4 px-6 pb-5">
        {/* The pipeline itself */}
        <Panel className="w-[318px] shrink-0 px-5 py-4">
          <ol className="flex h-full flex-col justify-between">
            {processSteps.map((s, i) => {
              const active = i === step && !done;
              const past = i < step || done;
              return (
                <li key={s.id} className="relative flex items-center gap-3.5">
                  {i < processSteps.length - 1 &&
                  <span
                    className={`absolute left-[11px] top-[26px] h-[16px] w-[1px] ${
                    past ? 'bg-accent/40' : 'bg-white/[0.08]'}`
                    }
                    aria-hidden="true" />

                  }
                  <span className="relative flex h-[23px] w-[23px] shrink-0 items-center justify-center">
                    {active &&
                    <motion.span
                      className="absolute inset-0 rounded-full border border-accent"
                      animate={{ opacity: [0.2, 0.8, 0.2], scale: [0.82, 1.15, 0.82] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }} />

                    }
                    <span
                      className={`flex h-[19px] w-[19px] items-center justify-center rounded-full ${
                      active ?
                      'bg-accent/25 text-accent-soft' :
                      past ?
                      'bg-accent/[0.14] text-accent' :
                      'bg-white/[0.05] text-mist-600'}`
                      }>
                      
                      {past ?
                      <CheckIcon className="h-3 w-3" strokeWidth={2.4} aria-hidden="true" /> :

                      <span className="tabular font-mono text-[9px]">{i + 1}</span>
                      }
                    </span>
                  </span>
                  <div className="min-w-0 flex-1">
                    <p
                      className={`text-[13.5px] font-light leading-none ${
                      active ? 'text-mist-50' : past ? 'text-mist-300' : 'text-mist-600'}`
                      }>
                      
                      {s.label}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 font-mono text-[8.5px] uppercase tracking-label ${
                    active ? 'text-accent' : 'text-mist-600'}`
                    }>
                    
                    {s.code}
                  </span>
                </li>);

            })}
          </ol>
        </Panel>

        {/* What is happening right now */}
        <div className="flex min-h-0 flex-1 flex-col gap-4">
          <Panel className="flex min-h-0 flex-1 flex-col px-6 py-5">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
              Aktueller Schritt
            </span>
            <AnimatePresence mode="wait">
              <motion.div
                key={current?.id ?? 'idle'}
                initial={{ opacity: 0, y: 10, filter: 'blur(4px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -8, filter: 'blur(4px)' }}
                transition={{ duration: 0.28, ease: EASE }}>
                
                <p className="mt-3 text-[30px] font-extralight leading-none tracking-tight text-mist-50">
                  {step < 0 ? 'Bereit' : current.label}
                </p>
                <p className="mt-3 max-w-[420px] text-[13px] font-light leading-relaxed text-mist-400">
                  {step < 0 ?
                  'Der nächste Durchlauf startet automatisch. Der Roboter wartet auf den nächsten Zeitpunkt.' :
                  current.detail}
                </p>
              </motion.div>
            </AnimatePresence>

            <div className="mt-auto">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
                  Fortschritt Schritt
                </span>
                <span className="tabular font-mono text-[10.5px] text-accent">
                  {Math.round(progress * 100)} %
                </span>
              </div>
              <div className="mt-2.5 h-[3px] overflow-hidden rounded-full bg-white/[0.07]">
                <div
                  className="h-full rounded-full bg-accent"
                  style={{ width: `${Math.round(progress * 100)}%`, transition: 'width 120ms linear' }} />
                
              </div>
              <p className="mt-4 text-[12.5px] font-light italic text-mist-500">
                „{def.lines[personality.tone]}"
              </p>
            </div>
          </Panel>

          <Panel className="shrink-0 px-6 py-4">
            <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
              Aktuelles Thema
            </span>
            <p className="mt-2.5 truncate text-[15px] font-light text-mist-100">{topic.title}</p>
            <div className="mt-3 flex items-center gap-6 border-t border-white/[0.04] pt-3">
              {[
              { label: 'Score', value: String(topic.score) },
              { label: 'Quellen', value: String(topic.sources) },
              { label: 'Prüfung', value: topic.verified },
              { label: 'Kategorie', value: topic.category }].
              map((f) =>
              <div key={f.label}>
                  <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {f.label}
                  </p>
                  <p className="mt-1.5 text-[12.5px] font-light leading-none text-mist-200">
                    {f.value}
                  </p>
                </div>
              )}
            </div>
          </Panel>
        </div>
      </div>
    </div>);

}