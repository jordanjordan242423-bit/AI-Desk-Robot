import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { DownloadIcon, PlayIcon, SmartphoneIcon, UploadIcon } from 'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { TouchCard } from '../components/TouchCard';
import { TouchButton } from '../components/TouchButton';
import { QRTag } from '../components/QRTag';
import { Reveal, ScrollArea } from '../components/ScrollArea';
import { videos } from '../data/content';
import { useSettings } from '../contexts/SettingsContext';
import { useAttention } from '../contexts/AttentionContext';
import type { VideoItem, VideoStatus } from '../data/content';

const EASE = [0.23, 1, 0.32, 1] as const;

const statusTone: Record<VideoStatus, string> = {
  veröffentlicht: 'text-ok',
  bereit: 'text-accent',
  rendert: 'text-mist-300',
  fehler: 'text-warn'
};

const uploadTone = {
  online: 'text-ok',
  geplant: 'text-accent',
  wartet: 'text-mist-400',
  fehlgeschlagen: 'text-warn'
};

export function Videos({ onBack }: {onBack?: () => void;}) {
  const [selected, setSelected] = useState<VideoItem | null>(null);
  const { react } = useAttention();

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <AnimatePresence mode="wait">
        {selected ?
        <motion.div
          key="detail"
          initial={{ opacity: 0, scale: 0.985 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.99 }}
          transition={{ duration: 0.26, ease: EASE }}
          className="flex min-h-0 flex-1 flex-col">
          
            <Detail video={selected} onBack={() => setSelected(null)} />
          </motion.div> :

        <motion.div
          key="list"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.24, ease: EASE }}
          className="flex min-h-0 flex-1 flex-col">
          
            <ScreenHeader title="Videos" meta={`${videos.length} zuletzt · 128 gesamt`} onBack={onBack} />
            <ScrollArea className="px-6 pb-6">
              <div className="grid grid-cols-4 gap-x-4 gap-y-5">
                {videos.map((v, i) =>
              <Reveal key={v.id} delay={i % 4 * 0.04}>
                    <TouchCard
                  onPress={() => {
                    react('nod');
                    setSelected(v);
                  }}
                  label={`${v.title} öffnen`}
                  className="overflow-hidden p-0">
                  
                      <div
                    className="relative h-[150px] w-full overflow-hidden bg-ink-800"
                    style={{ borderRadius: 'calc(var(--radius) - 1px) calc(var(--radius) - 1px) 0 0' }}>
                    
                        <img
                      src={v.thumb}
                      alt={v.title}
                      className="h-full w-full object-cover opacity-90 transition-opacity duration-300 group-hover:opacity-100" />
                    
                        <span className="absolute bottom-2.5 right-2.5 rounded-full bg-black/70 px-2 py-[3px] font-mono text-[9px] text-mist-100">
                          {v.duration}
                        </span>
                        {v.status === 'rendert' &&
                    <motion.span
                      className="absolute bottom-0 left-0 h-[2px] bg-accent"
                      animate={{ width: ['10%', '78%', '10%'] }}
                      transition={{ duration: 5.2, repeat: Infinity, ease: 'easeInOut' }} />

                    }
                      </div>
                      <div className="px-3.5 pb-3.5 pt-3">
                        <p className="line-clamp-2 min-h-[34px] text-[12.5px] font-light leading-snug text-mist-100">
                          {v.title}
                        </p>
                        <div className="mt-2.5 flex items-center justify-between">
                          <span className={`font-mono text-[8.5px] uppercase tracking-label ${statusTone[v.status]}`}>
                            {v.status}
                          </span>
                          <span className="font-mono text-[8.5px] text-mist-600">{v.date}</span>
                        </div>
                      </div>
                    </TouchCard>
                  </Reveal>
              )}
              </div>
            </ScrollArea>
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}

function Detail({ video, onBack }: {video: VideoItem;onBack: () => void;}) {
  const { settings } = useSettings();
  const manual = settings.manualFallback;

  const facts = [
  { label: 'Aufrufe', value: video.views },
  { label: 'Länge', value: video.duration },
  { label: 'Auflösung', value: video.resolution },
  { label: 'Größe', value: video.size },
  { label: 'Wörter', value: String(video.words) },
  { label: 'Quellen', value: String(video.sources) }];


  return (
    <>
      <ScreenHeader title={video.title} meta={`${video.topic} · ${video.date}`} onBack={onBack} />

      <div className="flex min-h-0 flex-1 gap-4 px-6 pb-5">
        <div
          className="relative w-[210px] shrink-0 overflow-hidden bg-ink-800"
          style={{ borderRadius: 'var(--radius)' }}>
          
          <img src={video.thumb} alt={video.title} className="h-full w-full object-cover" />
          <div
            className="absolute inset-0"
            style={{ background: 'linear-gradient(0deg, rgba(0,0,0,0.62) 0%, rgba(0,0,0,0) 58%)' }}
            aria-hidden="true" />
          
          <button
            type="button"
            aria-label="Video abspielen"
            className="absolute inset-0 flex items-center justify-center outline-none">
            
            <span className="flex h-14 w-14 items-center justify-center rounded-full border border-white/25 bg-black/40 backdrop-blur-sm transition-colors duration-200 hover:bg-black/60">
              <PlayIcon className="ml-[2px] h-5 w-5 text-mist-50" strokeWidth={1.6} aria-hidden="true" />
            </span>
          </button>
          <span className="absolute bottom-3 left-3 rounded-full bg-black/70 px-2.5 py-1 font-mono text-[10px] text-mist-100">
            {video.duration}
          </span>
        </div>

        <div className="flex min-h-0 flex-1 flex-col gap-4">
          <Panel className="px-6 py-5">
            <div className="flex items-start justify-between gap-8">
              <div className="min-w-0">
                <span className={`font-mono text-[9px] uppercase tracking-label ${statusTone[video.status]}`}>
                  Verarbeitung · {video.status}
                </span>
                <p className="mt-2.5 text-[13px] font-light leading-relaxed text-mist-300">
                  {video.description}
                </p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {video.hashtags.map((h) =>
                  <span
                    key={h}
                    className="rounded-full border border-white/[0.06] px-2.5 py-[3px] font-mono text-[9.5px] text-mist-400">
                    
                      {h}
                    </span>
                  )}
                </div>
              </div>
              <div className="shrink-0 text-right">
                <p className="font-mono text-[9px] uppercase tracking-label text-mist-600">Upload</p>
                <p className={`mt-2 text-[14px] font-light leading-none ${uploadTone[video.upload]}`}>
                  {video.upload}
                </p>
                <p className="mt-2 font-mono text-[9.5px] text-mist-600">{video.uploadNote}</p>
              </div>
            </div>
          </Panel>

          <Panel className="flex min-h-0 flex-1 flex-col px-6 py-5">
            <div className="grid grid-cols-6 gap-4">
              {facts.map((f) =>
              <div key={f.label}>
                  <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {f.label}
                  </p>
                  <p className="tabular mt-2 text-[16px] font-light leading-none text-mist-100">
                    {f.value}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-auto flex items-end justify-between gap-6 pt-5">
              <div className="flex flex-wrap items-center gap-2.5">
                <TouchButton variant="primary" icon={<PlayIcon className="h-3.5 w-3.5" strokeWidth={1.8} />}>
                  Abspielen
                </TouchButton>
                <TouchButton icon={<UploadIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
                  Hochladen
                </TouchButton>
                {manual &&
                <>
                    <TouchButton icon={<DownloadIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
                      Herunterladen
                    </TouchButton>
                    <TouchButton icon={<SmartphoneIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
                      Auf Handy
                    </TouchButton>
                  </>
                }
              </div>

              {manual &&
              <div className="flex shrink-0 items-center gap-3">
                  <div className="text-right">
                    <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                      Manueller Upload
                    </p>
                    <p className="mt-1.5 max-w-[150px] text-[10.5px] font-light leading-snug text-mist-500">
                      Scannen, um Titel, Beschreibung und Hashtags auf dem Handy zu öffnen.
                    </p>
                  </div>
                  <QRTag px={54} />
                </div>
              }
            </div>
          </Panel>
        </div>
      </div>
    </>);

}