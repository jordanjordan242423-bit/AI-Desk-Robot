import React from 'react';
import { motion } from 'framer-motion';
import { WifiIcon, WifiOffIcon } from 'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { TouchButton } from '../components/TouchButton';
import { network as fallback } from '../data/content';
import { formatBitrate, formatBytes, useNetworkStatus } from '../hooks/useNetworkStatus';

const EASE = [0.23, 1, 0.32, 1] as const;

export function Netzwerk({ onBack }: { onBack: () => void }) {
  const live = useNetworkStatus(3500);
  const isLive = live !== null;

  const ssid = live?.ssid ?? (live?.online ? live.primary_interface ?? 'Ethernet' : fallback.ssid);
  const ip = live?.ip ?? fallback.ip;
  const signal =
    live?.signal_percent ??
    (live?.online ? 92 : 0);
  const online = live?.online ?? true;
  const backendUp = live?.backend_reachable ?? true;

  const details = [
    { label: 'IP-Adresse', value: ip },
    { label: 'Hostname', value: live?.hostname ?? fallback.gateway },
    {
      label: 'Primäres Interface',
      value: live?.primary_interface ?? fallback.type
    },
    {
      label: 'MAC',
      value:
        live?.interfaces?.find((i) => i.name === live?.primary_interface)?.mac ?? fallback.mac
    },
    {
      label: 'Verbindung',
      value: live
        ? `${
            live.interfaces.find((i) => i.name === live.primary_interface)?.speed_mbps ?? '—'
          } Mbit/s`
        : fallback.band
    },
    { label: 'Backend', value: backendUp ? 'Erreichbar' : 'Nicht erreichbar' }
  ];

  const traffic = live
    ? [
        { label: 'Download', value: formatBitrate(live.download_kbps) },
        { label: 'Upload', value: formatBitrate(live.upload_kbps) },
        {
          label: 'Gesendet',
          value: formatBytes(live.bytes_sent_total)
        },
        {
          label: 'Empfangen',
          value: formatBytes(live.bytes_recv_total)
        }
      ]
    : [
        { label: 'Download', value: fallback.down },
        { label: 'Upload', value: fallback.up },
        { label: 'Latenz', value: fallback.latency },
        { label: 'Heute', value: fallback.today }
      ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="Netzwerk"
        meta={isLive ? (online ? `Live · ${ssid}` : 'Offline') : ssid}
        onBack={onBack}
      />

      <div className="flex min-h-0 flex-1 gap-4 px-6 pb-5">
        <Panel className="flex w-[300px] shrink-0 flex-col justify-between px-6 py-5">
          <div>
            <div className="flex items-start justify-between">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-label text-mist-600">
                  {online ? 'Verbunden' : 'Getrennt'}
                </p>
                <p
                  data-testid="net-ssid"
                  className="mt-2.5 text-[21px] font-light leading-none text-mist-50">
                  {ssid}
                </p>
                <p
                  data-testid="net-ip"
                  className="tabular mt-1.5 font-mono text-[11px] text-mist-400">
                  {ip}
                </p>
              </div>
              {online ? (
                <WifiIcon className="h-8 w-8 text-accent/80" strokeWidth={1.2} aria-hidden="true" />
              ) : (
                <WifiOffIcon className="h-8 w-8 text-warn/80" strokeWidth={1.2} aria-hidden="true" />
              )}
            </div>

            <div className="mt-6">
              <div className="flex items-baseline justify-between">
                <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
                  Signal
                </span>
                <span
                  data-testid="net-signal"
                  className="tabular font-mono text-[11px] text-accent">
                  {signal ? `${signal} %` : '—'}
                </span>
              </div>
              <div className="mt-2.5 h-[4px] overflow-hidden rounded-full bg-white/[0.07]">
                <motion.div
                  className={`h-full rounded-full ${signal > 30 ? 'bg-accent' : 'bg-warn'}`}
                  initial={false}
                  animate={{ width: `${Math.min(100, Math.max(0, signal))}%` }}
                  transition={{ duration: 0.5, ease: EASE }}
                />
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  backendUp ? 'bg-ok' : 'bg-warn'
                }`}
                aria-hidden="true"
              />
              <span className="font-mono text-[9.5px] uppercase tracking-label text-mist-500">
                Backend {backendUp ? 'online' : 'offline'}
              </span>
            </div>
          </div>

          <div className="flex gap-2.5 border-t border-white/[0.04] pt-4">
            <TouchButton variant="primary">Neu verbinden</TouchButton>
            <TouchButton>Trennen</TouchButton>
          </div>
        </Panel>

        <div className="flex min-h-0 flex-1 flex-col gap-4">
          <Panel className="px-6 py-5">
            <div className="grid grid-cols-4 gap-5">
              {traffic.map((m) => (
                <div key={m.label} data-testid={`net-traffic-${m.label}`}>
                  <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {m.label}
                  </p>
                  <p className="tabular mt-2 text-[20px] font-light leading-none text-mist-50">
                    {m.value}
                  </p>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title={isLive ? 'Details · live' : 'Details'} className="min-h-0 flex-1 px-6 pb-4">
            <div className="grid grid-cols-2 gap-x-8 divide-y divide-white/[0.04] pt-1">
              {details.map((d) => (
                <div key={d.label} className="flex items-center justify-between py-3">
                  <span className="text-[12.5px] font-light text-mist-400">{d.label}</span>
                  <span className="tabular font-mono text-[11px] text-mist-200">{d.value ?? '—'}</span>
                </div>
              ))}
            </div>
          </Panel>

          {live && live.interfaces.length > 1 && (
            <Panel title="Weitere Interfaces" className="px-6 pb-4">
              <div className="grid grid-cols-3 gap-3 pt-1">
                {live.interfaces
                  .filter((i) => i.name !== live.primary_interface)
                  .map((i) => (
                    <div
                      key={i.name}
                      className="border border-white/[0.04] px-3 py-2"
                      style={{ borderRadius: 'calc(var(--radius) * 0.6)' }}>
                      <div className="flex items-center gap-2">
                        <span
                          className={`h-1.5 w-1.5 rounded-full ${
                            i.is_up ? 'bg-ok' : 'bg-mist-600'
                          }`}
                          aria-hidden="true"
                        />
                        <span className="font-mono text-[9px] uppercase tracking-label text-mist-500">
                          {i.name}
                        </span>
                      </div>
                      <p className="tabular mt-1.5 font-mono text-[10px] text-mist-300">
                        {i.ip ?? '—'}
                      </p>
                    </div>
                  ))}
              </div>
            </Panel>
          )}
        </div>
      </div>
    </div>
  );
}
