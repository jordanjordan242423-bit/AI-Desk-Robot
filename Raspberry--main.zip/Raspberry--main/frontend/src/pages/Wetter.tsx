import React from 'react';
import { motion } from 'framer-motion';
import { CloudIcon, CloudRainIcon, CloudSunIcon, MoonIcon, SunIcon } from 'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { ScrollArea } from '../components/ScrollArea';
import { LocationPicker } from '../components/LocationPicker';
import { weather as fallbackWeather } from '../data/content';
import { useWeather } from '../hooks/useWeather';
import { useSettings } from '../contexts/SettingsContext';

const EASE = [0.23, 1, 0.32, 1] as const;

const skyIcon = {
  sun: SunIcon,
  cloud: CloudIcon,
  rain: CloudRainIcon,
  night: MoonIcon
};

export function Wetter({ onBack }: { onBack: () => void }) {
  const { settings, set } = useSettings();
  const live = useWeather({
    lat: settings.weatherLat,
    lon: settings.weatherLon,
    place: settings.weatherPlace,
    useBrowserLocation: settings.weatherUseBrowserLocation
  });
  const weather = live ?? fallbackWeather;
  const hi = Math.max(...weather.days.map((d) => d.high));
  const lo = Math.min(...weather.days.map((d) => d.low));

  const details = [
    { label: 'Gefühlt', value: weather.feels },
    { label: 'Luftfeuchte', value: weather.humidity },
    { label: 'Wind', value: weather.wind },
    { label: 'Regen', value: weather.rain },
    { label: 'Luftdruck', value: weather.pressure },
    { label: 'UV-Index', value: weather.uv }
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="Wetter"
        meta={live ? 'Live · Open-Meteo' : weather.place}
        onBack={onBack}
        action={
          <LocationPicker
            currentPlace={settings.weatherPlace}
            onPick={(loc) => {
              set('weatherPlace', loc.name);
              set('weatherLat', loc.latitude);
              set('weatherLon', loc.longitude);
              set('weatherUseBrowserLocation', false);
              // Force the cache to refresh with the new location
              try {
                window.localStorage.removeItem('eilik.weather.v1');
              } catch {
                /* ignore */
              }
            }}
            onUseCurrent={() => {
              set('weatherUseBrowserLocation', true);
              try {
                window.localStorage.removeItem('eilik.weather.v1');
              } catch {
                /* ignore */
              }
            }}
          />
        }
      />

      <ScrollArea className="px-6 pb-5">
        <div className="flex gap-4">
          <Panel className="flex w-[320px] shrink-0 flex-col justify-between px-6 py-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="tabular text-[76px] font-extralight leading-none tracking-tighter text-mist-50">
                  {weather.temp}
                </p>
                <p className="mt-3 text-[15px] font-light text-mist-300">{weather.text}</p>
                <p className="mt-1.5 font-mono text-[9px] uppercase tracking-label text-mist-600">
                  {weather.place}
                </p>
              </div>
              <CloudSunIcon className="h-10 w-10 text-accent/80" strokeWidth={1.1} aria-hidden="true" />
            </div>
            <div className="mt-6 flex items-center gap-5 border-t border-white/[0.04] pt-4">
              <span className="font-mono text-[10px] uppercase tracking-label text-mist-500">
                Höchst {weather.high}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-label text-mist-600">
                Tiefst {weather.low}
              </span>
            </div>
          </Panel>

          <Panel className="min-w-0 flex-1 px-6 py-5">
            <div className="grid grid-cols-3 gap-x-6 gap-y-5">
              {details.map((d) => (
                <div key={d.label}>
                  <p className="font-mono text-[9px] uppercase tracking-label text-mist-600">
                    {d.label}
                  </p>
                  <p className="tabular mt-2 text-[21px] font-light leading-none text-mist-100">
                    {d.value}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-5 flex items-center gap-6 border-t border-white/[0.04] pt-4">
              <span className="font-mono text-[10px] uppercase tracking-label text-mist-500">
                Sonnenaufgang {weather.sunrise}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-label text-mist-500">
                Sonnenuntergang {weather.sunset}
              </span>
            </div>
          </Panel>
        </div>

        <Panel title="Heute" className="mt-4 px-6 pb-5">
          <div className="flex items-end justify-between gap-2 pt-2">
            {weather.hours.map((h, i) => {
              const Icon = skyIcon[h.sky];
              return (
                <motion.div
                  key={h.time + i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, ease: EASE, delay: i * 0.035 }}
                  className="flex flex-1 flex-col items-center gap-2.5">
                  <span className="tabular font-mono text-[9.5px] text-mist-600">{h.rain}</span>
                  <Icon className="h-[18px] w-[18px] text-mist-400" strokeWidth={1.4} aria-hidden="true" />
                  <span className="tabular text-[17px] font-light leading-none text-mist-100">
                    {h.temp}
                  </span>
                  <span className="tabular font-mono text-[9.5px] uppercase tracking-label text-mist-600">
                    {h.time}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </Panel>

        <Panel title="Nächste Tage" className="mt-4 px-6 pb-4">
          <div className="divide-y divide-white/[0.04] pt-1">
            {weather.days.map((d, i) => {
              const Icon = skyIcon[d.sky];
              const left = ((d.low - lo) / (hi - lo)) * 100;
              const width = ((d.high - d.low) / (hi - lo)) * 100;
              return (
                <div key={d.day + i} className="flex items-center gap-5 py-3">
                  <span className="w-9 shrink-0 font-mono text-[11px] uppercase tracking-label text-mist-300">
                    {d.day}
                  </span>
                  <Icon className="h-[17px] w-[17px] shrink-0 text-mist-500" strokeWidth={1.4} aria-hidden="true" />
                  <span className="w-[120px] shrink-0 truncate text-[12.5px] font-light text-mist-400">
                    {d.text}
                  </span>
                  <span className="tabular w-10 shrink-0 text-right font-mono text-[11px] text-mist-600">
                    {d.low}°
                  </span>
                  <div className="relative h-[4px] min-w-0 flex-1 rounded-full bg-white/[0.06]">
                    <motion.div
                      className="absolute inset-y-0 rounded-full bg-accent/70"
                      initial={{ opacity: 0, scaleX: 0.4 }}
                      animate={{ opacity: 1, scaleX: 1 }}
                      transition={{ duration: 0.45, ease: EASE, delay: 0.06 + i * 0.05 }}
                      style={{
                        left: `${left}%`,
                        width: `${Math.max(width, 6)}%`,
                        originX: 0
                      }}
                    />
                  </div>
                  <span className="tabular w-10 shrink-0 font-mono text-[11px] text-mist-200">
                    {d.high}°
                  </span>
                  <span className="tabular w-12 shrink-0 text-right font-mono text-[10px] text-mist-600">
                    {d.rain}
                  </span>
                </div>
              );
            })}
          </div>
        </Panel>
      </ScrollArea>
    </div>
  );
}
