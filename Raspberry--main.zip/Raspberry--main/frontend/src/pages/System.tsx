import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckIcon, RefreshCwIcon } from 'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { TouchCard } from '../components/TouchCard';
import { TouchButton } from '../components/TouchButton';
import { ScrollArea } from '../components/ScrollArea';
import { metrics as mockMetrics, services, systemInfo as mockSystemInfo } from '../data/content';
import { formatUptime, useSystemMetrics } from '../hooks/useSystemMetrics';

const EASE = [0.23, 1, 0.32, 1] as const;

const stateTone = {
  ok: { dot: 'bg-ok', text: 'text-mist-200' },
  busy: { dot: 'bg-accent', text: 'text-accent' },
  warn: { dot: 'bg-warn', text: 'text-warn' }
};

interface SystemProps {
  onBack?: () => void;
  onOpenNetwork: () => void;
}

interface MetricCard {
  id: string;
  code: string;
  label: string;
  value: number;
  display: string;
  detail: string;
}

export function System({ onBack, onOpenNetwork }: SystemProps) {
  const [checked, setChecked] = useState<string | null>(null);
  const live = useSystemMetrics(3000);
  const isLive = live !== null;

  const runCheck = () => {
    setChecked(new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }));
  };

  const cards: MetricCard[] = useMemo(() => {
    if (!live) {
      return mockMetrics.map((m) => ({
        id: m.id,
        code: m.code,
        label: m.label,
        value: m.value,
        display: m.display,
        detail: m.detail
      }));
    }
    return [
      {
        id: 'cpu',
        code: 'CPU',
        label: 'CPU',
        value: live.cpu,
        display: `${live.cpu.toFixed(0)} %`,
        detail: `Last ${live.load_avg_1.toFixed(2)} · 5 min ${live.load_avg_5.toFixed(2)} · 15 min ${live.load_avg_15.toFixed(2)}`
      },
      {
        id: 'ram',
        code: 'RAM',
        label: 'Speicher',
        value: live.ram,
        display: `${live.ram.toFixed(0)} %`,
        detail: `${live.ram_used_gb.toFixed(1)} / ${live.ram_total_gb.toFixed(1)} GB belegt`
      },
      {
        id: 'temp',
        code: 'TEMP',
        label: 'Temperatur',
        value: live.temperature_c ?? 0,
        display: live.temperature_c !== null ? `${live.temperature_c.toFixed(1)} °C` : '—',
        detail: live.temperature_c !== null
          ? live.temperature_c > 75
            ? 'Gehäuse wird warm'
            : 'Kühlung ausreichend'
          : 'Sensor nicht verfügbar'
      },
      {
        id: 'disk',
        code: 'SPEICHER',
        label: 'Datenträger',
        value: live.disk,
        display: `${live.disk.toFixed(0)} %`,
        detail: `${live.disk_used_gb.toFixed(1)} / ${live.disk_total_gb.toFixed(1)} GB belegt`
      },
      {
        id: 'uptime',
        code: 'LAUFZEIT',
        label: 'Uptime',
        value: 100,
        display: formatUptime(live.uptime_seconds),
        detail: `Seit dem letzten Neustart · ${live.hostname}`
      },
      {
        id: 'network',
        code: 'NETZ',
        label: 'Netzwerk',
        value: 88,
        display: 'Online',
        detail: 'Ingress · WLAN aktiv'
      }
    ];
  }, [live]);

  const info = useMemo(() => {
    if (!live) return mockSystemInfo;
    return [
      { label: 'Laufzeit', value: formatUptime(live.uptime_seconds) },
      { label: 'Hostname', value: live.hostname },
      { label: 'Plattform', value: live.platform.split('-with-')[0] },
      { label: 'Letzte Messung', value: new Date(live.timestamp).toLocaleTimeString('de-DE') }
    ];
  }, [live]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="System"
        meta={
          checked
            ? `Dienste geprüft · ${checked}`
            : isLive
            ? 'Live · alles in Ordnung'
            : 'Alles in Ordnung'
        }
        onBack={onBack}
        action={
          <TouchButton onClick={runCheck} icon={<RefreshCwIcon className="h-3.5 w-3.5" strokeWidth={1.7} />}>
            Dienste prüfen
          </TouchButton>
        }
      />

      <ScrollArea className="px-6 pb-5">
        <div className="grid grid-cols-3 gap-4">
          {cards.map((m, i) => {
            const inner = (
              <>
                <div className="flex items-baseline justify-between">
                  <span className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                    {m.code}
                  </span>
                  <span className="tabular font-mono text-[10px] text-mist-500">
                    {m.id === 'temp' || m.id === 'uptime' || m.id === 'network' ? '' : `${Math.round(m.value)} %`}
                  </span>
                </div>
                <p className="tabular mt-3 text-[24px] font-extralight leading-none tracking-tight text-mist-50">
                  {m.display}
                </p>
                <div className="mt-3.5 h-[3px] overflow-hidden rounded-full bg-white/[0.07]">
                  <motion.div
                    className={`h-full rounded-full ${m.value > 80 ? 'bg-warn' : 'bg-accent/75'}`}
                    initial={false}
                    animate={{ width: `${Math.min(100, Math.max(0, m.value))}%` }}
                    transition={{ duration: 0.5, ease: EASE }}
                  />
                </div>
                <p className="mt-2.5 text-[11px] font-light text-mist-500">{m.detail}</p>
              </>
            );

            return (
              <motion.div
                key={m.id}
                data-testid={`sys-metric-${m.id}`}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, ease: EASE, delay: i * 0.035 }}
              >
                {m.id === 'network' ? (
                  <TouchCard onPress={onOpenNetwork} label="Netzwerk öffnen" className="px-5 py-4">
                    {inner}
                  </TouchCard>
                ) : (
                  <Panel className="px-5 py-4">{inner}</Panel>
                )}
              </motion.div>
            );
          })}
        </div>

        <Panel title="Dienste" className="mt-4 px-5 pb-4">
          <div className="grid grid-cols-4 gap-4 pt-1">
            {services.map((s) => {
              const tone = stateTone[s.state];
              return (
                <div
                  key={s.id}
                  className="border border-white/[0.04] px-4 py-3.5"
                  style={{ borderRadius: 'calc(var(--radius) * 0.75)' }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`h-1.5 w-1.5 rounded-full ${tone.dot}`} aria-hidden="true" />
                      <span className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                        {s.code}
                      </span>
                    </div>
                    {checked && (
                      <CheckIcon className="h-3 w-3 text-ok" strokeWidth={2.2} aria-hidden="true" />
                    )}
                  </div>
                  <p className={`mt-2.5 text-[14px] font-light leading-none ${tone.text}`}>{s.value}</p>
                  <p className="mt-2 truncate text-[10.5px] font-light text-mist-600">{s.detail}</p>
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel title={isLive ? 'Gerät · live' : 'Gerät'} className="mt-4 px-5 pb-4">
          <div className="flex flex-wrap items-center gap-x-10 gap-y-3 pt-1">
            {info.map((s) => (
              <div key={s.label}>
                <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                  {s.label}
                </p>
                <p className="mt-1.5 text-[13px] font-light leading-none text-mist-200">{s.value}</p>
              </div>
            ))}
          </div>
        </Panel>
      </ScrollArea>
    </div>
  );
}
