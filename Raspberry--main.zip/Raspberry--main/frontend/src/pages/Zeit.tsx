import React, { useEffect, useState } from 'react';
import { ScreenHeader } from '../components/ScreenHeader';
import { Panel } from '../components/Panel';
import { Segmented } from '../components/controls/Segmented';
import { clockInfo, stats } from '../data/content';
import { useSettings } from '../contexts/SettingsContext';

export function Zeit({ onBack }: {onBack: () => void;}) {
  const { settings, set } = useSettings();
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const time = now.toLocaleTimeString('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: settings.timeFormat === '12 h'
  });
  const seconds = now.toLocaleTimeString('de-DE', { second: '2-digit' });
  const long = now.toLocaleDateString('de-DE', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Zeit & Datum" meta={clockInfo.timezone} onBack={onBack} />

      <div className="flex min-h-0 flex-1 gap-4 px-6 pb-5">
        <Panel className="flex min-w-0 flex-1 flex-col justify-center px-8 py-6">
          <div className="flex items-end gap-3">
            <p className="tabular text-[104px] font-extralight leading-none tracking-tighter text-mist-50">
              {time}
            </p>
            <p className="tabular pb-3 font-mono text-[20px] font-light text-mist-600">{seconds}</p>
          </div>
          <p className="mt-5 text-[16px] font-light text-mist-300">{long}</p>
          <div className="mt-6 flex items-center gap-8 border-t border-white/[0.04] pt-4">
            {[
            { label: 'Zeitzone', value: clockInfo.timezone },
            { label: 'Synchronisierung', value: clockInfo.sync },
            { label: 'Laufzeit', value: clockInfo.uptime }].
            map((f) =>
            <div key={f.label}>
                <p className="font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                  {f.label}
                </p>
                <p className="mt-1.5 text-[12px] font-light leading-none text-mist-200">{f.value}</p>
              </div>
            )}
          </div>
        </Panel>

        <div className="flex w-[320px] shrink-0 flex-col gap-4">
          <Panel title="Anzeige" className="px-[18px] pb-4">
            <div className="space-y-4 pt-1">
              <div>
                <p className="mb-2.5 text-[12.5px] font-light text-mist-300">Zeitformat</p>
                <Segmented
                  id="zeit-time"
                  wide
                  value={settings.timeFormat}
                  onChange={(v) => set('timeFormat', v)}
                  options={[
                  { value: '24 h', label: '24 h' },
                  { value: '12 h', label: '12 h' }]
                  } />
                
              </div>
              <div>
                <p className="mb-2.5 text-[12.5px] font-light text-mist-300">Datumsformat</p>
                <Segmented
                  id="zeit-date"
                  wide
                  value={settings.dateFormat}
                  onChange={(v) => set('dateFormat', v)}
                  options={[
                  { value: 'TT.MM.JJJJ', label: 'TT.MM.JJJJ' },
                  { value: 'JJJJ-MM-TT', label: 'JJJJ-MM-TT' }]
                  } />
                
              </div>
            </div>
          </Panel>

          <Panel title="Zeitplan" className="min-h-0 flex-1 px-[18px] pb-4">
            <div className="divide-y divide-white/[0.04] pt-1">
              {[
              { label: 'Nächster Upload', value: stats.nextUpload },
              { label: 'Uploadzeiten', value: settings.publishTimes.join(' · ') || 'keine' },
              { label: 'Videos pro Tag', value: String(settings.perDay) },
              { label: 'Letzte Sync', value: clockInfo.lastSync }].
              map((r) =>
              <div key={r.label} className="flex items-center justify-between py-3">
                  <span className="text-[12.5px] font-light text-mist-400">{r.label}</span>
                  <span className="tabular font-mono text-[11px] text-mist-200">{r.value}</span>
                </div>
              )}
            </div>
          </Panel>
        </div>
      </div>
    </div>);

}