import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BotIcon,
  CpuIcon,
  FilmIcon,
  InfoIcon,
  MonitorIcon,
  PaletteIcon,
  SlidersHorizontalIcon,
  SparklesIcon,
  WifiIcon } from
'lucide-react';
import { ScreenHeader } from '../components/ScreenHeader';
import { ScrollArea } from '../components/ScrollArea';
import { SettingsGeneral } from './settings/SettingsGeneral';
import { SettingsAppearance } from './settings/SettingsAppearance';
import { SettingsDisplay } from './settings/SettingsDisplay';
import { SettingsRobot } from './settings/SettingsRobot';
import { SettingsAi } from './settings/SettingsAi';
import { SettingsContent } from './settings/SettingsContent';
import { SettingsNetwork } from './settings/SettingsNetwork';
import { SettingsSystem } from './settings/SettingsSystem';
import { SettingsAbout } from './settings/SettingsAbout';
import { useAttention } from '../contexts/AttentionContext';

const EASE = [0.23, 1, 0.32, 1] as const;

type SectionId =
'general' |
'appearance' |
'display' |
'robot' |
'ai' |
'content' |
'network' |
'system' |
'about';

const sections: {id: SectionId;label: string;Icon: typeof BotIcon;}[] = [
{ id: 'general', label: 'Allgemein', Icon: SlidersHorizontalIcon },
{ id: 'appearance', label: 'Darstellung', Icon: PaletteIcon },
{ id: 'display', label: 'Display', Icon: MonitorIcon },
{ id: 'robot', label: 'Roboter', Icon: BotIcon },
{ id: 'ai', label: 'KI', Icon: SparklesIcon },
{ id: 'content', label: 'Inhalte', Icon: FilmIcon },
{ id: 'network', label: 'Netzwerk', Icon: WifiIcon },
{ id: 'system', label: 'System', Icon: CpuIcon },
{ id: 'about', label: 'Über', Icon: InfoIcon }];


interface SettingsProps {
  onBack: () => void;
  onOpenNetwork: () => void;
}

export function Settings({ onBack, onOpenNetwork }: SettingsProps) {
  const [section, setSection] = useState<SectionId>('appearance');
  const { lookAt } = useAttention();

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="Einstellungen"
        meta={sections.find((s) => s.id === section)?.label}
        onBack={onBack} />
      

      <div className="flex min-h-0 flex-1 gap-4 px-6 pb-5">
        <nav aria-label="Bereiche" className="flex w-[172px] shrink-0 flex-col gap-1">
          {sections.map(({ id, label, Icon }) => {
            const active = id === section;
            return (
              <motion.button
                key={id}
                type="button"
                data-testid={`settings-nav-${id}`}
                onPointerDown={(ev) => lookAt(ev.currentTarget)}
                onClick={() => setSection(id)}
                whileTap={{ scale: 0.975 }}
                transition={{ duration: 0.12, ease: EASE }}
                aria-current={active ? 'true' : undefined}
                className="relative flex h-[42px] items-center gap-3 px-4 outline-none focus-visible:ring-1 focus-visible:ring-accent/60"
                style={{ borderRadius: 'calc(var(--radius) * 0.7)' }}>
                
                {active &&
                <motion.span
                  layoutId="settings-nav"
                  className="absolute inset-0 border border-white/[0.05] bg-white/[0.055]"
                  style={{ borderRadius: 'calc(var(--radius) * 0.7)' }}
                  transition={{ duration: 0.26, ease: EASE }} />

                }
                <Icon
                  className={`relative h-[16px] w-[16px] ${active ? 'text-accent' : 'text-mist-600'}`}
                  strokeWidth={1.6}
                  aria-hidden="true" />
                
                <span
                  className={`relative text-[12.5px] font-light ${active ? 'text-mist-50' : 'text-mist-500'}`}>
                  
                  {label}
                </span>
              </motion.button>);

          })}
        </nav>

        <div className="flex min-h-0 flex-1 flex-col">
          <AnimatePresence mode="wait">
            <motion.div
              key={section}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: EASE }}
              className="flex min-h-0 flex-1 flex-col">
              
              <ScrollArea className="pr-3">
                <div className="space-y-4 pb-2">
                  {section === 'general' && <SettingsGeneral />}
                  {section === 'appearance' && <SettingsAppearance />}
                  {section === 'display' && <SettingsDisplay />}
                  {section === 'robot' && <SettingsRobot />}
                  {section === 'ai' && <SettingsAi />}
                  {section === 'content' && <SettingsContent />}
                  {section === 'network' && <SettingsNetwork onOpenNetwork={onOpenNetwork} />}
                  {section === 'system' && <SettingsSystem />}
                  {section === 'about' && <SettingsAbout />}
                </div>
              </ScrollArea>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>);

}