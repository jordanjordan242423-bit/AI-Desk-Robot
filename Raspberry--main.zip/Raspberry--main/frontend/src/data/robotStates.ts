import type { Expression, RobotMood, RobotStateDef, StateId } from '../types/robot';

export const robotStates: Record<StateId, RobotStateDef> = {
  bereit: {
    id: 'bereit',
    label: 'Bereit',
    lines: {
      sachlich: 'Bereit.',
      freundlich: 'Alles läuft. Ich warte auf die nächste Aufgabe.',
      verspielt: 'Bereit. Und ein bisschen neugierig.'
    },
    short: { sachlich: 'Bereit.', freundlich: 'Alles läuft.', verspielt: 'Was soll ich machen?' },
    mood: 'idle',
    tone: 'neutral',
    duration: 5600
  },
  recherche: {
    id: 'recherche',
    label: 'Recherche',
    lines: {
      sachlich: 'Recherche läuft.',
      freundlich: 'Ich suche gerade nach einem interessanten Thema.',
      verspielt: 'Ich stöbere ein bisschen herum.'
    },
    short: { sachlich: 'Recherche', freundlich: 'Ich suche etwas.', verspielt: 'Stöbern!' },
    mood: 'searching',
    tone: 'accent',
    duration: 7000
  },
  denken: {
    id: 'denken',
    label: 'Bewertung',
    lines: {
      sachlich: 'Thema wird bewertet.',
      freundlich: 'Ich prüfe, ob das Thema geeignet ist.',
      verspielt: 'Hmm … ist das gut genug?'
    },
    short: { sachlich: 'Bewertung', freundlich: 'Moment …', verspielt: 'Hmm …' },
    mood: 'thinking',
    tone: 'accent',
    duration: 5200
  },
  fakten: {
    id: 'fakten',
    label: 'Faktencheck',
    lines: {
      sachlich: 'Faktencheck läuft.',
      freundlich: 'Ich prüfe das noch einmal.',
      verspielt: 'Doppelt geprüft hält besser.'
    },
    short: { sachlich: 'Faktencheck', freundlich: 'Ich prüfe das.', verspielt: 'Kontrolle!' },
    mood: 'thinking',
    tone: 'accent',
    duration: 5200
  },
  schreiben: {
    id: 'schreiben',
    label: 'Skript',
    lines: {
      sachlich: 'Skript wird geschrieben.',
      freundlich: 'Ich erstelle das Skript.',
      verspielt: 'Ich tippe wie verrückt.'
    },
    short: { sachlich: 'Skript', freundlich: 'Ich schreibe.', verspielt: 'Tipp, tipp …' },
    mood: 'writing',
    tone: 'accent',
    duration: 6400
  },
  sprache: {
    id: 'sprache',
    label: 'Sprache',
    lines: {
      sachlich: 'Sprachausgabe wird erzeugt.',
      freundlich: 'Ich erzeuge die deutsche Stimme.',
      verspielt: 'Test, test … klingt gut.'
    },
    short: { sachlich: 'Sprache', freundlich: 'Ich spreche.', verspielt: 'Test, test …' },
    mood: 'speaking',
    tone: 'accent',
    duration: 6000
  },
  medien: {
    id: 'medien',
    label: 'Medien',
    lines: {
      sachlich: 'Medien werden gesucht.',
      freundlich: 'Ich suche passende Aufnahmen.',
      verspielt: 'Oh, das sieht gut aus!'
    },
    short: { sachlich: 'Medien', freundlich: 'Ich suche Bilder.', verspielt: 'Oh, schön!' },
    mood: 'curious',
    tone: 'accent',
    duration: 5200
  },
  video: {
    id: 'video',
    label: 'Rendern',
    lines: {
      sachlich: 'Rendering läuft.',
      freundlich: 'Ich erstelle dein Video.',
      verspielt: 'Ich bastle es zusammen.'
    },
    short: { sachlich: 'Rendern', freundlich: 'Ich baue dein Video.', verspielt: 'Basteln!' },
    mood: 'rendering',
    tone: 'accent',
    duration: 8000
  },
  qualitaet: {
    id: 'qualitaet',
    label: 'Qualität',
    lines: {
      sachlich: 'Qualitätsprüfung läuft.',
      freundlich: 'Ich prüfe das fertige Video.',
      verspielt: 'Kurz drüberschauen …'
    },
    short: { sachlich: 'Qualität', freundlich: 'Letzter Blick.', verspielt: 'Kurz prüfen …' },
    mood: 'thinking',
    tone: 'accent',
    duration: 4800
  },
  upload: {
    id: 'upload',
    label: 'Upload',
    lines: {
      sachlich: 'Video wird hochgeladen.',
      freundlich: 'Das Video wird veröffentlicht.',
      verspielt: 'Ab damit ins Netz!'
    },
    short: { sachlich: 'Upload', freundlich: 'Ich lade hoch.', verspielt: 'Ab ins Netz!' },
    mood: 'upload',
    tone: 'accent',
    duration: 6400
  },
  fertig: {
    id: 'fertig',
    label: 'Fertig',
    lines: {
      sachlich: 'Aufgabe abgeschlossen.',
      freundlich: 'Dein Video ist bereit.',
      verspielt: 'Fertig! Schau mal rein.'
    },
    short: { sachlich: 'Fertig.', freundlich: 'Alles erledigt.', verspielt: 'Tada!' },
    mood: 'success',
    tone: 'accent',
    duration: 6000
  },
  fehler: {
    id: 'fehler',
    label: 'Fehler',
    lines: {
      sachlich: 'Fehler aufgetreten.',
      freundlich: 'Da ist etwas schiefgelaufen. Ich versuche es noch einmal.',
      verspielt: 'Ups. Das war nicht geplant.'
    },
    short: { sachlich: 'Fehler', freundlich: 'Etwas lief schief.', verspielt: 'Ups …' },
    mood: 'error',
    tone: 'warn',
    duration: 7000
  }
};

/** The autonomous loop the robot walks through on its own. */
export const pipeline: StateId[] = [
'bereit',
'recherche',
'denken',
'fakten',
'schreiben',
'sprache',
'medien',
'video',
'qualitaet',
'upload',
'fertig'];


export interface ProcessStep {
  id: string;
  label: string;
  code: string;
  hint: string;
  detail: string;
  states: StateId[];
}

/** The full eight stage pipeline. */
export const processSteps: ProcessStep[] = [
{
  id: 'research',
  label: 'Recherche',
  code: 'RESEARCH',
  hint: 'Thema suchen und bewerten',
  detail: 'Ich suche nach einem interessanten Thema und prüfe, ob es geeignet ist.',
  states: ['recherche', 'denken']
},
{
  id: 'fact',
  label: 'Faktencheck',
  code: 'FACT CHECK',
  hint: 'Quellen verifizieren',
  detail: 'Ich prüfe jede Aussage gegen mehrere unabhängige Quellen.',
  states: ['fakten']
},
{
  id: 'script',
  label: 'Skript',
  code: 'SCRIPT',
  hint: 'Text schreiben',
  detail: 'Ich erstelle das Skript mit Einstieg, Erklärung und Abschluss.',
  states: ['schreiben']
},
{
  id: 'tts',
  label: 'Sprache',
  code: 'TTS',
  hint: 'Stimme erzeugen',
  detail: 'Ich erzeuge die deutsche Stimme, lokal und mit passender Betonung.',
  states: ['sprache']
},
{
  id: 'media',
  label: 'Medien',
  code: 'MEDIA',
  hint: 'Aufnahmen finden',
  detail: 'Ich suche passende Aufnahmen und schneide sie auf die Sprachspur.',
  states: ['medien']
},
{
  id: 'render',
  label: 'Rendern',
  code: 'RENDER',
  hint: 'Video bauen',
  detail: 'Ich erstelle dein Video in 1080 × 1920 mit Untertiteln und Tonmischung.',
  states: ['video']
},
{
  id: 'quality',
  label: 'Qualität',
  code: 'QUALITY CHECK',
  hint: 'Ergebnis prüfen',
  detail: 'Ich prüfe das fertige Video auf Bildfehler, Lautheit und Untertitel.',
  states: ['qualitaet']
},
{
  id: 'upload',
  label: 'Upload',
  code: 'UPLOAD',
  hint: 'Veröffentlichen',
  detail: 'Das Video wird veröffentlicht, mit Titel, Beschreibung und Hashtags.',
  states: ['upload', 'fertig']
}];


export function activeStep(state: StateId): number {
  return processSteps.findIndex((s) => s.states.includes(state));
}

/** Compact four stage summary used next to the robot on the home screen. */
export const trail: {label: string;steps: number[];}[] = [
{ label: 'Thema', steps: [0, 1] },
{ label: 'Skript', steps: [2, 3] },
{ label: 'Video', steps: [4, 5, 6] },
{ label: 'Upload', steps: [7] }];


/* Face geometry lives in a 280 × 320 viewBox; the mouth sits around 140 / 128. */
export const expressions: Record<RobotMood, Expression> = {
  idle: { eyeW: 30, eyeH: 30, dy: 0, gaze: 'still', mouth: 'M127 126 Q140 135 153 126' },
  searching: { eyeW: 28, eyeH: 31, dy: 0, gaze: 'scan', mouth: 'M129 128 Q140 132 151 128' },
  thinking: { eyeW: 30, eyeH: 12, dy: -2, gaze: 'up', mouth: 'M130 129 Q140 129 150 129', tilt: 3 },
  writing: { eyeW: 28, eyeH: 18, dy: 2, gaze: 'down', mouth: 'M129 127 Q140 131 151 127' },
  speaking: {
    eyeW: 30,
    eyeH: 27,
    dy: 0,
    gaze: 'still',
    mouth: 'M125 125 Q140 138 155 125',
    talk: true
  },
  media: { eyeW: 33, eyeH: 34, dy: 0, gaze: 'still', mouth: 'M125 124 Q140 137 155 124' },
  curious: {
    eyeW: 33,
    eyeH: 35,
    dy: -1,
    gaze: 'scan',
    mouth: 'M128 126 Q140 135 152 126',
    tilt: 6
  },
  rendering: { eyeW: 30, eyeH: 15, dy: 0, gaze: 'still', mouth: 'M130 129 Q140 130 150 129' },
  success: {
    eyeW: 30,
    eyeH: 30,
    dy: 0,
    gaze: 'still',
    mouth: 'M123 122 Q140 141 157 122',
    arcEyes: true
  },
  error: {
    eyeW: 28,
    eyeH: 20,
    dy: 3,
    gaze: 'down',
    mouth: 'M128 132 Q140 125 152 132',
    brow: true,
    tilt: -4
  },
  waiting: { eyeW: 28, eyeH: 24, dy: 0, gaze: 'still', mouth: 'M128 127 Q140 132 152 127' },
  upload: { eyeW: 28, eyeH: 28, dy: -1, gaze: 'up', mouth: 'M128 126 Q140 133 152 126' },
  sleeping: {
    eyeW: 30,
    eyeH: 4,
    dy: 7,
    gaze: 'down',
    mouth: 'M133 129 Q140 132 147 129',
    tilt: -5
  }
};

/** Resting mouth shapes, chosen by how much the personality smiles. */
export const restMouths = {
  flat: 'M130 129 Q140 131 150 129',
  soft: 'M128 127 Q140 134 152 127',
  smile: 'M125 124 Q140 138 155 124'
};