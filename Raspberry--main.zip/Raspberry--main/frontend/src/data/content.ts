export type VideoStatus = 'veröffentlicht' | 'bereit' | 'rendert' | 'fehler';

export interface VideoItem {
  id: string;
  title: string;
  thumb: string;
  duration: string;
  status: VideoStatus;
  date: string;
  upload: 'online' | 'geplant' | 'wartet' | 'fehlgeschlagen';
  uploadNote: string;
  views: string;
  resolution: string;
  size: string;
  words: number;
  sources: number;
  topic: string;
  description: string;
  hashtags: string[];
  excerpt: string;
}

const SKY = "/c19df73e-99cc-4076-b8c4-a433c79607a1.jpg";
const SSD = "/0f3a0544-ca23-479b-be99-d1b26b9d50b5.jpg";
const SLEEP = "/49bb22bd-9313-49ef-a6d7-be4b3a430747.jpg";
const HOLE = "/fbc6ce58-e58d-4797-80f6-86d64bf6e35b.jpg";

export const videos: VideoItem[] = [
{
  id: 'v-108',
  title: 'Warum ist der Himmel blau?',
  thumb: SKY,
  duration: '0:48',
  status: 'veröffentlicht',
  date: 'Heute, 14:20',
  upload: 'online',
  uploadNote: 'TikTok · 14:22',
  views: '24,8 Tsd.',
  resolution: '1080 × 1920',
  size: '31,4 MB',
  words: 148,
  sources: 6,
  topic: 'Wissenschaft',
  description:
  'Blaues Licht wird in der Luft viel stärker gestreut als rotes. Deshalb kommt es aus allen Richtungen des Himmels zu dir.',
  hashtags: ['#wissen', '#himmel', '#physik', '#erklärt'],
  excerpt:
  'Sonnenlicht ist weiß — aber es ist ein Gemisch aus allen Farben. In der Luft wird blaues Licht viel stärker gestreut als rotes …'
},
{
  id: 'v-107',
  title: 'Wie funktioniert eine SSD?',
  thumb: SSD,
  duration: '0:52',
  status: 'bereit',
  date: 'Heute, 11:05',
  upload: 'geplant',
  uploadNote: 'Geplant für 20:00',
  views: '—',
  resolution: '1080 × 1920',
  size: '34,1 MB',
  words: 161,
  sources: 5,
  topic: 'Technik & KI',
  description:
  'Keine beweglichen Teile, nur Ladung in Milliarden winziger Zellen. Warum das so schnell ist — in unter einer Minute.',
  hashtags: ['#technik', '#ssd', '#computer', '#erklärt'],
  excerpt:
  'Eine SSD hat keine beweglichen Teile. Statt Magnetscheiben speichert sie Bits als Ladung in Milliarden winziger Zellen …'
},
{
  id: 'v-106',
  title: 'Warum schlafen wir?',
  thumb: SLEEP,
  duration: '0:44',
  status: 'veröffentlicht',
  date: 'Gestern, 20:00',
  upload: 'online',
  uploadNote: 'TikTok · gestern, 20:01',
  views: '61,2 Tsd.',
  resolution: '1080 × 1920',
  size: '28,7 MB',
  words: 139,
  sources: 7,
  topic: 'Psychologie',
  description:
  'Im Schlaf räumt das Gehirn auf: Abfallstoffe raus, Erinnerungen sortieren, Immunsystem neu einstellen.',
  hashtags: ['#schlaf', '#gehirn', '#wissen'],
  excerpt:
  'Im Schlaf räumt das Gehirn auf. Es spült Abfallstoffe aus, sortiert Erinnerungen und stellt das Immunsystem neu ein …'
},
{
  id: 'v-105',
  title: 'Was passiert in einem Schwarzen Loch?',
  thumb: HOLE,
  duration: '0:57',
  status: 'rendert',
  date: 'Gestern, 17:40',
  upload: 'wartet',
  uploadNote: 'Nach dem Rendern',
  views: '—',
  resolution: '1080 × 1920',
  size: '—',
  words: 172,
  sources: 8,
  topic: 'Raumfahrt',
  description:
  'Ab dem Ereignishorizont führt jeder Weg nach innen — selbst für Licht. Was das wirklich bedeutet.',
  hashtags: ['#weltraum', '#physik', '#schwarzesloch'],
  excerpt:
  'Ab dem Ereignishorizont führt jeder Weg nach innen. Selbst Licht findet keine Richtung mehr, die hinausführt …'
},
{
  id: 'v-104',
  title: 'Wie entsteht ein Polarlicht?',
  thumb: SKY,
  duration: '0:51',
  status: 'veröffentlicht',
  date: 'Mi, 20:00',
  upload: 'online',
  uploadNote: 'TikTok · Mi, 20:02',
  views: '18,3 Tsd.',
  resolution: '1080 × 1920',
  size: '33,0 MB',
  words: 154,
  sources: 6,
  topic: 'Natur & Tiere',
  description:
  'Teilchen der Sonne treffen das Magnetfeld der Erde, werden zu den Polen gelenkt und bringen die Luft zum Leuchten.',
  hashtags: ['#natur', '#polarlicht', '#wissen'],
  excerpt:
  'Teilchen der Sonne treffen auf das Magnetfeld der Erde und werden zu den Polen gelenkt. Dort bringen sie die Luft zum Leuchten …'
},
{
  id: 'v-103',
  title: 'Warum rostet Edelstahl nicht?',
  thumb: SSD,
  duration: '0:46',
  status: 'veröffentlicht',
  date: 'Mi, 13:15',
  upload: 'online',
  uploadNote: 'TikTok · Mi, 13:17',
  views: '9,7 Tsd.',
  resolution: '1080 × 1920',
  size: '29,8 MB',
  words: 142,
  sources: 4,
  topic: 'Wissenschaft',
  description:
  'Chrom bildet eine unsichtbare Schutzschicht, die sich nach jeder Beschädigung in Sekunden selbst erneuert.',
  hashtags: ['#chemie', '#alltag', '#wissen'],
  excerpt:
  'Das Chrom im Stahl bildet eine unsichtbare Schutzschicht. Wird sie beschädigt, baut sie sich innerhalb von Sekunden neu auf …'
},
{
  id: 'v-102',
  title: 'Was träumen Tiere?',
  thumb: SLEEP,
  duration: '0:49',
  status: 'fehler',
  date: 'Di, 20:00',
  upload: 'fehlgeschlagen',
  uploadNote: 'Tonspur fehlerhaft',
  views: '—',
  resolution: '1080 × 1920',
  size: '30,2 MB',
  words: 147,
  sources: 5,
  topic: 'Natur & Tiere',
  description:
  'Ratten wiederholen im Schlaf ganze Laufwege — ihre Nervenzellen feuern in derselben Reihenfolge wie beim Laufen.',
  hashtags: ['#tiere', '#schlaf', '#forschung'],
  excerpt:
  'Ratten wiederholen im Schlaf ganze Laufwege. Ihre Nervenzellen feuern in derselben Reihenfolge wie beim Laufen …'
},
{
  id: 'v-101',
  title: 'Wie schwer ist Licht?',
  thumb: HOLE,
  duration: '0:55',
  status: 'veröffentlicht',
  date: 'Di, 11:40',
  upload: 'online',
  uploadNote: 'TikTok · Di, 11:42',
  views: '42,1 Tsd.',
  resolution: '1080 × 1920',
  size: '35,6 MB',
  words: 165,
  sources: 6,
  topic: 'Raumfahrt',
  description:
  'Licht hat keine Masse, aber Impuls. Deshalb kann ein Sonnensegel ein Raumschiff wirklich beschleunigen.',
  hashtags: ['#physik', '#weltraum', '#licht'],
  excerpt:
  'Licht hat keine Masse — aber Impuls. Deshalb kann ein Sonnensegel ein Raumschiff tatsächlich beschleunigen …'
}];


export interface TopicItem {
  id: string;
  title: string;
  status: 'geplant' | 'in Arbeit' | 'geprüft' | 'verworfen';
  score: number;
  date: string;
  category: string;
  sources: number;
  verified: 'bestätigt' | 'offen' | 'widersprüchlich';
  picked: boolean;
  note: string;
}

export const topics: TopicItem[] = [
{ id: 't-1', title: 'Warum träumen wir in Farben?', status: 'in Arbeit', score: 94, date: 'Heute, 16:12', category: 'Psychologie', sources: 7, verified: 'bestätigt', picked: true, note: 'Starke Frage, selten erklärt, gute Quellenlage.' },
{ id: 't-2', title: 'Wie entsteht ein Polarlicht?', status: 'geprüft', score: 88, date: 'Heute, 15:40', category: 'Natur & Tiere', sources: 6, verified: 'bestätigt', picked: false, note: 'Visuell sehr dankbar, viele freie Aufnahmen.' },
{ id: 't-3', title: 'Was macht Beton so stark?', status: 'geplant', score: 76, date: 'Heute, 12:08', category: 'Technik & KI', sources: 5, verified: 'bestätigt', picked: false, note: 'Solide, aber weniger überraschend.' },
{ id: 't-4', title: 'Warum knackt ein Finger?', status: 'geplant', score: 71, date: 'Gestern, 21:30', category: 'Alltag', sources: 4, verified: 'offen', picked: false, note: 'Zwei Studien widersprechen sich leicht.' },
{ id: 't-5', title: 'Wie orientieren sich Zugvögel?', status: 'geprüft', score: 84, date: 'Gestern, 20:10', category: 'Natur & Tiere', sources: 6, verified: 'bestätigt', picked: false, note: 'Magnetsinn ist gut belegt.' },
{ id: 't-6', title: 'Warum ist Salzwasser gefährlich?', status: 'geplant', score: 68, date: 'Gestern, 18:02', category: 'Wissenschaft', sources: 3, verified: 'offen', picked: false, note: 'Quellen dünn, braucht mehr Recherche.' },
{ id: 't-7', title: 'Was steckt in einem Akku?', status: 'geplant', score: 73, date: 'Mi, 22:14', category: 'Technik & KI', sources: 5, verified: 'bestätigt', picked: false, note: 'Gut erklärbar, viel Material.' },
{ id: 't-8', title: 'Wer hat die Zeitzonen erfunden?', status: 'verworfen', score: 42, date: 'Mi, 19:55', category: 'Geschichte', sources: 2, verified: 'widersprüchlich', picked: false, note: 'Zu trocken für ein kurzes Video.' },
{ id: 't-9', title: 'Warum gibt es Schluckauf?', status: 'verworfen', score: 38, date: 'Mi, 16:30', category: 'Alltag', sources: 2, verified: 'widersprüchlich', picked: false, note: 'Forschung nicht eindeutig.' }];


export const topicTags = [
'Wissenschaft',
'Technik & KI',
'Natur & Tiere',
'Raumfahrt',
'Geschichte',
'Psychologie',
'Alltag',
'Aktuell'];


export const weather = {
  place: 'Sassenburg',
  temp: '18°',
  feels: '17°',
  text: 'Leicht bewölkt',
  rain: '10 %',
  wind: '12 km/h',
  humidity: '64 %',
  pressure: '1018 hPa',
  uv: 'Niedrig',
  sunrise: '06:42',
  sunset: '19:58',
  high: '21°',
  low: '11°',
  hours: [
  { time: '17', temp: '18°', rain: '10 %', sky: 'cloud' as const },
  { time: '18', temp: '17°', rain: '10 %', sky: 'cloud' as const },
  { time: '19', temp: '16°', rain: '20 %', sky: 'rain' as const },
  { time: '20', temp: '15°', rain: '30 %', sky: 'rain' as const },
  { time: '21', temp: '14°', rain: '20 %', sky: 'cloud' as const },
  { time: '22', temp: '13°', rain: '10 %', sky: 'night' as const },
  { time: '23', temp: '12°', rain: '0 %', sky: 'night' as const },
  { time: '00', temp: '12°', rain: '0 %', sky: 'night' as const }],

  days: [
  { day: 'Sa', text: 'Sonnig', high: 22, low: 12, rain: '0 %', sky: 'sun' as const },
  { day: 'So', text: 'Leicht bewölkt', high: 21, low: 12, rain: '10 %', sky: 'cloud' as const },
  { day: 'Mo', text: 'Regen', high: 17, low: 10, rain: '70 %', sky: 'rain' as const },
  { day: 'Di', text: 'Bewölkt', high: 16, low: 9, rain: '30 %', sky: 'cloud' as const },
  { day: 'Mi', text: 'Sonnig', high: 19, low: 8, rain: '0 %', sky: 'sun' as const }]

};

export const week = [
{ day: 'Mo', count: 2 },
{ day: 'Di', count: 3 },
{ day: 'Mi', count: 1 },
{ day: 'Do', count: 4 },
{ day: 'Fr', count: 3 },
{ day: 'Sa', count: 0 },
{ day: 'So', count: 1 }];


export const stats = {
  heute: 3,
  woche: 14,
  gesamt: 128,
  geplant: 3,
  erfolgreich: 126,
  erfolgsquote: '96 %',
  fehler: 2,
  upload: '12 von 14',
  hochgeladen: 121,
  nextUpload: '20:00'
};

export const activity = [
{ time: '16:12', text: 'Thema „Warum träumen wir in Farben?" ausgewählt' },
{ time: '15:48', text: 'Video „Warum ist der Himmel blau?" veröffentlicht' },
{ time: '15:02', text: 'Skript geschrieben · 148 Wörter' },
{ time: '14:31', text: 'Sprachausgabe erzeugt · de-DE' },
{ time: '13:57', text: '18 Aufnahmen gefunden und geprüft' },
{ time: '12:40', text: 'Rendering abgeschlossen · 1080×1920' },
{ time: '11:05', text: 'Video „Wie funktioniert eine SSD?" bereit' },
{ time: '09:22', text: 'Faktencheck bestanden · 6 Quellen' }];


export interface Metric {
  id: string;
  label: string;
  code: string;
  value: number;
  display: string;
  detail: string;
}

export const metrics: Metric[] = [
{ id: 'cpu', label: 'CPU', code: 'CPU', value: 24, display: '24 %', detail: '4 Kerne · 1,8 GHz' },
{ id: 'ram', label: 'RAM', code: 'RAM', value: 38, display: '3,0 / 8 GB', detail: '38 % belegt' },
{ id: 'gpu', label: 'GPU', code: 'GPU', value: 61, display: '61 %', detail: 'Rendering aktiv' },
{ id: 'temp', label: 'Temperatur', code: 'TEMPERATURE', value: 48, display: '48 °C', detail: 'Lüfter 32 %' },
{ id: 'storage', label: 'Speicher', code: 'STORAGE', value: 53, display: '112 GB frei', detail: 'NVMe 256 GB' },
{ id: 'network', label: 'Netzwerk', code: 'NETWORK', value: 41, display: '412 Mbit/s', detail: 'WLAN · 5 GHz' }];


export interface ServiceItem {
  id: string;
  label: string;
  code: string;
  value: string;
  detail: string;
  state: 'ok' | 'busy' | 'warn';
}

export const services: ServiceItem[] = [
{ id: 'ollama', label: 'Ollama', code: 'OLLAMA', value: 'llama3', detail: 'Modell geladen · 4,7 GB', state: 'ok' },
{ id: 'tts', label: 'Sprachmodul', code: 'TTS', value: 'de-DE', detail: 'Stimme Nova · bereit', state: 'ok' },
{ id: 'ffmpeg', label: 'FFmpeg', code: 'FFMPEG', value: '6.1', detail: 'Hardware-Encoder aktiv', state: 'ok' },
{ id: 'worker', label: 'Worker', code: 'WORKER', value: '1 Aufgabe', detail: 'Warteschlange leer', state: 'busy' }];


export const network = {
  ssid: 'Heimnetz 5G',
  type: 'WLAN · 802.11ac',
  ip: '192.168.178.42',
  gateway: '192.168.178.1',
  dns: '192.168.178.1',
  mac: 'D8:3A:DD:4F:19:02',
  signal: 82,
  down: '412 Mbit/s',
  up: '96 Mbit/s',
  latency: '14 ms',
  today: '2,4 GB',
  band: '5 GHz'
};

export const systemInfo = [
{ label: 'Laufzeit', value: '6 Tage, 4 Std.' },
{ label: 'Version', value: 'v2.4.1' },
{ label: 'TikTok', value: 'verbunden' },
{ label: 'Letztes Backup', value: 'Heute, 04:00' }];


export const clockInfo = {
  timezone: 'Europe/Berlin (UTC+1)',
  sync: 'NTP · pool.ntp.org',
  lastSync: 'Heute, 04:02',
  uptime: '6 Tage, 4 Std.'
};

export const device = {
  name: 'AI Desk Robot',
  subtitle: 'TikTok Content Center',
  board: 'Raspberry Pi 5',
  model: 'EK-7 Desk Companion',
  serial: 'EK7-2026-004182',
  firmware: 'v2.4.1 (build 5180)'
};