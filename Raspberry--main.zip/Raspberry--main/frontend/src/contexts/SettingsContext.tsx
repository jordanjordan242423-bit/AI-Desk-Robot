import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  accents,
  backgrounds,
  bodyColors,
  defaultSettings,
  densityScale,
  intensityFactor,
  personalities,
  STORAGE_KEY } from
'../types/settings';
import type {
  AccentDef,
  BodyColorDef,
  PersonalityDef,
  Settings } from
'../types/settings';

export interface RobotMotionProfile {
  /** multiplies animation rates — higher is faster */
  speed: number;
  /** multiplies movement distances */
  amplitude: number;
  /** multiplies the pause between eye movements */
  gazeGap: number;
  /** multiplies the pause between expressive idle moments */
  flourishGap: number;
  /** how strongly the resting mouth smiles, 0 … 1 */
  smile: number;
}

interface SettingsValue {
  settings: Settings;
  set: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  reset: () => void;
  accent: AccentDef;
  body: BodyColorDef;
  personality: PersonalityDef;
  eyeHex: string;
  robot: RobotMotionProfile;
  /** Panel brightness as a CSS filter value */
  brightness: number;
}

const SettingsContext = createContext<SettingsValue | null>(null);

function load(): Settings {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultSettings;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return { ...defaultSettings, ...parsed };
  } catch {
    return defaultSettings;
  }
}

export function SettingsProvider({
  children,
  initial



}: {children: React.ReactNode;initial?: Partial<Settings>;}) {
  const [settings, setSettings] = useState<Settings>(() => ({ ...load(), ...initial }));

  const set = useCallback(<K extends keyof Settings,>(key: K, value: Settings[K]) => {
    setSettings((s) => ({ ...s, [key]: value }));
  }, []);

  const reset = useCallback(() => setSettings({ ...defaultSettings, ...initial }), [initial]);

  // Persist every change so nothing is lost between screens or reloads
  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {

      /* storage unavailable — the session still works, it just will not survive a reload */}
  }, [settings]);

  // A slow simulated ambient sensor, so auto brightness is a real behaviour
  useEffect(() => {
    if (!settings.autoBrightness) return;
    const id = window.setInterval(() => {
      const t = Date.now() / 24000;
      const ambient = Math.round(66 + Math.sin(t) * 26);
      setSettings((s) => s.autoBrightness ? { ...s, brightness: ambient } : s);
    }, 3000);
    return () => window.clearInterval(id);
  }, [settings.autoBrightness]);

  const accent = accents[settings.accent];
  const body = bodyColors[settings.bodyColor];
  const personality = personalities[settings.personality];
  const eyeHex = settings.eyeColor === 'auto' ? accent.hex : accents[settings.eyeColor].hex;
  const brightness = 0.34 + settings.brightness / 100 * 0.78;

  useEffect(() => {
    const root = document.documentElement;
    const bg = backgrounds[settings.background];
    Object.entries(bg.ink).forEach(([k, v]) => root.style.setProperty(`--ink-${k}`, v));

    root.style.setProperty('--accent', accent.rgb);
    root.style.setProperty('--accent-soft', accent.softRgb);
    root.style.setProperty('--accent-deep', accent.deepRgb);
    root.style.setProperty('--accent-dim', accent.dimRgb);

    root.style.setProperty('--ui', String(densityScale[settings.density]));
    root.style.setProperty('--radius', `${settings.radius}px`);
    root.style.setProperty('--blur', `${settings.blur}px`);

    const t = settings.transparency / 100;
    root.style.setProperty('--panel-alpha', (0.008 + t * 0.072).toFixed(4));
    root.style.setProperty('--panel-border', (0.022 + t * 0.075).toFixed(4));

    const sh = settings.shadow / 100;
    root.style.setProperty(
      '--shadow',
      `0 1px 0 0 rgba(255,255,255,${(0.02 + sh * 0.045).toFixed(3)}) inset, 0 ${Math.round(
        8 + sh * 24
      )}px ${Math.round(18 + sh * 38)}px -${Math.round(14 + sh * 14)}px rgba(0,0,0,${(
      0.55 + sh * 0.4).
      toFixed(2)})`
    );

    const g = settings.glow / 100;
    root.style.setProperty(
      '--glow',
      `0 0 ${Math.round(6 + g * 34)}px rgb(${accent.rgb} / ${(0.08 + g * 0.38).toFixed(2)})`
    );

    root.setAttribute('data-ui', settings.uiStyle);
  }, [
  settings.background,
  settings.density,
  settings.radius,
  settings.blur,
  settings.transparency,
  settings.shadow,
  settings.glow,
  settings.uiStyle,
  accent]
  );

  const robot = useMemo<RobotMotionProfile>(() => {
    const iF = intensityFactor[settings.animation];
    return {
      speed: personality.speed * (settings.animationSpeed / 100),
      amplitude: personality.amplitude * iF,
      gazeGap: personality.gazeGap / Math.max(0.5, iF),
      flourishGap: personality.flourishGap / Math.max(0.5, iF),
      smile: personality.smile
    };
  }, [personality, settings.animation, settings.animationSpeed]);

  const value = useMemo<SettingsValue>(
    () => ({ settings, set, reset, accent, body, personality, eyeHex, robot, brightness }),
    [settings, set, reset, accent, body, personality, eyeHex, robot, brightness]
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings(): SettingsValue {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used inside SettingsProvider');
  return ctx;
}