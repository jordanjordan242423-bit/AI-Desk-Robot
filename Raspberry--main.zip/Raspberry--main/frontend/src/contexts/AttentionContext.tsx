import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';

export interface Glance {
  x: number;
  y: number;
  key: number;
}

export type ReactionKind = 'nod' | 'excited' | 'surprise';

export interface Reaction {
  kind: ReactionKind;
  key: number;
}

interface AttentionValue {
  /** Where the robot should briefly look, normalised to -1 … 1 */
  glance: Glance | null;
  /** A one-off expressive reaction to something the owner did */
  reaction: Reaction | null;
  look: (x: number, y: number) => void;
  lookAt: (el: Element | null) => void;
  react: (kind: ReactionKind) => void;
  /** Seconds since the last interaction */
  idleSec: number;
  poke: () => void;
}

const AttentionContext = createContext<AttentionValue | null>(null);

export function AttentionProvider({ children }: {children: React.ReactNode;}) {
  const [glance, setGlance] = useState<Glance | null>(null);
  const [reaction, setReaction] = useState<Reaction | null>(null);
  const [idleSec, setIdleSec] = useState(0);
  const last = useRef(Date.now());
  const gKey = useRef(0);
  const rKey = useRef(0);

  const poke = useCallback(() => {
    last.current = Date.now();
    setIdleSec(0);
  }, []);

  const look = useCallback(
    (x: number, y: number) => {
      gKey.current += 1;
      setGlance({
        x: Math.max(-1, Math.min(1, x)),
        y: Math.max(-1, Math.min(1, y)),
        key: gKey.current
      });
      poke();
    },
    [poke]
  );

  const lookAt = useCallback(
    (el: Element | null) => {
      if (!el) {
        poke();
        return;
      }
      const r = el.getBoundingClientRect();
      const cx = (r.left + r.width / 2 - window.innerWidth / 2) / (window.innerWidth / 2);
      const cy = (r.top + r.height / 2 - window.innerHeight / 2) / (window.innerHeight / 2);
      look(cx * 1.2, cy * 1.2);
    },
    [look, poke]
  );

  const react = useCallback(
    (kind: ReactionKind) => {
      rKey.current += 1;
      setReaction({ kind, key: rKey.current });
      poke();
    },
    [poke]
  );

  useEffect(() => {
    const id = window.setInterval(() => {
      setIdleSec(Math.round((Date.now() - last.current) / 1000));
    }, 1000);
    const onAct = () => {
      last.current = Date.now();
    };
    window.addEventListener('pointerdown', onAct);
    window.addEventListener('keydown', onAct);
    window.addEventListener('wheel', onAct, { passive: true });
    return () => {
      window.clearInterval(id);
      window.removeEventListener('pointerdown', onAct);
      window.removeEventListener('keydown', onAct);
      window.removeEventListener('wheel', onAct);
    };
  }, []);

  const value = useMemo(
    () => ({ glance, reaction, look, lookAt, react, idleSec, poke }),
    [glance, reaction, look, lookAt, react, idleSec, poke]
  );

  return <AttentionContext.Provider value={value}>{children}</AttentionContext.Provider>;
}

export function useAttention(): AttentionValue {
  const ctx = useContext(AttentionContext);
  if (!ctx) throw new Error('useAttention must be used inside AttentionProvider');
  return ctx;
}