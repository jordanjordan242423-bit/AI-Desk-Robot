import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeftIcon } from 'lucide-react';
import { useAttention } from '../contexts/AttentionContext';

interface ScreenHeaderProps {
  title: string;
  meta?: string;
  onBack?: () => void;
  action?: React.ReactNode;
}

export function ScreenHeader({ title, meta, onBack, action }: ScreenHeaderProps) {
  const { poke } = useAttention();

  return (
    <header
      className="flex shrink-0 items-center gap-4 px-6"
      style={{ paddingTop: 'calc(18px * var(--ui))', paddingBottom: 'calc(12px * var(--ui))' }}>
      
      {onBack &&
      <motion.button
        type="button"
        onPointerDown={poke}
        onClick={onBack}
        whileTap={{ scale: 0.93 }}
        transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
        aria-label="Zurück"
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/[0.055] text-mist-300 outline-none transition-colors duration-200 hover:bg-white/[0.09] hover:text-mist-50 focus-visible:ring-1 focus-visible:ring-accent/70">
        
          <ChevronLeftIcon className="h-5 w-5" strokeWidth={1.7} aria-hidden="true" />
        </motion.button>
      }
      <div className="min-w-0">
        <h1 className="truncate text-[21px] font-light leading-tight tracking-tight text-mist-50">
          {title}
        </h1>
        {meta &&
        <p className="mt-1 font-mono text-[9.5px] uppercase tracking-label text-mist-500">{meta}</p>
        }
      </div>
      {action && <div className="ml-auto flex items-center gap-2.5">{action}</div>}
    </header>);

}