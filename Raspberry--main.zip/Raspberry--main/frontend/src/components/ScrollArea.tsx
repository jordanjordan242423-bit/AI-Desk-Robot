import React, { useCallback, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

interface ScrollAreaProps {
  children: React.ReactNode;
  className?: string;
}

/**
 * Touch-style scroll region for the secondary screens: momentum scrolling,
 * fade masks at the edges and a slim thumb that only appears while scrolling.
 */
export function ScrollArea({ children, className = '' }: ScrollAreaProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [state, setState] = useState({ top: 0, ratio: 1, thumb: 0 });
  const [active, setActive] = useState(false);
  const idle = useRef<number>();

  const measure = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    const max = el.scrollHeight - el.clientHeight;
    setState({
      top: max > 0 ? el.scrollTop / max : 0,
      ratio: el.clientHeight / el.scrollHeight,
      thumb: max
    });
  }, []);

  useEffect(() => {
    measure();
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [measure]);

  const onScroll = () => {
    measure();
    setActive(true);
    if (idle.current) window.clearTimeout(idle.current);
    idle.current = window.setTimeout(() => setActive(false), 700);
  };

  const scrollable = state.ratio < 0.999;
  const trackH = 'calc(100% - 24px)';

  return (
    <div className="relative min-h-0 flex-1">
      <div
        ref={ref}
        onScroll={onScroll}
        className={`premium-scroll h-full overflow-y-auto overscroll-contain ${className}`}>
        
        {children}
      </div>

      {/* Edge fades — content dissolves instead of being cut off */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-8 transition-opacity duration-200"
        style={{
          opacity: scrollable && state.top > 0.02 ? 1 : 0,
          background:
          'linear-gradient(180deg, rgb(var(--ink-900) / 0.95) 0%, rgb(var(--ink-900) / 0) 100%)'
        }}
        aria-hidden="true" />
      
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-10 transition-opacity duration-200"
        style={{
          opacity: scrollable && state.top < 0.98 ? 1 : 0,
          background:
          'linear-gradient(0deg, rgb(var(--ink-900) / 0.95) 0%, rgb(var(--ink-900) / 0) 100%)'
        }}
        aria-hidden="true" />
      

      {/* Slim thumb */}
      {scrollable &&
      <div
        className="pointer-events-none absolute right-1.5 top-3 w-[3px] rounded-full bg-white/[0.06]"
        style={{ height: trackH }}
        aria-hidden="true">
        
          <motion.div
          className="absolute left-0 w-full rounded-full bg-accent/70"
          style={{ height: `${Math.max(state.ratio * 100, 12)}%` }}
          animate={{
            top: `${state.top * (100 - Math.max(state.ratio * 100, 12))}%`,
            opacity: active ? 1 : 0.25
          }}
          transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }} />
        
        </div>
      }
    </div>);

}

/** Fades a row in as it enters the scroll viewport. */
export function Reveal({
  children,
  delay = 0,
  className = ''




}: {children: React.ReactNode;delay?: number;className?: string;}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: false, amount: 0.35 }}
      transition={{ duration: 0.34, ease: [0.23, 1, 0.32, 1], delay }}
      className={className}>
      
      {children}
    </motion.div>);

}