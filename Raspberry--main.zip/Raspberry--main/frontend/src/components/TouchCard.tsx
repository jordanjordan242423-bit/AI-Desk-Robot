import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useAttention } from '../contexts/AttentionContext';

interface TouchCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  className?: string;
  label?: string;
  active?: boolean;
}

/**
 * A pressable surface built for fingers: a generous target, a short press
 * compression, and it tells the robot to glance at whatever was just touched.
 */
export function TouchCard({ children, onPress, className = '', label, active }: TouchCardProps) {
  const { lookAt } = useAttention();
  const ref = useRef<HTMLButtonElement>(null);

  return (
    <motion.button
      ref={ref}
      type="button"
      aria-label={label}
      onPointerDown={() => lookAt(ref.current)}
      onClick={onPress}
      whileTap={{ scale: 0.983 }}
      transition={{ duration: 0.14, ease: [0.23, 1, 0.32, 1] }}
      className={`surface group relative flex flex-col text-left outline-none focus-visible:border-accent/50 ${
      active ? 'border-accent/40' : ''} ${
      className}`}
      style={active ? { backgroundColor: 'rgb(var(--accent) / 0.07)' } : undefined}>
      
      {children}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-200 group-hover:opacity-60 group-active:opacity-100"
        style={{ borderRadius: 'inherit', background: 'rgb(255 255 255 / 0.022)' }} />
      
    </motion.button>);

}