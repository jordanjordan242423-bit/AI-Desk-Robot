import React, { useEffect, useRef } from 'react';
import { animate, motion, useMotionValue, useMotionValueEvent, useTransform } from 'framer-motion';
import { Robot } from './Robot';
import { RobotBack } from './RobotBack';
import { useAttention } from '../contexts/AttentionContext';
import { useSettings } from '../contexts/SettingsContext';
import type { IdlePhase } from '../hooks/useRobotLife';
import type { RobotMood } from '../types/robot';

interface RobotViewportProps {
  mood: RobotMood;
  height: number;
  phase?: IdlePhase;
  onTap?: () => void;
  label?: string;
  rotatable?: boolean;
  persistKey?: string;
}

const TAP_SLOP = 9;
const PX_PER_TURN = 520;
const FRICTION = 0.96;
const STOP_VEL = 6;
const IDLE_DRIFT_START_MS = 4200;

const mod360 = (deg: number) => {
  const m = deg % 360;
  return m < 0 ? m + 360 : m;
};

const readPersisted = (key?: string) => {
  if (!key) return 0;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return 0;
    const n = Number(raw);
    return Number.isFinite(n) ? n : 0;
  } catch {
    return 0;
  }
};

/**
 * Same cute SVG robot as before, but the whole viewport is rotated in real
 * CSS 3D. Front and back plates cross-fade at ±90°, two thin side panels give
 * a sense of thickness, and after a few seconds without touch the robot gently
 * sways left and right on its own.
 */
export function RobotViewport({
  mood,
  height,
  phase = 'awake',
  onTap,
  label,
  rotatable = true,
  persistKey
}: RobotViewportProps) {
  const { poke, react } = useAttention();
  const { settings } = useSettings();

  const rotY = useMotionValue(readPersisted(persistKey));
  const localTurn = useMotionValue(0);
  const dragLean = useMotionValue(0);
  const dragScale = useMotionValue(1);

  useMotionValueEvent(rotY, 'change', (deg) => {
    const rad = (deg * Math.PI) / 180;
    localTurn.set(Math.max(-1, Math.min(1, Math.sin(rad))));
    if (persistKey) {
      try {
        window.localStorage.setItem(persistKey, String(deg));
      } catch {
        /* ignore */
      }
    }
  });

  const rotateStyle = useTransform(
    [rotY, dragLean, dragScale] as unknown as [typeof rotY, typeof dragLean, typeof dragScale],
    ([r, l, s]: number[]) => `rotateY(${r}deg) rotateZ(${l}deg) scale(${s})`
  );

  const frontOpacity = useTransform(rotY, (v) => {
    const c = Math.cos((mod360(v) * Math.PI) / 180);
    return c >= 0 ? 1 : 0;
  });
  const backOpacity = useTransform(rotY, (v) => {
    const c = Math.cos((mod360(v) * Math.PI) / 180);
    return c < 0 ? 1 : 0;
  });
  const sideRightOpacity = useTransform(rotY, (v) => {
    const s = Math.sin((mod360(v) * Math.PI) / 180);
    return Math.max(0, Math.min(1, s)) * 0.9;
  });
  const sideLeftOpacity = useTransform(rotY, (v) => {
    const s = Math.sin((mod360(v) * Math.PI) / 180);
    return Math.max(0, Math.min(1, -s)) * 0.9;
  });

  const drag = useRef({
    active: false,
    startX: 0,
    base: 0,
    moved: 0,
    lastX: 0,
    lastT: 0,
    vel: 0,
    raf: 0
  });
  const lastInteraction = useRef(performance.now());

  const stopMomentum = () => {
    if (drag.current.raf) {
      window.cancelAnimationFrame(drag.current.raf);
      drag.current.raf = 0;
    }
  };

  const startMomentum = (velDegPerSec: number) => {
    let vel = velDegPerSec;
    let last = performance.now();
    const step = () => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;
      vel *= Math.pow(FRICTION, dt * 60);
      rotY.set(rotY.get() + vel * dt);
      if (Math.abs(vel) < STOP_VEL) {
        drag.current.raf = 0;
        return;
      }
      drag.current.raf = window.requestAnimationFrame(step);
    };
    drag.current.raf = window.requestAnimationFrame(step);
  };

  // ── Idle drift: gentle ambient sway a few degrees ± ──
  useEffect(() => {
    if (!rotatable) return;
    if (phase === 'asleep') return;

    let running = false;
    let raf = 0;

    const startDrift = () => {
      if (running) return;
      running = true;
      const baseAngle = rotY.get();
      const startedAt = performance.now();
      const amp = settings.idle === 'still' ? 1.6 : settings.idle === 'neugierig' ? 5.5 : 3.2;
      const speed = settings.idle === 'neugierig' ? 0.9 : 0.5;
      const step = () => {
        if (!running) return;
        if (drag.current.active || drag.current.raf !== 0) {
          stopDrift();
          return;
        }
        const t = (performance.now() - startedAt) / 1000;
        const ease = Math.min(1, t / 1.2);
        rotY.set(baseAngle + Math.sin(t * speed) * amp * ease);
        raf = window.requestAnimationFrame(step);
      };
      raf = window.requestAnimationFrame(step);
    };

    const stopDrift = () => {
      running = false;
      if (raf) {
        window.cancelAnimationFrame(raf);
        raf = 0;
      }
    };

    const poller = window.setInterval(() => {
      const idle = performance.now() - lastInteraction.current;
      if (
        idle > IDLE_DRIFT_START_MS &&
        !drag.current.active &&
        drag.current.raf === 0 &&
        !running
      ) {
        startDrift();
      }
    }, 350);

    return () => {
      window.clearInterval(poller);
      stopDrift();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rotatable, phase, settings.idle]);

  useEffect(() => () => stopMomentum(), []);

  const onDown = (ev: React.PointerEvent) => {
    poke();
    if (!rotatable) return;
    stopMomentum();
    lastInteraction.current = performance.now();
    ev.currentTarget.setPointerCapture(ev.pointerId);
    drag.current = {
      active: true,
      startX: ev.clientX,
      base: rotY.get(),
      moved: 0,
      lastX: ev.clientX,
      lastT: performance.now(),
      vel: 0,
      raf: 0
    };
    animate(dragScale, 0.985, { duration: 0.16, ease: 'easeOut' });
  };

  const onMove = (ev: React.PointerEvent) => {
    const d = drag.current;
    if (!d.active) return;
    const dx = ev.clientX - d.startX;
    d.moved = Math.max(d.moved, Math.abs(dx));
    const now = performance.now();
    const dt = Math.max(8, now - d.lastT);
    d.vel = ((ev.clientX - d.lastX) / dt) * 1000 * (360 / PX_PER_TURN);
    d.lastX = ev.clientX;
    d.lastT = now;
    lastInteraction.current = now;
    rotY.set(d.base + (dx * 360) / PX_PER_TURN);
    const lean = Math.max(-9, Math.min(9, d.vel * 0.009));
    dragLean.set(lean);
  };

  const onUp = () => {
    const d = drag.current;
    animate(dragLean, 0, { type: 'spring', stiffness: 220, damping: 15 });
    animate(dragScale, 1, { type: 'spring', stiffness: 260, damping: 18 });
    lastInteraction.current = performance.now();
    if (!d.active) {
      if (onTap) onTap();
      return;
    }
    d.active = false;
    if (d.moved < TAP_SLOP) {
      if (onTap) onTap();
      return;
    }
    if (Math.abs(d.vel) > 900) react('surprise');
    if (Math.abs(d.vel) > STOP_VEL) startMomentum(d.vel);
  };

  const sideWidth = Math.round(height * 0.09);
  const sideHeight = Math.round(height * 0.85);

  return (
    <div style={{ perspective: 1400 }} className="select-none">
      <motion.button
        type="button"
        data-testid="robot-viewport"
        aria-label={label ?? 'Roboter'}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        whileTap={{ scale: 0.985 }}
        transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
        className="block rounded-[44px] outline-none focus-visible:ring-1 focus-visible:ring-accent/50"
        style={{ touchAction: 'none', transformStyle: 'preserve-3d' }}>
        <motion.div
          style={{
            transform: rotateStyle,
            transformStyle: 'preserve-3d',
            willChange: 'transform',
            position: 'relative'
          }}>
          <motion.div
            style={{
              transformStyle: 'preserve-3d',
              backfaceVisibility: 'hidden',
              opacity: frontOpacity
            }}>
            <Robot mood={mood} height={height} phase={phase} turn={localTurn} />
          </motion.div>
          <motion.div
            style={{
              position: 'absolute',
              inset: 0,
              transform: 'rotateY(180deg)',
              transformStyle: 'preserve-3d',
              backfaceVisibility: 'hidden',
              opacity: backOpacity
            }}>
            <RobotBack height={height} phase={phase} />
          </motion.div>
          <motion.div
            aria-hidden="true"
            style={{
              position: 'absolute',
              top: '7%',
              right: '46%',
              width: sideWidth,
              height: sideHeight,
              transform: `rotateY(90deg) translateZ(${sideWidth / 2}px)`,
              transformStyle: 'preserve-3d',
              borderRadius: sideWidth * 0.7,
              background:
                'linear-gradient(180deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.05) 44%, rgba(0,0,0,0.55) 100%)',
              boxShadow:
                'inset 1px 0 0 rgba(255,255,255,0.14), inset -2px 0 6px rgba(0,0,0,0.55)',
              opacity: sideRightOpacity,
              pointerEvents: 'none'
            }} />
          <motion.div
            aria-hidden="true"
            style={{
              position: 'absolute',
              top: '7%',
              left: '46%',
              width: sideWidth,
              height: sideHeight,
              transform: `rotateY(-90deg) translateZ(${sideWidth / 2}px)`,
              transformStyle: 'preserve-3d',
              borderRadius: sideWidth * 0.7,
              background:
                'linear-gradient(180deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.05) 44%, rgba(0,0,0,0.55) 100%)',
              boxShadow:
                'inset -1px 0 0 rgba(255,255,255,0.14), inset 2px 0 6px rgba(0,0,0,0.55)',
              opacity: sideLeftOpacity,
              pointerEvents: 'none'
            }} />
        </motion.div>
      </motion.button>
    </div>
  );
}
