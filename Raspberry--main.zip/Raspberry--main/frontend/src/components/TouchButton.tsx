import React from 'react';
import { motion } from 'framer-motion';
import { useAttention } from '../contexts/AttentionContext';

interface TouchButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'ghost' | 'quiet';
  icon?: React.ReactNode;
  size?: 'md' | 'lg';
  'data-testid'?: string;
}

export function TouchButton({
  children,
  onClick,
  variant = 'ghost',
  icon,
  size = 'md',
  'data-testid': testId
}: TouchButtonProps) {
  const { poke } = useAttention();
  const base =
  'flex shrink-0 items-center justify-center gap-2.5 rounded-full font-mono uppercase tracking-label outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/70';
  const dims = size === 'lg' ? 'h-12 px-7 text-[11px]' : 'h-11 px-6 text-[10.5px]';
  const look =
  variant === 'primary' ?
  'bg-accent/[0.15] text-accent-soft hover:bg-accent/[0.22]' :
  variant === 'quiet' ?
  'text-mist-400 hover:text-mist-100' :
  'bg-white/[0.055] text-mist-300 hover:bg-white/[0.09]';

  return (
    <motion.button
      type="button"
      data-testid={testId}
      onPointerDown={poke}
      onClick={onClick}
      whileTap={{ scale: 0.955 }}
      transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
      className={`${base} ${dims} ${look}`}>
      
      {icon}
      {children}
    </motion.button>);

}