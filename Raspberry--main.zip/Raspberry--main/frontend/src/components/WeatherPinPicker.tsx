import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckIcon, PinIcon } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';

export interface WeatherPinOption {
  key: string;
  label: string;
  /** Function that pulls the current value out of the weather object */
  value: (w: Record<string, string | number>) => string;
}

export const weatherPinOptions: WeatherPinOption[] = [
  { key: 'rain', label: 'Regen', value: (w) => String(w.rain) },
  { key: 'wind', label: 'Wind', value: (w) => String(w.wind) },
  { key: 'humidity', label: 'Feuchte', value: (w) => String(w.humidity) },
  { key: 'feels', label: 'Gefühlt', value: (w) => String(w.feels) },
  { key: 'uv', label: 'UV', value: (w) => String(w.uv) },
  { key: 'pressure', label: 'Druck', value: (w) => String(w.pressure) },
  { key: 'sunrise', label: 'Aufgang', value: (w) => String(w.sunrise) },
  { key: 'sunset', label: 'Untergang', value: (w) => String(w.sunset) },
  { key: 'high', label: 'Höchst', value: (w) => String(w.high) },
  { key: 'low', label: 'Tiefst', value: (w) => String(w.low) }
];

const EASE = [0.23, 1, 0.32, 1] as const;

/**
 * A small dropdown that lets the user pick which two weather details are shown
 * on the Home tile. Persisted through the settings context (`homeWeatherPins`).
 */
export function WeatherPinPicker({ onClose }: { onClose?: () => void }) {
  const { settings, set } = useSettings();
  const [open, setOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  const toggle = (key: string) => {
    const pins = settings.homeWeatherPins.includes(key)
      ? settings.homeWeatherPins.filter((k) => k !== key)
      : [...settings.homeWeatherPins, key].slice(-4); // cap at 4 pins
    set('homeWeatherPins', pins);
  };

  useEffect(() => {
    if (!open) return;
    const onDoc = (ev: MouseEvent) => {
      if (!boxRef.current) return;
      if (!boxRef.current.contains(ev.target as Node)) {
        setOpen(false);
        onClose?.();
      }
    };
    window.addEventListener('mousedown', onDoc);
    return () => window.removeEventListener('mousedown', onDoc);
  }, [open, onClose]);

  return (
    <div className="relative" ref={boxRef} onPointerDown={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()}>
      <motion.button
        type="button"
        data-testid="weather-pin-open"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        whileTap={{ scale: 0.92 }}
        transition={{ duration: 0.12, ease: EASE }}
        aria-label="Wetter-Kacheln anpassen"
        className="flex h-7 w-7 items-center justify-center rounded-full bg-white/[0.055] text-mist-400 outline-none transition-colors duration-200 hover:bg-white/[0.09] hover:text-mist-100 focus-visible:ring-1 focus-visible:ring-accent/60">
        <PinIcon className="h-3.5 w-3.5" strokeWidth={1.7} aria-hidden="true" />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.97 }}
            transition={{ duration: 0.16, ease: EASE }}
            className="surface absolute right-0 top-[calc(100%+6px)] z-40 w-[190px] p-1.5"
            data-testid="weather-pin-panel">
            <p className="px-2.5 pt-1.5 pb-1 font-mono text-[8.5px] uppercase tracking-label text-mist-600">
              Kacheln anheften
            </p>
            <div className="max-h-[260px] overflow-y-auto premium-scroll">
              {weatherPinOptions.map((opt) => {
                const active = settings.homeWeatherPins.includes(opt.key);
                return (
                  <button
                    key={opt.key}
                    type="button"
                    data-testid={`weather-pin-${opt.key}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      toggle(opt.key);
                    }}
                    className={`flex w-full items-center gap-2 rounded-[calc(var(--radius)*0.5)] px-2.5 py-1.5 text-left transition-colors duration-150 ${
                      active ? 'bg-accent/[0.08] text-mist-50' : 'text-mist-300 hover:bg-white/[0.05]'
                    }`}>
                    <span className="flex h-3.5 w-3.5 shrink-0 items-center justify-center">
                      {active && (
                        <CheckIcon className="h-3 w-3 text-accent" strokeWidth={2.4} aria-hidden="true" />
                      )}
                    </span>
                    <span className="text-[11.5px] font-light">{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
