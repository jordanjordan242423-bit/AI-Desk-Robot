import React from 'react';
import { motion } from 'framer-motion';
import { BarChart2Icon, CpuIcon, FilmIcon, LightbulbIcon, SparklesIcon } from 'lucide-react';
import { useAttention } from '../contexts/AttentionContext';
import type { ScreenId } from '../types/robot';

interface NavBarProps {
  active: ScreenId;
  onChange: (id: ScreenId) => void;
}

const items: {id: ScreenId;label: string;Icon: typeof CpuIcon;also?: ScreenId[];}[] = [
{ id: 'home', label: 'Home', Icon: SparklesIcon, also: ['wetter', 'prozess', 'zeit'] },
{ id: 'videos', label: 'Videos', Icon: FilmIcon },
{ id: 'statistik', label: 'Statistik', Icon: BarChart2Icon },
{ id: 'themen', label: 'Themen', Icon: LightbulbIcon },
{ id: 'system', label: 'System', Icon: CpuIcon, also: ['netzwerk'] }];


export function NavBar({ active, onChange }: NavBarProps) {
  const { lookAt } = useAttention();

  return (
    <nav
      aria-label="Gerätenavigation"
      className="flex shrink-0 items-stretch gap-1.5 px-4 pb-3"
      style={{ height: 'calc(74px * var(--ui))' }}>
      
      {items.map(({ id, label, Icon, also }) => {
        const isActive = id === active || (also?.includes(active) ?? false);
        return (
          <motion.button
            key={id}
            type="button"
            onPointerDown={(ev) => lookAt(ev.currentTarget)}
            onClick={() => onChange(id)}
            aria-current={isActive ? 'page' : undefined}
            whileTap={{ scale: 0.96 }}
            transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
            className="relative flex flex-1 flex-col items-center justify-center gap-[7px] outline-none focus-visible:ring-1 focus-visible:ring-accent/60"
            style={{ borderRadius: 'calc(var(--radius) * 0.8)' }}>
            
            {isActive &&
            <motion.span
              layoutId="nav-surface"
              className="glow-accent absolute inset-0 border border-white/[0.05] bg-white/[0.05]"
              style={{ borderRadius: 'calc(var(--radius) * 0.8)' }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }} />

            }
            <Icon
              className={`relative h-[17px] w-[17px] transition-colors duration-200 ${
              isActive ? 'text-accent' : 'text-mist-600'}`
              }
              strokeWidth={1.6}
              aria-hidden="true" />
            
            <span
              className={`relative font-mono text-[9px] uppercase tracking-label transition-colors duration-200 ${
              isActive ? 'text-mist-100' : 'text-mist-600'}`
              }>
              
              {label}
            </span>
          </motion.button>);

      })}
    </nav>);

}