import React, { useId } from 'react';
import { motion } from 'framer-motion';
import { useSettings } from '../contexts/SettingsContext';
import type { IdlePhase } from '../hooks/useRobotLife';

interface RobotBackProps {
  height?: number;
  phase?: IdlePhase;
}

function tint(hex: string, f: number) {
  const n = parseInt(hex.slice(1), 16);
  const c = (shift: number) =>
    Math.max(0, Math.min(255, Math.round(((n >> shift) & 255) * f)));
  return `rgb(${c(16)}, ${c(8)}, ${c(0)})`;
}

/**
 * The back of the robot — same 280×320 stage, same shell colours as the front,
 * but with a rounded plate where the face used to be. Antenna and arms are still
 * there so the shape is unmistakable. Drawn as its own SVG so the front stays
 * unchanged when you spin it around.
 */
export function RobotBack({ height = 300, phase = 'awake' }: RobotBackProps) {
  const { settings, body, eyeHex, accent } = useSettings();
  const uid = useId().replace(/:/g, '');
  const asleep = phase === 'asleep';
  const scale = (settings.robotSize / 100) * (height / 320);
  const stageH = 320 * scale;
  const stageW = 280 * scale;

  const bodyF = settings.bodyBrightness / 100;
  const shellLight = tint(body.light, bodyF);
  const shellMid = tint(body.mid, bodyF);
  const shellDeep = tint(body.deep, bodyF);
  const color = eyeHex;
  const dim = asleep ? 0.4 : phase === 'drowsy' ? 0.72 : 1;
  const glowF = settings.robotGlow / 100;

  return (
    <svg
      viewBox="0 0 280 320"
      style={{ height: stageH, width: stageW, display: 'block', overflow: 'visible' }}
      role="img"
      aria-label="Roboter, Rückseite">
      <defs>
        <linearGradient id={`${uid}-shell`} x1="0.9" y1="0" x2="0.12" y2="1">
          <stop offset="0%" stopColor={shellLight} />
          <stop offset="42%" stopColor={shellMid} />
          <stop offset="100%" stopColor={shellDeep} />
        </linearGradient>
        <linearGradient id={`${uid}-body`} x1="0.95" y1="0" x2="0.08" y2="1">
          <stop offset="0%" stopColor={shellLight} />
          <stop offset="55%" stopColor={shellMid} />
          <stop offset="100%" stopColor={shellDeep} />
        </linearGradient>
        <linearGradient id={`${uid}-limb`} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={tint(body.collar, 1.08)} />
          <stop offset="100%" stopColor={tint(body.collar, 0.72)} />
        </linearGradient>
        <linearGradient id={`${uid}-rim`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="60%" stopColor="#ffffff" stopOpacity="0.04" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <filter id={`${uid}-soft`} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="9" />
        </filter>
      </defs>

      {/* Ground contact */}
      <ellipse cx="140" cy="303" rx="76" ry="9" fill="#000000" opacity="0.7" filter={`url(#${uid}-soft)`} />
      <ellipse cx="140" cy="299" rx="60" ry="12" fill={accent.hex} opacity={0.07 * glowF * dim} filter={`url(#${uid}-soft)`} />

      {/* Arms — same as the front, on opposite sides so the silhouette is right */}
      <rect x="216" y="196" width="20" height="60" rx="10" fill={`url(#${uid}-limb)`} />
      <rect x="44" y="196" width="20" height="60" rx="10" fill={`url(#${uid}-limb)`} />

      {/* Body */}
      <rect x="80" y="164" width="120" height="132" rx="54" fill={`url(#${uid}-body)`} />
      <rect x="80.5" y="164.5" width="119" height="131" rx="53.5" fill="none" stroke={`url(#${uid}-rim)`} strokeWidth="1.2" />
      {/* Cooling vents — a couple of dark grilles on the back plate */}
      <g opacity="0.36">
        {[0, 1, 2, 3].map((i) => (
          <rect key={i} x={112} y={210 + i * 14} width="56" height="4" rx="2" fill="#000" />
        ))}
      </g>
      {/* Model tag */}
      <rect x="122" y="270" width="36" height="10" rx="2" fill="#000" opacity="0.22" />

      {/* Head shell */}
      <rect x="58" y="30" width="164" height="142" rx="58" fill={`url(#${uid}-shell)`} />
      <rect x="58.5" y="30.5" width="163" height="141" rx="57.5" fill="none" stroke={`url(#${uid}-rim)`} strokeWidth="1.3" />
      {/* Seam where the front glass sits — a soft indent on the back */}
      <rect x="72" y="46" width="136" height="106" rx="46" fill="none" stroke="#000" strokeOpacity="0.18" strokeWidth="2" />
      <rect x="76" y="50" width="128" height="98" rx="44" fill="#000" opacity="0.08" />

      {/* Sensor pods, from the back angle */}
      <rect x="219" y="92" width="15" height="42" rx="7.5" fill={shellDeep} />
      <rect x="46" y="92" width="15" height="42" rx="7.5" fill={shellDeep} />

      {/* Antenna base — a small nub on the back too */}
      <circle cx="140" cy="42" r="6" fill={shellMid} />
      <circle cx="140" cy="42" r="6" fill="none" stroke="#000" strokeOpacity="0.35" />

      {/* Tiny status LED */}
      <motion.circle
        cx="140"
        cy="90"
        r="3"
        fill={color}
        animate={{ opacity: [0.4, 0.9, 0.4] }}
        transition={{ duration: 3.4, repeat: Infinity, ease: 'easeInOut' }} />
    </svg>
  );
}
