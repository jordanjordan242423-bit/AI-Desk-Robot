import React from 'react';

/** Deterministic, decorative QR-style tag for the local web page. */
function modules(size: number): boolean[][] {
  let seed = 0x2f6e2b1;
  const rand = () => {
    seed = seed * 1103515245 + 12345 & 0x7fffffff;
    return seed / 0x7fffffff;
  };
  const grid: boolean[][] = [];
  for (let y = 0; y < size; y++) {
    const row: boolean[] = [];
    for (let x = 0; x < size; x++) row.push(rand() > 0.52);
    grid.push(row);
  }
  // Finder patterns in three corners
  const finder = (ox: number, oy: number) => {
    for (let y = 0; y < 7; y++) {
      for (let x = 0; x < 7; x++) {
        const edge = x === 0 || y === 0 || x === 6 || y === 6;
        const core = x >= 2 && x <= 4 && y >= 2 && y <= 4;
        grid[oy + y][ox + x] = edge || core;
      }
    }
  };
  finder(0, 0);
  finder(size - 7, 0);
  finder(0, size - 7);
  return grid;
}

const SIZE = 21;
const grid = modules(SIZE);

export function QRTag({ px = 60 }: {px?: number;}) {
  return (
    <svg
      viewBox={`0 0 ${SIZE} ${SIZE}`}
      style={{ width: px, height: px }}
      className="rounded-[4px] bg-mist-50 p-[2px]"
      aria-hidden="true">
      
      {grid.map((row, y) =>
      row.map((on, x) =>
      on ? <rect key={`${x}-${y}`} x={x} y={y} width="1" height="1" fill="#0b0c0f" /> : null
      )
      )}
    </svg>);

}