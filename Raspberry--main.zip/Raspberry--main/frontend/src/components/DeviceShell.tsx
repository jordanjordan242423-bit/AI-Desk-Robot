import React, { useEffect, useState } from 'react';
import { useSettings } from '../contexts/SettingsContext';

const W = 1024;
const H = 600;
const BEZEL = 26;

interface DeviceShellProps {
  children: React.ReactNode;
  framed?: boolean;
}

/** Scales the fixed 7" panel to whatever room it is shown in. */
function useFitScale(framed: boolean) {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const outerW = framed ? W + BEZEL * 2 : W;
    const outerH = framed ? H + BEZEL * 2 + 26 : H;
    const fit = () => {
      const s = Math.min(window.innerWidth / (outerW + 48), window.innerHeight / (outerH + 48), 1);
      setScale(s);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [framed]);

  return scale;
}

export function DeviceShell({ children, framed = true }: DeviceShellProps) {
  const scale = useFitScale(framed);
  const { brightness, settings } = useSettings();
  const z = settings.uiScale / 100;

  const panel =
  <div
    className="display-light touch-panel relative overflow-hidden"
    style={{
      width: W,
      height: H,
      borderRadius: framed ? 20 : 0,
      // Brightness is a real display setting: it dims the rendered pixels, background included
      filter: `brightness(${brightness.toFixed(3)})`,
      transition: 'filter 220ms cubic-bezier(0.23,1,0.32,1)'
    }}>
    
      {/* UI scale is applied with zoom so spacing and type grow together */}
      <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: `${100 / z}%`,
        height: `${100 / z}%`,
        zoom: z
      }}>
      
        {children}
      </div>

      <div
      className="pointer-events-none absolute inset-0"
      style={{
        background:
        'linear-gradient(103deg, rgba(255,255,255,0.035) 0%, rgba(255,255,255,0) 34%, rgba(255,255,255,0) 100%)'
      }}
      aria-hidden="true" />
    
      <div
      className="pointer-events-none absolute inset-0"
      style={{ boxShadow: 'inset 0 0 90px 14px rgba(0,0,0,0.5)' }}
      aria-hidden="true" />
    
    </div>;


  if (!framed) {
    return <div className="room-light flex h-full w-full items-center justify-center">{panel}</div>;
  }

  return (
    <div className="room-light flex h-full w-full items-center justify-center overflow-hidden">
      <div style={{ transform: `scale(${scale})` }} className="flex flex-col items-center">
        <div
          className="shadow-bezel"
          style={{
            padding: BEZEL,
            borderRadius: 40,
            background: 'linear-gradient(168deg, #35393f 0%, #1c1f23 38%, #0f1114 100%)'
          }}>
          
          <div
            style={{
              borderRadius: 22,
              padding: 2,
              background: 'linear-gradient(180deg, rgba(0,0,0,0.92) 0%, rgba(255,255,255,0.075) 100%)'
            }}>
            
            {panel}
          </div>
        </div>
        <div
          className="h-[10px] w-[300px]"
          style={{
            borderRadius: '0 0 14px 14px',
            background: 'linear-gradient(180deg, #23262a 0%, #0d0f11 100%)'
          }}
          aria-hidden="true" />
        
        <div className="h-[7px] w-[420px] rounded-b-[18px] bg-[#0b0d0f]" aria-hidden="true" />
      </div>
    </div>);

}