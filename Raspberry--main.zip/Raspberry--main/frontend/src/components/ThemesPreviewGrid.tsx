import React from 'react';
import { motion } from 'framer-motion';
import { useSettings } from '../contexts/SettingsContext';
import { uiStyles } from '../types/settings';
import type { UiStyleId } from '../types/settings';

/**
 * A row of four (five) little tile-sized previews, each rendered in the actual
 * theme so the user picks visually, not by reading a label. Tapping a tile
 * swaps the whole UI to that theme immediately — like every other setting.
 */
export function ThemesPreviewGrid() {
  const { settings, set } = useSettings();

  return (
    <div className="flex flex-wrap gap-3">
      {uiStyles.map((style) => (
        <ThemeTile
          key={style.id}
          id={style.id}
          label={style.label}
          caption={style.caption}
          active={settings.uiStyle === style.id}
          onPick={() => set('uiStyle', style.id)}
        />
      ))}
    </div>
  );
}

interface TileProps {
  id: UiStyleId;
  label: string;
  caption: string;
  active: boolean;
  onPick: () => void;
}

/**
 * Each tile forces its own data-ui attribute so its inner .surface reflects
 * that theme even when the page is showing a different one. Purely visual —
 * no state contamination.
 */
function ThemeTile({ id, label, caption, active, onPick }: TileProps) {
  return (
    <motion.button
      type="button"
      onClick={onPick}
      data-testid={`theme-tile-${id}`}
      whileTap={{ scale: 0.97 }}
      transition={{ duration: 0.14, ease: [0.23, 1, 0.32, 1] }}
      className={`relative flex w-[132px] shrink-0 flex-col items-stretch overflow-hidden rounded-[calc(var(--radius)*0.7)] p-3 text-left outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/60 ${
        active ? 'bg-accent/[0.09] ring-1 ring-accent/50' : 'bg-white/[0.03] hover:bg-white/[0.055]'
      }`}
      aria-pressed={active}
      aria-label={`Stil ${label}`}>
      {/* Isolated theme scope — the SwatchTile has its own data-ui override */}
      <div
        data-ui={id}
        className="relative flex h-[70px] items-end gap-1.5 rounded-[calc(var(--radius)*0.55)] p-2"
        style={{
          background:
            id === 'minimal'
              ? 'transparent'
              : id === 'solid'
              ? 'rgb(var(--ink-800))'
              : id === 'glass'
              ? 'linear-gradient(135deg, rgb(var(--accent-dim) / 0.35) 0%, rgb(var(--ink-800)) 60%)'
              : 'rgb(var(--ink-800))'
        }}>
        <div className="surface flex-1 rounded-[calc(var(--radius)*0.4)] px-2 pt-1.5 pb-2">
          <div className="h-[3px] w-8 rounded-full bg-white/40" />
          <div className="mt-1 h-[3px] w-6 rounded-full bg-white/25" />
          <div className="mt-1.5 h-[3px] w-10 rounded-full bg-accent" />
        </div>
        <div
          className="surface h-9 w-9 shrink-0 rounded-full"
          style={{ boxShadow: id === 'minimal' ? 'none' : undefined }} />
      </div>

      <div className="mt-2.5 flex items-center justify-between">
        <span className={`text-[11.5px] font-light ${active ? 'text-mist-50' : 'text-mist-200'}`}>
          {label}
        </span>
        {active && <span className="h-1.5 w-1.5 rounded-full bg-accent" aria-hidden="true" />}
      </div>
      <span className="mt-0.5 line-clamp-2 text-[9.5px] font-light leading-snug text-mist-500">
        {caption}
      </span>
    </motion.button>
  );
}
