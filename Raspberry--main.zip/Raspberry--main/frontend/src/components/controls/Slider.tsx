import React, { useCallback, useRef } from 'react';
import { useAttention } from '../../contexts/AttentionContext';

interface SliderProps {
  value: number;
  onChange: (next: number) => void;
  min?: number;
  max?: number;
  step?: number;
  label: string;
  /** Rendered to the right of the track */
  readout?: string;
}

/** A finger sized slider — the whole 44px row is the drag target. */
export function Slider({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  label,
  readout
}: SliderProps) {
  const track = useRef<HTMLDivElement>(null);
  const { poke } = useAttention();
  const pct = (value - min) / (max - min) * 100;

  const apply = useCallback(
    (clientX: number) => {
      const el = track.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const raw = min + (clientX - r.left) / r.width * (max - min);
      const snapped = Math.round(raw / step) * step;
      onChange(Math.max(min, Math.min(max, snapped)));
    },
    [min, max, step, onChange]
  );

  return (
    <div className="flex min-w-0 flex-1 items-center gap-4">
      <div
        ref={track}
        role="slider"
        tabIndex={0}
        aria-label={label}
        aria-valuenow={value}
        aria-valuemin={min}
        aria-valuemax={max}
        onPointerDown={(ev) => {
          poke();
          ev.currentTarget.setPointerCapture(ev.pointerId);
          apply(ev.clientX);
        }}
        onPointerMove={(ev) => {
          if (ev.currentTarget.hasPointerCapture(ev.pointerId)) apply(ev.clientX);
        }}
        onKeyDown={(ev) => {
          if (ev.key === 'ArrowLeft') onChange(Math.max(min, value - step));
          if (ev.key === 'ArrowRight') onChange(Math.min(max, value + step));
        }}
        className="flex h-11 min-w-0 flex-1 cursor-default items-center outline-none focus-visible:ring-1 focus-visible:ring-accent/60">
        
        <div className="relative h-[5px] w-full rounded-full bg-white/[0.07]">
          <div
            className="absolute inset-y-0 left-0 rounded-full bg-accent/80"
            style={{ width: `${pct}%`, transition: 'width 90ms linear' }} />
          
          <span
            className="absolute top-1/2 h-[18px] w-[18px] -translate-y-1/2 rounded-full bg-mist-50 shadow-[0_2px_8px_-2px_rgba(0,0,0,0.9)]"
            style={{ left: `calc(${pct}% - 9px)`, transition: 'left 90ms linear' }}
            aria-hidden="true" />
          
        </div>
      </div>
      {readout &&
      <span className="tabular w-[52px] shrink-0 text-right font-mono text-[11px] text-mist-300">
          {readout}
        </span>
      }
    </div>);

}