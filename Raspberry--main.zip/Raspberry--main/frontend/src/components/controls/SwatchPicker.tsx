import React from 'react';
import { motion } from 'framer-motion';
import { useAttention } from '../../contexts/AttentionContext';

interface SwatchPickerProps<T extends string> {
  value: T;
  options: {value: T;label: string;hex: string;}[];
  onChange: (value: T) => void;
}

export function SwatchPicker<T extends string>({ value, options, onChange }: SwatchPickerProps<T>) {
  const { poke } = useAttention();

  return (
    <div className="flex flex-wrap gap-2.5">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <motion.button
            key={o.value}
            type="button"
            aria-label={o.label}
            aria-pressed={active}
            onPointerDown={poke}
            onClick={() => onChange(o.value)}
            whileTap={{ scale: 0.92 }}
            transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
            className="flex h-11 items-center gap-2.5 rounded-full border px-3 outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/70"
            style={{
              borderColor: active ? o.hex : 'rgba(255,255,255,0.06)',
              backgroundColor: active ? `${o.hex}1f` : 'rgba(255,255,255,0.02)'
            }}>
            
            <span
              className="h-[18px] w-[18px] rounded-full"
              style={{ backgroundColor: o.hex, boxShadow: active ? `0 0 12px ${o.hex}80` : 'none' }}
              aria-hidden="true" />
            
            <span
              className="font-mono text-[10px] uppercase tracking-label"
              style={{ color: active ? o.hex : '#6d747c' }}>
              
              {o.label}
            </span>
          </motion.button>);

      })}
    </div>);

}