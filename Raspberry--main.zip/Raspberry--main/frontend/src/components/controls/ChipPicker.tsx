import React from 'react';
import { motion } from 'framer-motion';
import { useAttention } from '../../contexts/AttentionContext';

interface ChipPickerProps {
  values: string[];
  options: string[];
  onChange: (next: string[]) => void;
  label: string;
}

/** Multi select pills — used for content categories and publishing times. */
export function ChipPicker({ values, options, onChange, label }: ChipPickerProps) {
  const { poke } = useAttention();

  const toggle = (o: string) =>
  onChange(values.includes(o) ? values.filter((v) => v !== o) : [...values, o]);

  return (
    <div role="group" aria-label={label} className="flex flex-wrap gap-2">
      {options.map((o) => {
        const active = values.includes(o);
        return (
          <motion.button
            key={o}
            type="button"
            aria-pressed={active}
            onPointerDown={poke}
            onClick={() => toggle(o)}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
            className={`h-10 rounded-full border px-4 text-[12px] font-light outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/70 ${
            active ?
            'border-accent/40 bg-accent/[0.14] text-accent-soft' :
            'border-white/[0.06] bg-white/[0.02] text-mist-400 hover:text-mist-200'}`
            }>
            
            {o}
          </motion.button>);

      })}
    </div>);

}