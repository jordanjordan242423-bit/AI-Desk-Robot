import React from 'react';

interface SettingRowProps {
  label: string;
  hint?: string;
  children: React.ReactNode;
  /** Puts the control on its own line, for wide pickers */
  stacked?: boolean;
}

export function SettingRow({ label, hint, children, stacked }: SettingRowProps) {
  if (stacked) {
    return (
      <div className="px-[18px] py-4">
        <p className="text-[13.5px] font-light leading-none text-mist-100">{label}</p>
        {hint && <p className="mt-1.5 text-[10.5px] font-light leading-snug text-mist-600">{hint}</p>}
        <div className="mt-3.5">{children}</div>
      </div>);

  }

  return (
    <div className="flex min-h-[64px] items-center gap-5 px-[18px] py-3">
      <div className="min-w-0 flex-1">
        <p className="text-[13.5px] font-light leading-none text-mist-100">{label}</p>
        {hint && <p className="mt-1.5 text-[10.5px] font-light leading-snug text-mist-600">{hint}</p>}
      </div>
      <div className="flex shrink-0 items-center justify-end">{children}</div>
    </div>);

}

export function SettingGroup({
  title,
  icon,
  children




}: {title: string;icon?: React.ReactNode;children: React.ReactNode;}) {
  return (
    <section className="surface">
      <header className="flex items-center gap-2 px-[18px] pb-1 pt-4 text-mist-500">
        {icon}
        <h2 className="font-mono text-[9.5px] uppercase tracking-label">{title}</h2>
      </header>
      <div className="divide-y divide-white/[0.04]">{children}</div>
    </section>);

}