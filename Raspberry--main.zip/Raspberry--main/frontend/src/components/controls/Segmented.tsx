import React from 'react';
import { motion } from 'framer-motion';
import { useAttention } from '../../contexts/AttentionContext';

interface SegmentedProps<T extends string> {
  id: string;
  value: T;
  options: {value: T;label: string;}[];
  onChange: (value: T) => void;
  /** Fills the available width instead of hugging the options */
  wide?: boolean;
}

export function Segmented<T extends string>({
  id,
  value,
  options,
  onChange,
  wide
}: SegmentedProps<T>) {
  const { poke } = useAttention();

  return (
    <div
      role="radiogroup"
      className={`flex h-11 items-stretch gap-1 rounded-full border border-white/[0.05] bg-white/[0.025] p-1 ${
      wide ? 'w-full' : ''}`
      }>
      
      {options.map((o) => {
        const active = o.value === value;
        return (
          <motion.button
            key={o.value}
            type="button"
            role="radio"
            aria-checked={active}
            onPointerDown={poke}
            onClick={() => onChange(o.value)}
            whileTap={{ scale: 0.96 }}
            transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
            className={`relative flex-1 rounded-full px-4 font-mono text-[10px] uppercase tracking-label outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/70 ${
            active ? 'text-accent-soft' : 'text-mist-500 hover:text-mist-200'}`
            }>
            
            {active &&
            <motion.span
              layoutId={`seg-${id}`}
              className="glow-accent absolute inset-0 rounded-full bg-accent/[0.16]"
              transition={{ duration: 0.26, ease: [0.23, 1, 0.32, 1] }} />

            }
            <span className="relative whitespace-nowrap">{o.label}</span>
          </motion.button>);

      })}
    </div>);

}