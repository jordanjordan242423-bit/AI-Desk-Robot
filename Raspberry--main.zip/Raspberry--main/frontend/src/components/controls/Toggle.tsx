import React from 'react';
import { motion } from 'framer-motion';
import { useAttention } from '../../contexts/AttentionContext';

interface ToggleProps {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
}

export function Toggle({ checked, onChange, label }: ToggleProps) {
  const { poke } = useAttention();

  return (
    <motion.button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onPointerDown={poke}
      onClick={() => onChange(!checked)}
      whileTap={{ scale: 0.94 }}
      transition={{ duration: 0.12, ease: [0.23, 1, 0.32, 1] }}
      className={`relative flex h-8 w-[54px] shrink-0 items-center rounded-full border outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/70 ${
      checked ? 'glow-accent border-accent/40 bg-accent/[0.2]' : 'border-white/[0.07] bg-white/[0.04]'}`
      }>
      
      <motion.span
        className={`ml-1 h-6 w-6 rounded-full ${checked ? 'bg-accent-soft' : 'bg-mist-500'}`}
        animate={{ x: checked ? 22 : 0 }}
        transition={{ type: 'spring', stiffness: 620, damping: 34 }} />
      
    </motion.button>);

}