import React, { useEffect, useId } from 'react';
import { animate, motion, useMotionValue, useTransform } from 'framer-motion';
import type { MotionValue } from 'framer-motion';
import { expressions, restMouths } from '../data/robotStates';
import { useSettings } from '../contexts/SettingsContext';
import { useAttention } from '../contexts/AttentionContext';
import { useRobotLife } from '../hooks/useRobotLife';
import type { IdlePhase } from '../hooks/useRobotLife';
import type { RobotMood } from '../types/robot';
import type { EyeShape } from '../types/settings';

interface RobotProps {
  mood: RobotMood;
  /** Base height in px; the robot size setting scales this */
  height?: number;
  phase?: IdlePhase;
  /** Swipe rotation, -1 … 1 */
  turn?: MotionValue<number>;
}

/* Geometry — a 280 × 320 stage. Head and body overlap so the neck reads as one shell. */
const CX = 140;
const EYE_Y = 96;
const MOUTH_Y = 128;
const EASE = [0.23, 1, 0.32, 1] as const;

const eyeShapes: Record<EyeShape, {w: number;h: number;rot: number;rx: number | null;}> = {
  rund: { w: 1, h: 1, rot: 0, rx: null },
  pille: { w: 0.74, h: 1.22, rot: 0, rx: null },
  balken: { w: 1.26, h: 0.58, rot: 0, rx: 3 },
  kristall: { w: 0.94, h: 0.94, rot: 45, rx: 5 }
};

function tint(hex: string, f: number) {
  const n = parseInt(hex.slice(1), 16);
  const c = (shift: number) => Math.max(0, Math.min(255, Math.round((n >> shift & 255) * f)));
  return `rgb(${c(16)}, ${c(8)}, ${c(0)})`;
}

export function Robot({ mood, height = 300, phase = 'awake', turn }: RobotProps) {
  const { settings, eyeHex, body, robot } = useSettings();
  const { glance, reaction } = useAttention();
  const asleep = phase === 'asleep';
  const shownMood: RobotMood = asleep ? 'sleeping' : mood;

  const life = useRobotLife({
    mood: shownMood,
    profile: robot,
    idle: settings.idle,
    phase,
    glance,
    reaction
  });

  const e = expressions[shownMood];
  const uid = useId().replace(/:/g, '');
  const happy = life.flourish === 'happy';
  const err = shownMood === 'error';
  const color = err ? '#e8746c' : eyeHex;

  const localTurn = useMotionValue(0);
  const t = turn ?? localTurn;

  /* ── Derived looks from the settings ─────────────────── */
  const scale = settings.robotSize / 100 * (height / 320);
  const stageH = 320 * scale;
  const stageW = 280 * scale;

  const bodyF = settings.bodyBrightness / 100;
  const shellLight = tint(body.light, bodyF);
  const shellMid = tint(body.mid, bodyF);
  const shellDeep = tint(body.deep, bodyF);

  const fb = settings.faceBrightness / 100;
  const glassTop = `rgb(${Math.round(18 + fb * 58)}, ${Math.round(22 + fb * 60)}, ${Math.round(26 + fb * 64)})`;
  const glassMid = `rgb(${Math.round(8 + fb * 30)}, ${Math.round(10 + fb * 32)}, ${Math.round(13 + fb * 36)})`;
  const glassDeep = `rgb(${Math.round(3 + fb * 14)}, ${Math.round(4 + fb * 16)}, ${Math.round(6 + fb * 18)})`;

  const glowF = settings.robotGlow / 100;
  const eb = settings.eyeBrightness / 100;
  const dim = asleep ? 0.4 : phase === 'drowsy' ? 0.72 : 1;
  const eyeOpacity = (0.64 + eb * 0.36) * dim;
  const glowOpacity = (0.1 + eb * 0.42) * glowF * dim;
  const blurStd = 3 + glowF * 7;

  const spacing = 27 * (settings.eyeSpacing / 100);
  const EYE_L = CX - spacing;
  const EYE_R = CX + spacing;
  const sh = eyeShapes[settings.eyeShape];
  const eyeMul = settings.eyeSize / 100;
  const eyeW = e.eyeW * eyeMul * sh.w;
  const eyeH = e.eyeH * eyeMul * sh.h;
  const eyeRx = sh.rx ?? Math.min(eyeW, eyeH) / 2;
  const cy = EYE_Y + e.dy;

  /* Mouth: personality decides the resting shape, the state decides the rest */
  const resting = shownMood === 'idle' || shownMood === 'waiting';
  const restPath = robot.smile > 0.66 ? restMouths.smile : robot.smile > 0.33 ? restMouths.soft : restMouths.flat;
  const mouthPath = happy ? expressions.success.mouth : resting ? restPath : e.mouth;
  const ms = settings.mouthSize / 100;
  const arc = e.arcEyes || happy;

  /* ── Motion plumbing ─────────────────────────────────── */
  const exprTilt = useMotionValue(0);
  useEffect(() => {
    animate(exprTilt, (e.tilt ?? 0) + (life.flourish === 'curious' ? 7 : 0), {
      duration: 0.6,
      ease: EASE
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [e.tilt, life.flourish]);

  const headRotate = useTransform([life.headTilt, exprTilt, t], ([a, b, tv]: number[]) => a + b + tv * -3);
  const headShift = useTransform([life.headX, t], ([a, tv]: number[]) => a + tv * -5);
  const faceX = useTransform(t, (v) => v * -9);
  const eyesX = useTransform([life.eyeX, t], ([a, tv]: number[]) => a + tv * 5);
  const podShift = useTransform(t, (v) => v * 6);
  const leftPodOpacity = useTransform(t, (v) => 1 - Math.max(0, -v) * 0.55);
  const rightPodOpacity = useTransform(t, (v) => 1 - Math.max(0, v) * 0.55);
  const shadeLeft = useTransform(t, (v) => Math.max(0, -v) * 0.38);
  const shadeRight = useTransform(t, (v) => Math.max(0, v) * 0.38);
  const antennaRotate = useTransform([life.antenna, t], ([a, tv]: number[]) => a + tv * -9);
  const podLift = useTransform(life.podTwitch, (v) => v * -2.6);

  const spd = Math.max(0.3, life.speed);
  const breath = life.live ?
  {
    animate: { y: [0, -2.6 * life.amp, 0], scaleY: [1, 1 + 0.012 * life.amp, 1] },
    transition: {
      duration: (asleep ? 8.6 : 5.2) / spd,
      repeat: Infinity,
      ease: 'easeInOut' as const
    }
  } :
  { animate: { y: 0, scaleY: 1 }, transition: { duration: 0 } };

  const armPose = () => {
    if (!life.live) return { rotate: 0, duration: 0, repeat: 0 };
    if (shownMood === 'success' || happy) return { rotate: [0, -16, -7], duration: 1 / spd, repeat: Infinity };
    if (life.flourish === 'stretch') return { rotate: [0, -26, 0], duration: 1.5 / spd, repeat: 0 };
    if (shownMood === 'writing') return { rotate: [0, -7, -1], duration: 1.3 / spd, repeat: Infinity };
    if (asleep) return { rotate: [0, 1.2, 0], duration: 9 / spd, repeat: Infinity };
    return { rotate: [0, -3.6 * life.amp, 0], duration: 6.4 / spd, repeat: Infinity };
  };
  const ap = armPose();
  const armKey = `${shownMood}-${life.flourish}-${settings.armStyle}-${life.live}`;
  const armTransition = {
    duration: ap.duration,
    repeat: ap.repeat as number,
    repeatType: 'mirror' as const,
    ease: 'easeInOut' as const
  };

  /* ── Parts ───────────────────────────────────────────── */
  const eyePair = (glow: boolean) =>
  <g opacity={glow ? glowOpacity : eyeOpacity} filter={glow ? `url(#${uid}-glow)` : undefined}>
      <motion.g animate={{ opacity: arc ? 0 : 1 }} transition={{ duration: 0.2, ease: EASE }}>
        {[EYE_L, EYE_R].map((ex) =>
      <g key={ex} transform={sh.rot ? `rotate(${sh.rot} ${ex} ${cy})` : undefined}>
            <motion.rect
          fill={color}
          initial={false}
          animate={{ x: ex - eyeW / 2, y: cy - eyeH / 2, width: eyeW, height: eyeH, rx: eyeRx }}
          transition={{ duration: 0.3, ease: EASE }} />
        
          </g>
      )}
      </motion.g>
      <motion.g
      animate={{ opacity: arc ? 1 : 0 }}
      transition={{ duration: 0.2, ease: EASE }}
      stroke={color}
      strokeWidth={6.5 * eyeMul}
      strokeLinecap="round"
      fill="none">
      
        <path d={`M${EYE_L - 14 * eyeMul} ${cy + 5} Q${EYE_L} ${cy - 12 * eyeMul} ${EYE_L + 14 * eyeMul} ${cy + 5}`} />
        <path d={`M${EYE_R - 14 * eyeMul} ${cy + 5} Q${EYE_R} ${cy - 12 * eyeMul} ${EYE_R + 14 * eyeMul} ${cy + 5}`} />
      </motion.g>
    </g>;


  const mouth = () => {
    if (settings.mouthStyle === 'keine') return null;
    const stroke = 4.6 * ms;
    if (settings.mouthStyle === 'punkt') {
      return <circle cx={CX} cy={MOUTH_Y} r={4.4 * ms} fill={color} opacity={eyeOpacity * 0.9} />;
    }
    if (settings.mouthStyle === 'linie') {
      return (
        <path
          d={`M${CX - 13 * ms} ${MOUTH_Y} L${CX + 13 * ms} ${MOUTH_Y}`}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          opacity={eyeOpacity * 0.9} />);


    }
    return (
      <motion.path
        initial={false}
        animate={{ d: mouthPath }}
        transition={{ duration: 0.3, ease: EASE }}
        stroke={color}
        strokeWidth={stroke}
        strokeLinecap="round"
        fill="none"
        opacity={eyeOpacity * 0.9} />);


  };

  const arm = (side: -1 | 1) => {
    const base = side < 0 ? 71 : 209;
    const style = settings.armStyle;
    if (style === 'gelenk') {
      return (
        <>
          <rect x={base - 9} y={196} width={18} height={30} rx={9} fill={`url(#${uid}-limb)`} />
          <circle cx={base} cy={228} r={8.4} fill={shellMid} />
          <circle cx={base} cy={228} r={8.4} fill="none" stroke="#ffffff" strokeOpacity="0.35" />
          <rect x={base - 7.5} y={231} width={15} height={26} rx={7.5} fill={`url(#${uid}-limb)`} />
          <rect x={base - 5} y={200} width={3.4} height={18} rx={1.7} fill="#ffffff" opacity={side < 0 ? 0.42 : 0.24} />
        </>);

    }
    if (style === 'flach') {
      return (
        <>
          <rect x={base - 10} y={196} width={20} height={58} rx={5} fill={`url(#${uid}-limb)`} />
          <rect x={base - 6} y={201} width={3.6} height={34} rx={1.8} fill="#ffffff" opacity={side < 0 ? 0.4 : 0.22} />
        </>);

    }
    return (
      <>
        <rect x={base - 10} y={196} width={20} height={60} rx={10} fill={`url(#${uid}-limb)`} />
        <rect x={base - 6} y={202} width={3.6} height={34} rx={1.8} fill="#ffffff" opacity={side < 0 ? 0.42 : 0.24} />
      </>);

  };

  const antenna = () => {
    if (settings.antennaStyle === 'keine') return null;
    const bulb = (x: number, y: number, r: number) =>
    <>
        <circle cx={x} cy={y} r={r + 2.6} fill={color} opacity={glowOpacity * 0.8} filter={`url(#${uid}-glow)`} />
        <circle cx={x} cy={y} r={r} fill={color} opacity={eyeOpacity} />
      </>;

    if (settings.antennaStyle === 'bogen') {
      return (
        <g>
          <path d="M106 44 Q140 26 174 44" stroke={color} strokeWidth="5.5" strokeLinecap="round" fill="none" opacity={eyeOpacity * 0.85} />
          <path d="M106 44 Q140 26 174 44" stroke={color} strokeWidth="9" strokeLinecap="round" fill="none" opacity={glowOpacity * 0.7} filter={`url(#${uid}-glow)`} />
        </g>);

    }
    if (settings.antennaStyle === 'doppel') {
      return (
        <g>
          <path d="M120 44 L114 20" stroke={shellMid} strokeWidth="3.4" strokeLinecap="round" />
          <path d="M160 44 L166 20" stroke={shellMid} strokeWidth="3.4" strokeLinecap="round" />
          {bulb(113, 17, 4.2)}
          {bulb(167, 17, 4.2)}
        </g>);

    }
    return (
      <g>
        <path d="M140 42 L140 18" stroke={shellMid} strokeWidth="3.8" strokeLinecap="round" />
        {bulb(140, 13, 5.4)}
      </g>);

  };

  return (
    <svg
      viewBox="0 0 280 320"
      style={{ height: stageH, width: stageW, display: 'block', overflow: 'visible' }}
      role="img"
      aria-label={`Roboter, Zustand ${shownMood}`}>
      
      <defs>
        <linearGradient id={`${uid}-shell`} x1="0.12" y1="0" x2="0.9" y2="1">
          <stop offset="0%" stopColor={shellLight} />
          <stop offset="42%" stopColor={shellMid} />
          <stop offset="100%" stopColor={shellDeep} />
        </linearGradient>
        <linearGradient id={`${uid}-bodyShell`} x1="0.08" y1="0" x2="0.95" y2="1">
          <stop offset="0%" stopColor={shellLight} />
          <stop offset="55%" stopColor={shellMid} />
          <stop offset="100%" stopColor={shellDeep} />
        </linearGradient>
        <linearGradient id={`${uid}-limb`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={tint(body.collar, 1.08)} />
          <stop offset="100%" stopColor={tint(body.collar, 0.72)} />
        </linearGradient>
        <linearGradient id={`${uid}-glass`} x1="0.2" y1="0" x2="0.85" y2="1">
          <stop offset="0%" stopColor={glassTop} />
          <stop offset="45%" stopColor={glassMid} />
          <stop offset="100%" stopColor={glassDeep} />
        </linearGradient>
        <radialGradient id={`${uid}-bloom`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor={color} stopOpacity="0.55" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`${uid}-rim`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
          <stop offset="60%" stopColor="#ffffff" stopOpacity="0.06" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <filter id={`${uid}-glow`} x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation={blurStd} />
        </filter>
        <filter id={`${uid}-soft`} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="9" />
        </filter>
        <clipPath id={`${uid}-headClip`}>
          <rect x="58" y="30" width="164" height="142" rx="58" />
        </clipPath>
        <clipPath id={`${uid}-bodyClip`}>
          <rect x="80" y="164" width="120" height="132" rx="54" />
        </clipPath>
      </defs>

      {/* Desk contact and the light the robot throws back onto it */}
      <ellipse cx={CX} cy="303" rx="76" ry="9" fill="#000000" opacity="0.7" filter={`url(#${uid}-soft)`} />
      <ellipse cx={CX} cy="299" rx="60" ry="12" fill={color} opacity={0.07 * glowF * dim} filter={`url(#${uid}-soft)`} />
      <ellipse cx={CX} cy="298" rx="64" ry="12" fill="none" stroke={color} strokeWidth="1.1" opacity={0.4 * dim} />

      <motion.g style={{ rotate: life.lean, transformOrigin: `${CX}px 298px` }}>
        <motion.g animate={{ y: life.flourish === 'stretch' ? -6 : 0 }} transition={{ duration: 0.7, ease: EASE }}>
          <motion.g {...breath} style={{ transformOrigin: `${CX}px 296px` }}>
            {/* Arms sit at the shoulder line and overlap the shell by 2px, so they read as attached */}
            <motion.g key={`al-${armKey}`} style={{ transformOrigin: '71px 198px' }} animate={{ rotate: ap.rotate }} transition={armTransition}>
              {arm(-1)}
            </motion.g>
            <motion.g
              key={`ar-${armKey}`}
              style={{ transformOrigin: '209px 198px' }}
              animate={{ rotate: Array.isArray(ap.rotate) ? (ap.rotate as number[]).map((v) => -v) : 0 }}
              transition={armTransition}>
              
              {arm(1)}
            </motion.g>

            {/* Body */}
            <rect x="80" y="164" width="120" height="132" rx="54" fill={`url(#${uid}-bodyShell)`} />
            <rect x="80.5" y="164.5" width="119" height="131" rx="53.5" fill="none" stroke={`url(#${uid}-rim)`} strokeWidth="1.2" />
            <path
              d={`M104 170 Q140 160 176 170 Q168 200 140 210 Q112 200 104 170 Z`}
              fill={body.collar}
              opacity="0.92" />
            
            <path d="M108 172 Q140 164 172 172 Q166 184 140 190 Q114 184 108 172 Z" fill="#ffffff" opacity="0.2" />
            <motion.circle
              cx={CX}
              cy="238"
              r="2.6"
              fill={color}
              animate={life.live ? { opacity: [0.2, 0.65, 0.2] } : { opacity: 0.4 }}
              transition={life.live ? { duration: 3.9 / spd, repeat: Infinity, ease: 'easeInOut' } : { duration: 0 }} />
            
            {/* Volume shading that follows the rotation */}
            <g clipPath={`url(#${uid}-bodyClip)`}>
              <motion.rect x="80" y="164" width="44" height="132" fill="#000000" style={{ opacity: shadeLeft }} />
              <motion.rect x="156" y="164" width="44" height="132" fill="#000000" style={{ opacity: shadeRight }} />
            </g>

            {/* Head */}
            <motion.g style={{ rotate: headRotate, x: headShift, y: life.headY, transformOrigin: `${CX}px 172px` }}>
              {/* Sensor pods */}
              <motion.g style={{ y: podLift, x: podShift }}>
                <motion.g style={{ opacity: leftPodOpacity }}>
                  <rect x="46" y="92" width="15" height="42" rx="7.5" fill={shellMid} />
                  <rect x="48.5" y="98" width="3.2" height="20" rx="1.6" fill="#ffffff" opacity="0.5" />
                  <circle cx="53.5" cy="127" r="1.9" fill={color} opacity={0.7 * dim} />
                </motion.g>
                <motion.g style={{ opacity: rightPodOpacity }}>
                  <rect x="219" y="92" width="15" height="42" rx="7.5" fill={shellDeep} />
                  <circle cx="226.5" cy="127" r="1.9" fill={color} opacity={0.45 * dim} />
                </motion.g>
              </motion.g>

              <motion.g
                style={{
                  rotate: settings.antennaMotion ? antennaRotate : 0,
                  transformOrigin: `${CX}px 44px`
                }}>
                
                {antenna()}
              </motion.g>

              {/* Helmet */}
              <rect x="58" y="30" width="164" height="142" rx="58" fill={`url(#${uid}-shell)`} />
              <rect x="58.5" y="30.5" width="163" height="141" rx="57.5" fill="none" stroke={`url(#${uid}-rim)`} strokeWidth="1.3" />
              <path d="M78 66 Q104 42 146 40" stroke="#ffffff" strokeWidth="6" strokeLinecap="round" opacity="0.42" fill="none" />

              {/* Glass face, inset into the shell */}
              <rect x="72" y="46" width="136" height="106" rx="46" fill={`url(#${uid}-glass)`} />
              <rect x="72" y="46" width="136" height="106" rx="46" fill="none" stroke="#000000" strokeOpacity="0.8" />
              <rect x="74.5" y="48.5" width="131" height="101" rx="43.5" fill="none" stroke="#ffffff" strokeOpacity="0.07" />
              <ellipse cx={CX} cy={EYE_Y + 4} rx="56" ry="40" fill={`url(#${uid}-bloom)`} opacity={glowOpacity * 0.5} />

              {/* Face content — shifts against the rotation so it reads as wrapped onto the shell */}
              <motion.g style={{ x: faceX }}>
                <motion.g style={{ x: eyesX, y: life.eyeY, scale: life.eyeScale, transformOrigin: `${CX}px ${cy}px` }}>
                  <motion.g style={{ scaleY: life.lid, transformOrigin: `${CX}px ${cy}px` }}>
                    {eyePair(true)}
                    {eyePair(false)}
                  </motion.g>
                  <motion.g
                    animate={{ opacity: e.brow ? 0.8 : 0 }}
                    transition={{ duration: 0.25, ease: EASE }}
                    stroke={color}
                    strokeWidth="3.6"
                    strokeLinecap="round">
                    
                    <path d={`M${EYE_L - 14} ${cy - 20} L${EYE_L + 10} ${cy - 14}`} />
                    <path d={`M${EYE_R + 14} ${cy - 20} L${EYE_R - 10} ${cy - 14}`} />
                  </motion.g>
                </motion.g>

                <motion.g
                  key={`mouth-${e.talk ? 'talk' : 'still'}-${settings.mouthStyle}`}
                  animate={{ scaleY: e.talk && life.live ? [1, 0.4, 1.2, 0.6, 1] : 1 }}
                  transition={
                  e.talk && life.live ?
                  { duration: 0.9 / spd, repeat: Infinity, ease: 'easeInOut' } :
                  { duration: 0.25, ease: EASE }
                  }
                  style={{ transformOrigin: `${CX}px ${MOUTH_Y}px` }}>
                  
                  {mouth()}
                </motion.g>
              </motion.g>

              {/* Specular sheen on the glass, drawn last */}
              <path d="M88 70 Q104 52 132 50" stroke="#ffffff" strokeWidth="5" strokeLinecap="round" opacity="0.09" fill="none" />
              <g clipPath={`url(#${uid}-headClip)`}>
                <motion.rect x="58" y="30" width="50" height="142" fill="#000000" style={{ opacity: shadeLeft }} />
                <motion.rect x="172" y="30" width="50" height="142" fill="#000000" style={{ opacity: shadeRight }} />
              </g>
            </motion.g>
          </motion.g>
        </motion.g>
      </motion.g>
    </svg>);

}