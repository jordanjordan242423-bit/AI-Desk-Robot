import React from 'react';

interface PanelProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}

/** The one surface every screen is built from. Its material follows the UI style setting. */
export function Panel({ children, className = '', title, icon, action }: PanelProps) {
  return (
    <section className={`surface relative ${className}`}>
      {title &&
      <header className="flex items-center justify-between px-[18px] pb-2 pt-4">
          <div className="flex items-center gap-2 text-mist-500">
            {icon}
            <h2 className="font-mono text-[9.5px] uppercase tracking-label text-mist-500">{title}</h2>
          </div>
          {action}
        </header>
      }
      {children}
    </section>);

}