import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { SettingsIcon, WifiIcon } from 'lucide-react';
import { device, network as fallbackNet } from '../data/content';
import { useSettings } from '../contexts/SettingsContext';
import { useAttention } from '../contexts/AttentionContext';
import { useNetworkStatus } from '../hooks/useNetworkStatus';

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 15000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

function MarkGlyph() {
  return (
    <svg viewBox="0 0 32 32" className="h-[30px] w-[30px]" aria-hidden="true">
      <rect x="1" y="1" width="30" height="30" rx="10" fill="rgb(var(--ink-800))" stroke="rgb(255 255 255 / 0.08)" />
      <rect x="7" y="9" width="18" height="15" rx="7" fill="none" stroke="rgb(var(--accent))" strokeWidth="1.5" opacity="0.9" />
      <circle cx="13" cy="16" r="1.9" fill="rgb(var(--accent))" />
      <circle cx="19" cy="16" r="1.9" fill="rgb(var(--accent))" />
    </svg>);

}

interface StatusBarProps {
  onOpenSettings: () => void;
  onOpenClock: () => void;
  onOpenNetwork: () => void;
  settingsActive?: boolean;
}

export function StatusBar({
  onOpenSettings,
  onOpenClock,
  onOpenNetwork,
  settingsActive
}: StatusBarProps) {
  const now = useClock();
  const { settings } = useSettings();
  const { poke, lookAt, react } = useAttention();
  const liveNet = useNetworkStatus(6000);
  const ssid = liveNet?.ssid ?? liveNet?.primary_interface ?? fallbackNet.ssid;
  const online = liveNet ? liveNet.online : settings.wifi;

  const time = now.toLocaleTimeString('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: settings.timeFormat === '12 h'
  });
  const date =
  settings.dateFormat === 'TT.MM.JJJJ' ?
  now.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) :
  now.toISOString().slice(0, 10);

  const tap = { whileTap: { scale: 0.94 }, transition: { duration: 0.12, ease: [0.23, 1, 0.32, 1] as const } };

  return (
    <header
      className="flex shrink-0 items-center justify-between px-5"
      style={{ height: 'calc(58px * var(--ui))' }}>
      
      <div className="flex items-center gap-3 pl-1">
        <MarkGlyph />
        <div className="leading-none">
          <h1 className="text-[14.5px] font-normal tracking-tight text-mist-100">{device.name}</h1>
          <p className="mt-[5px] font-mono text-[8.5px] uppercase tracking-label text-mist-600">
            {device.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <motion.button
          type="button"
          {...tap}
          onPointerDown={(ev) => lookAt(ev.currentTarget)}
          onClick={onOpenNetwork}
          aria-label="Netzwerk öffnen"
          className="flex h-10 items-center gap-2.5 rounded-full px-3 outline-none transition-colors duration-200 hover:bg-white/[0.05] focus-visible:ring-1 focus-visible:ring-accent/60">
          
          <span
            className={`h-1.5 w-1.5 rounded-full ${online ? 'bg-accent' : 'bg-mist-600'}`}
            aria-hidden="true" />
          
          <span className="font-mono text-[9px] uppercase tracking-label text-mist-500">
            {online ? ssid : 'Offline'}
          </span>
          <WifiIcon
            className={`h-[15px] w-[15px] ${online ? 'text-mist-400' : 'text-mist-600'}`}
            strokeWidth={1.7}
            aria-hidden="true" />
          
        </motion.button>

        <motion.button
          type="button"
          {...tap}
          onPointerDown={(ev) => lookAt(ev.currentTarget)}
          onClick={onOpenClock}
          aria-label="Zeit und Datum öffnen"
          className="flex h-10 flex-col items-end justify-center rounded-full px-3 outline-none transition-colors duration-200 hover:bg-white/[0.05] focus-visible:ring-1 focus-visible:ring-accent/60">
          
          <span className="tabular font-mono text-[16px] leading-none text-mist-50">{time}</span>
          <span className="tabular mt-[5px] font-mono text-[8.5px] leading-none text-mist-600">
            {date}
          </span>
        </motion.button>

        <motion.button
          type="button"
          data-testid="open-settings"
          {...tap}
          onPointerDown={() => {
            poke();
            react('nod');
          }}
          onClick={onOpenSettings}
          aria-label="Einstellungen"
          className={`flex h-10 w-10 items-center justify-center rounded-full outline-none transition-colors duration-200 focus-visible:ring-1 focus-visible:ring-accent/60 ${
          settingsActive ? 'bg-accent/[0.15] text-accent-soft' : 'text-mist-500 hover:bg-white/[0.05] hover:text-mist-200'}`
          }>
          
          <SettingsIcon className="h-[17px] w-[17px]" strokeWidth={1.7} aria-hidden="true" />
        </motion.button>
      </div>
    </header>);

}