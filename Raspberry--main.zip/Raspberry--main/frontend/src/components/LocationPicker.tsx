import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MapPinIcon, SearchIcon, XIcon } from 'lucide-react';

const EASE = [0.23, 1, 0.32, 1] as const;

export interface LocationSuggestion {
  name: string;
  admin1?: string;
  country?: string;
  latitude: number;
  longitude: number;
}

interface LocationPickerProps {
  currentPlace: string;
  onPick: (loc: LocationSuggestion) => void;
  onUseCurrent?: () => void;
}

/**
 * A compact touch-friendly place picker. The user types, we hit Open-Meteo's
 * free geocoding endpoint, they tap a result — done. No sign-in, no key, and
 * the dropdown never blocks the rest of the page.
 */
export function LocationPicker({ currentPlace, onPick, onUseCurrent }: LocationPickerProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<LocationSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  // Debounced fetch — Open-Meteo asks nicely for no more than ~1 req / sec.
  useEffect(() => {
    if (!open) return;
    const q = query.trim();
    if (q.length < 2) {
      setResults([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    const handle = window.setTimeout(async () => {
      try {
        const res = await fetch(
          `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=de`
        );
        if (!res.ok) throw new Error('lookup failed');
        const j = await res.json();
        if (cancelled) return;
        setResults(
          (j?.results ?? []).map((r: LocationSuggestion) => ({
            name: r.name,
            admin1: r.admin1,
            country: r.country,
            latitude: r.latitude,
            longitude: r.longitude
          }))
        );
      } catch {
        if (!cancelled) setResults([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(handle);
    };
  }, [query, open]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (ev: MouseEvent) => {
      if (!boxRef.current) return;
      if (!boxRef.current.contains(ev.target as Node)) setOpen(false);
    };
    window.addEventListener('mousedown', onDoc);
    return () => window.removeEventListener('mousedown', onDoc);
  }, [open]);

  useEffect(() => {
    if (open) window.setTimeout(() => inputRef.current?.focus(), 60);
  }, [open]);

  const pick = (loc: LocationSuggestion) => {
    onPick(loc);
    setOpen(false);
    setQuery('');
    setResults([]);
  };

  return (
    <div className="relative" ref={boxRef}>
      <motion.button
        type="button"
        data-testid="weather-location-open"
        onClick={() => setOpen((v) => !v)}
        whileTap={{ scale: 0.97 }}
        transition={{ duration: 0.14, ease: EASE }}
        className="flex h-9 items-center gap-2 rounded-full bg-white/[0.055] pl-3 pr-4 text-mist-200 outline-none transition-colors duration-200 hover:bg-white/[0.09] focus-visible:ring-1 focus-visible:ring-accent/60">
        <MapPinIcon className="h-[14px] w-[14px] text-accent" strokeWidth={1.7} aria-hidden="true" />
        <span className="text-[11.5px] font-light">{currentPlace}</span>
        <span className="ml-1 font-mono text-[9px] uppercase tracking-label text-mist-500">Ort</span>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.98 }}
            transition={{ duration: 0.16, ease: EASE }}
            className="surface absolute right-0 top-[calc(100%+8px)] z-40 w-[300px] p-3"
            data-testid="weather-location-panel">
            <div className="flex items-center gap-2 rounded-full bg-white/[0.06] px-3">
              <SearchIcon className="h-[14px] w-[14px] text-mist-500" strokeWidth={1.7} aria-hidden="true" />
              <input
                ref={inputRef}
                data-testid="weather-location-input"
                value={query}
                onChange={(ev) => setQuery(ev.target.value)}
                placeholder="Stadt suchen…"
                className="h-9 min-w-0 flex-1 bg-transparent text-[12.5px] font-light text-mist-50 outline-none placeholder:text-mist-600"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Suche leeren"
                  className="text-mist-500 hover:text-mist-200">
                  <XIcon className="h-3.5 w-3.5" strokeWidth={1.7} aria-hidden="true" />
                </button>
              )}
            </div>

            <div className="mt-2 max-h-[220px] overflow-y-auto premium-scroll">
              {loading && (
                <p className="px-3 py-2 font-mono text-[9.5px] uppercase tracking-label text-mist-600">
                  Suche…
                </p>
              )}
              {!loading && query.length >= 2 && results.length === 0 && (
                <p className="px-3 py-2 text-[11.5px] font-light text-mist-500">Keine Treffer.</p>
              )}
              {results.map((r) => (
                <button
                  key={`${r.name}-${r.latitude}-${r.longitude}`}
                  type="button"
                  data-testid={`weather-location-result-${r.name}`}
                  onClick={() => pick(r)}
                  className="flex w-full flex-col items-start rounded-[calc(var(--radius)*0.55)] px-3 py-2 text-left transition-colors duration-150 hover:bg-white/[0.06]">
                  <span className="text-[12.5px] font-light text-mist-100">{r.name}</span>
                  <span className="mt-0.5 font-mono text-[9.5px] uppercase tracking-label text-mist-500">
                    {[r.admin1, r.country].filter(Boolean).join(' · ')}
                  </span>
                </button>
              ))}
            </div>

            {onUseCurrent && (
              <button
                type="button"
                data-testid="weather-location-use-current"
                onClick={() => {
                  onUseCurrent();
                  setOpen(false);
                }}
                className="mt-2 flex w-full items-center gap-2 rounded-[calc(var(--radius)*0.55)] px-3 py-2 text-left text-mist-300 transition-colors duration-150 hover:bg-white/[0.06]">
                <MapPinIcon className="h-3.5 w-3.5 text-accent" strokeWidth={1.7} aria-hidden="true" />
                <span className="text-[11.5px] font-light">Mein Standort</span>
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
