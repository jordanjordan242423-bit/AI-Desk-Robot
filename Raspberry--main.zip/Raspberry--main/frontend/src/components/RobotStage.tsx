import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { RobotViewport } from './RobotViewport';
import { useSettings } from '../contexts/SettingsContext';
import { useAttention } from '../contexts/AttentionContext';
import { robotStates } from '../data/robotStates';
import { stats } from '../data/content';
import type { IdlePhase } from '../hooks/useRobotLife';
import type { StateId } from '../types/robot';

interface RobotStageProps {
  state: StateId;
  progress: number;
  phase: IdlePhase;
  onClose: () => void;
}

const EASE = [0.23, 1, 0.32, 1] as const;

/**
 * Robot mode. Everything else steps back: the robot fills the panel, says one
 * short thing, and stays fully interactive — swipe to turn it, tap to come back.
 */
export function RobotStage({ state, progress, phase, onClose }: RobotStageProps) {
  const { settings, personality } = useSettings();
  const { react } = useAttention();
  const def = robotStates[state];
  const [greeting, setGreeting] = useState(settings.greeting !== 'Stumm');

  useEffect(() => {
    react('excited');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!greeting) return;
    const id = window.setTimeout(() => setGreeting(false), 2600);
    return () => window.clearTimeout(id);
  }, [greeting]);

  const asleep = phase === 'asleep';
  const message = asleep ?
  'Ich ruhe kurz.' :
  greeting ?
  settings.greeting :
  def.short[personality.tone];
  const err = state === 'fehler';

  const facts = [
  { label: 'Status', value: asleep ? 'Schlafmodus' : def.label },
  { label: 'Nächster Upload', value: stats.nextUpload },
  { label: 'Heute', value: `${stats.heute} Videos` }];


  return (
    <motion.div
      role="dialog"
      aria-label="Roboter-Modus"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3, ease: EASE }}
      className="absolute inset-0 z-30 flex flex-col items-center"
      style={{ backgroundColor: 'rgb(var(--ink-950) / 0.9)' }}>
      
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        animate={{ opacity: [0.62, 1, 0.62] }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
        style={{
          background:
          'radial-gradient(46% 42% at 50% 44%, rgb(var(--accent) / 0.11) 0%, rgb(var(--accent) / 0) 100%)'
        }} />
      

      <button
        type="button"
        onClick={onClose}
        aria-label="Roboter-Modus schließen"
        className="absolute inset-0 h-full w-full cursor-default outline-none" />
      

      <div className="pointer-events-none relative flex h-full w-full flex-col items-center">
        <div className="flex w-full items-center justify-between px-7 pt-5">
          <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
            Roboter-Modus
          </span>
          <span className="font-mono text-[9px] uppercase tracking-label text-mist-600">
            Wischen zum Drehen · Tippen zum Schließen
          </span>
        </div>

        <div className="pointer-events-auto flex min-h-0 flex-1 items-center justify-center">
          <motion.div layoutId="robot-body" transition={{ duration: 0.44, ease: EASE }}>
            <RobotViewport
              mood={def.mood}
              height={352}
              phase={phase}
              onTap={onClose}
              label="Roboter — tippen zum Schließen, wischen zum Drehen" />
            
          </motion.div>
        </div>

        <div className="flex h-[124px] w-full flex-col items-center px-8">
          <AnimatePresence mode="wait">
            <motion.p
              key={message}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.28, ease: EASE }}
              className="text-center text-[30px] font-extralight leading-none tracking-tight text-mist-50">
              
              {message}
            </motion.p>
          </AnimatePresence>

          <p className={`mt-3 font-mono text-[9.5px] uppercase tracking-label ${err ? 'text-warn' : 'text-accent'}`}>
            {asleep ? 'Schlafmodus' : def.label}
            {state === 'upload' ? ` · ${Math.round(progress * 100)} %` : ''}
          </p>

          <div className="mt-auto mb-5 flex items-center gap-9">
            {facts.map((f) =>
            <div key={f.label} className="text-center">
                <p className="tabular text-[13px] font-light leading-none text-mist-200">{f.value}</p>
                <p className="mt-1.5 font-mono text-[8.5px] uppercase tracking-label text-mist-600">
                  {f.label}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>);

}