# AI Desk Robot Control Center — PRD

## Problem Statement
A futuristic 7-inch landscape touch UI for a desk robot that autonomously creates and publishes short-form videos. The existing React/Vite frontend (from the uploaded ZIP) had a strong visual foundation but needed:
- Real 3D rotation for the robot (unlimited, no snap-back, momentum drift)
- Depth / back plate so the robot reads as a physical object
- Voice setting field, live preview in Settings > Roboter (already present, verified)
- Full reset workflows (Settings only + Everything)
- Migration from CRA-only supervisor script to Vite on port 3000
- All settings persistent via localStorage
- All navigation flows working (Home ↔ Settings ↔ subpages ↔ back)

## Architecture
- **Frontend**: Vite + React 18 + TypeScript + Tailwind 3 + Framer Motion, served by `yarn start` on port 3000 (`vite.config.ts` binds host 0.0.0.0, allowedHosts open for preview URL).
- **State**: `SettingsContext` holds every UI/robot/AI preference, persists to `localStorage['eilik.settings.v2']` on every change.
- **Attention system**: `AttentionContext` tracks idle time and reactions so the robot can react to touch and screen changes.
- **Robot rendering**: Two coordinated SVGs — front `Robot.tsx` (all animation, expressions, gaze life) and back plate `RobotBack.tsx` (rounded shell, cooling vents, sensor pods) inside a single CSS 3D `preserve-3d` wrapper driven by `RobotViewport.tsx`. Opacity cross-fades at ±90° so the correct face is always in front. Rotation is stored as unbounded degrees; release triggers a `requestAnimationFrame` drift with friction — no snap-back, no clamp.
- **Backend**: FastAPI + MongoDB scaffolding is left untouched; the frontend uses mock data from `src/data/content.ts` only, ready to be swapped for API calls later.

## Personas
- Owner of the physical robot device: interacts through touch on a 7" screen. Wants a delightful, alive, customisable companion that does the work of daily content publishing.

## Core Requirements (static)
1. Robot rotates in real 3D, unlimited angle, momentum drift, no snap-back.
2. Robot idle behaviour combines blinking, gaze, posture and flourishes, per personality.
3. Every setting change (Größe, Augenfarbe, Persönlichkeit, Antenne, Gehäusefarbe, UI-Stil, Akzent, Helligkeit …) is applied live and persisted.
4. Themes (Standard, Glas, Bubble, Solid, Minimal) each produce a distinct visual language.
5. Reset Settings and Reset Everything must both work, with confirmation.
6. Optimised for a 1024×600 7" landscape panel, scales to 1280×720 and 1920×1080.

## Implemented (2026-02-12)
- Migrated frontend from CRA to Vite; `yarn start` now runs Vite on port 3000; env preserved (`REACT_APP_BACKEND_URL`).
- Rewrote `RobotViewport.tsx`: unlimited rotation (no ±48° clamp), momentum drift with friction, no snap-back to 0, dual-plane 3D wrapper.
- Added `RobotBack.tsx`: back-of-robot SVG (cooling vents, sensor pods, antenna nub, model tag) rendered at rotateY(180deg) with opacity crossfade.
- Added missing `voice` field to `Settings` type + defaults so `SettingsRobot` compiles cleanly.
- Rewrote `SettingsAbout.tsx`: two separate reset flows (Einstellungen zurücksetzen, Alles zurücksetzen) each with confirm/cancel; "Alles" wipes every `eilik.*` localStorage key and reloads.
- Added `data-testid`s for automated testing (`robot-viewport`, `open-settings`, `settings-nav-*`, `reset-settings`, `reset-everything`).

## Implemented (2026-02-12, wave 2)
- **Rotation-Persistenz**: `RobotViewport` accepts a `persistKey` and stores the current angle in `localStorage['eilik.robot.rotY']` on every change. The home viewport uses it, so the robot keeps its pose across reloads and restarts.
- **Seitenprofil-Panels**: added two thin CSS-3D side strips at ±90° inside the viewport wrapper, each fading in through a `sin(rot)` transform. The robot now visibly has volume as it turns, not just two flat faces.
- **Live-Wetter**: new `useWeather` hook talks to Open-Meteo (no API key) with a 20-minute cache in `localStorage['eilik.weather.v1']`, WMO-code-to-German translation, WMO→Sky icon mapping, geolocation fallback, and a static-mock fallback. `Home.tsx` and `Wetter.tsx` both consume it, so the same forecast is shown everywhere and updates on its own.
- **Themes-Vorschaugitter**: new `ThemesPreviewGrid` component replaces the plain segmented control in `SettingsAppearance`. Each tile forces its own `data-ui` scope so the surface inside the tile is drawn in that theme (Standard, Glas, Bubble, Solid, Minimal) — picking is now visual, not text-only.

## Implemented (2026-02-12, wave 3)
- **Themes im Detail**: rewrote the `[data-ui='glass']` and `[data-ui='bubble']` CSS rules with proper visual identity — Glass now has multi-stop diagonal light gradient, side-specific border colours (top/left catch light, bottom/right darken), stronger blur+saturation+brightness backdrop-filter, and a `::after` top-highlight sheen. Bubble has extra-round corners, radial top gloss, `::before` shine strip, and a much larger soft shadow so surfaces feel physically raised.
- **Ortsauswahl Wetter**: new `LocationPicker` component (Open-Meteo geocoding, no API key) with debounced type-ahead, "Mein Standort" browser-geolocation fallback, keyboard-friendly search. Added `weatherPlace / weatherLat / weatherLon / weatherUseBrowserLocation` to `Settings` type. Wetter header and Home both feed the settings into `useWeather`, so switching city updates every panel and persists.
- **Roboter berührt zurück**: `RobotViewport` now animates `dragLean` (rotateZ ±9°) and `dragScale` (0.985) during pointer drag, springing back on release. The robot visibly tilts toward the finger direction and gives a soft squish on contact.
- **System Live-Metriken**: new `/api/system/metrics` FastAPI endpoint using psutil (CPU %, RAM %, disk %, CPU temperature via `sensors_temperatures()` with sensible fallbacks, uptime, load averages, hostname). New `useSystemMetrics` hook polls every 4 s and gracefully falls back to the mock. Home tile and System page both use it — verified live values (CPU 26 %, RAM 61 %, Disk 36 %).

## Implemented (2026-02-12, wave 4)
- **Süßer Roboter beibehalten**: rolled back the R3F canvas experiment. The SVG `Robot` + `RobotBack` + side profile strips are the character; only the wrapper is CSS 3D. Removed three, @react-three/fiber and @react-three/drei from dependencies.
- **Netzwerk Live-Status**: new `/api/system/network` endpoint using psutil `net_if_addrs / net_if_stats / net_io_counters` plus a best-effort `nmcli` / `iwgetid` shell-out for SSID + signal. New `useNetworkStatus` hook computes rolling download/upload throughput on the client. Netzwerk page shows live SSID, IP, signal, backend reachability, link speed, sent/received bytes and lists secondary interfaces. Status bar SSID chip and the top-of-screen network status pull from the same feed. Verified: `ETH0`, `10.231.166.124`, 92 %, backend online, 199 MB sent / 209 MB recv, 10000 Mbit/s.
- **Wetter-Widgets pinnen**: new `WeatherPinPicker` (pin icon on the Home weather tile) opens a check-list of every weather field (Regen, Wind, Feuchte, Gefühlt, UV, Druck, Aufgang, Untergang, Höchst, Tiefst). Selection persists in the new `homeWeatherPins` settings array (capped at 4). The Home weather tile renders those pins live — verified: Regen 0 %, Wind 14 km/h, UV Mittel, Untergang 19:39.
- **Idle-Drift**: `RobotViewport` starts a gentle sinusoidal sway ±1.6-5.5° (per idle setting) after 4.2 s without interaction and stops the moment the user touches or swipes. Runs on `requestAnimationFrame` with a 350 ms poller so idle CPU cost stays negligible.

## Prioritised Backlog
### P0 (blocking wow-moment for the physical device)
- Wire System page to a real `/api/system` endpoint (CPU/RAM/temp) once backend is enabled.
- Wire Netzwerk page to real `/api/network` endpoint.

### P1 (next iteration polish)
- Weather API integration (currently mock from `content.ts`).
- Pipeline hook `usePipeline` should subscribe to backend pipeline events instead of local timers.
- Add subtle side-panel shading strips at 90° and 270° for even richer volumetric rotation feel.
- Add haptic-style micro-flash on the robot when a setting is changed (already partially: `react('excited')`).

### P2 (nice-to-have)
- Persist the last rotation angle so the robot keeps its pose across reloads.
- Themes preview grid in Settings > Darstellung.
- Add screensaver-style burn-in prevention for the 7" panel over long uptime.
