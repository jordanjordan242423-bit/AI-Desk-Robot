/**
 * dashboard.js — Steuerlogik des Hauptdashboards.
 * Reines Vanilla-JS, kein Framework, keine CDN-Abhängigkeit (funktioniert offline).
 */
(() => {
  const STATUS_LABELS = {
    IDLE: "BEREIT", WAITING: "WARTEN", RESEARCH: "RECHERCHE", THINKING: "DENKT NACH",
    WRITING: "SCHREIBT SKRIPT", TTS: "SPRACHE WIRD ERZEUGT", VIDEO: "VIDEO WIRD ERSTELLT",
    UPLOAD: "UPLOAD LÄUFT", SUCCESS: "ERFOLGREICH", ERROR: "FEHLER",
  };

  const PROCESS_ICON_DONE = `<svg viewBox="0 0 24 24" fill="none" stroke="#3ddc97" stroke-width="2.4"><path d="M5 13l4 4L19 7"/></svg>`;
  const PROCESS_ICON_ACTIVE = `<svg viewBox="0 0 24 24" fill="none" stroke="#4be3ff" stroke-width="2.4"><circle cx="12" cy="12" r="8"/></svg>`;
  const PROCESS_ICON_PENDING = `<svg viewBox="0 0 24 24" fill="none" stroke="#56707c" stroke-width="2"><circle cx="12" cy="12" r="8"/></svg>`;
  const PROCESS_ICON_FAILED = `<svg viewBox="0 0 24 24" fill="none" stroke="#ff5d6c" stroke-width="2.4"><path d="M6 6l12 12M18 6L6 18"/></svg>`;

  let currentView = "main";

  function $(sel) { return document.querySelector(sel); }
  function $all(sel) { return document.querySelectorAll(sel); }

  function setBarLevel(el, percent, warnAt = 70, critAt = 90) {
    el.style.width = Math.min(100, Math.max(0, percent)) + "%";
    el.classList.remove("warn", "crit");
    if (percent >= critAt) el.classList.add("crit");
    else if (percent >= warnAt) el.classList.add("warn");
  }

  function fmtBytesGB(gb) { return gb == null ? "–" : `${gb} GB`; }

  // -----------------------------------------------------------------
  // Uhrzeit / Datum (lokal, kein Server-Roundtrip nötig)
  // -----------------------------------------------------------------
  function tickClock() {
    const now = new Date();
    $("#tb-time").textContent = now.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
    $("#tb-date").textContent = now.toLocaleDateString("de-DE", { weekday: "short", day: "2-digit", month: "2-digit" });
  }

  // -----------------------------------------------------------------
  // Status-Polling
  // -----------------------------------------------------------------
  async function pollStatus() {
    try {
      const resp = await fetch("/api/status");
      if (!resp.ok) throw new Error("HTTP " + resp.status);
      const data = await resp.json();
      renderStatus(data);
    } catch (e) {
      // Backend kurzzeitig nicht erreichbar (z.B. Neustart) - Dashboard bleibt stehen und versucht es weiter
      console.warn("Status-Abruf fehlgeschlagen:", e);
    }
  }

  function renderStatus(data) {
    const sys = data.system || {};
    const ram = sys.ram || {};
    const disk = sys.disk || {};

    $("#m-cpu").textContent = (sys.cpu_percent ?? "–") + " %";
    setBarLevel($("#m-cpu-bar"), sys.cpu_percent || 0);

    $("#m-ram").textContent = `${ram.used_mb ?? "–"} / ${ram.total_mb ?? "–"} MB`;
    setBarLevel($("#m-ram-bar"), ram.percent || 0);

    $("#m-disk").textContent = `${disk.used_gb ?? "–"} / ${disk.total_gb ?? "–"} GB`;
    setBarLevel($("#m-disk-bar"), disk.percent || 0);

    const temp = sys.temperature_c;
    $("#m-temp").textContent = temp != null ? `${temp} °C` : "n/v";
    setBarLevel($("#m-temp-bar"), temp != null ? (temp / 85) * 100 : 0, 70, 85);

    $("#m-uptime").textContent = sys.uptime_label || "–";

    setDot("internet", sys.internet, sys.internet ? "Verbunden" : "Offline");
    setDot("ollama", sys.ollama, sys.ollama ? "Aktiv" : "Fallback");
    setDot("piper", sys.piper, sys.piper ? "Bereit" : "Fallback");
    setDot("tiktok", sys.tiktok_connected, sys.tiktok_connected ? "Verbunden" : "Nicht verbunden");

    const w = data.weather || {};
    $("#tb-weather").textContent = w.available
      ? `${Math.round(w.temperature_c)}°C ${w.condition}`
      : "Wetter nicht konfiguriert";
    $("#tb-network").textContent = sys.internet ? "Online" : "Offline";

    renderFace(data.agent || {});
    renderBottomBar(data.stats || {});
    renderManualUploadIndicator(data.stats || {});
  }

  function renderManualUploadIndicator(stats) {
    const tiktokNavBtn = document.querySelector('.nav-btn[data-view="tiktok"]');
    if (!tiktokNavBtn) return;
    let dot = tiktokNavBtn.querySelector(".manual-upload-dot");
    const needsAttention = (stats.ready_for_upload || 0) > 0;
    if (needsAttention && !dot) {
      dot = document.createElement("span");
      dot.className = "manual-upload-dot";
      dot.style.cssText = "position:absolute; top:2px; right:2px; width:10px; height:10px; border-radius:50%; background:#ffb648; box-shadow:0 0 6px rgba(255,182,72,0.7);";
      tiktokNavBtn.style.position = "relative";
      tiktokNavBtn.appendChild(dot);
    } else if (!needsAttention && dot) {
      dot.remove();
    }
  }

  function setDot(key, ok, label) {
    const dot = $(`#dot-${key}`);
    const txt = $(`#txt-${key}`);
    dot.className = "status-dot " + (ok ? "ok" : "off");
    txt.textContent = label;
  }

  function renderFace(agent) {
    Face.setState(agent.face_state || "IDLE", agent.face_emotion || "neutral");
    $("#face-status-label").textContent = STATUS_LABELS[agent.face_state] || agent.face_state || "BEREIT";
    $("#face-status-sub").textContent = agent.message || "";

    const job = agent.job;
    $("#topic-value").textContent = job && job.topic ? job.topic : "Noch kein Thema gewählt";

    const process = agent.process || [];
    const doneCount = process.filter(p => p.status === "done").length;
    const progressPct = process.length ? Math.round((doneCount / process.length) * 100) : 0;
    $("#face-progress").style.width = progressPct + "%";

    const list = $("#process-list");
    list.innerHTML = "";
    process.forEach(p => {
      const row = document.createElement("div");
      row.className = "process-item " + p.status;
      const icon = p.status === "done" ? PROCESS_ICON_DONE
        : p.status === "active" ? PROCESS_ICON_ACTIVE
        : p.status === "failed" ? PROCESS_ICON_FAILED
        : PROCESS_ICON_PENDING;
      row.innerHTML = `<span class="process-icon">${icon}</span><span>${p.label}</span>`;
      list.appendChild(row);
    });

    $("#s-status").textContent = STATUS_LABELS[agent.face_state] || "Bereit";
  }

  function renderBottomBar(stats) {
    $("#s-today").textContent = stats.today ?? 0;
    $("#s-last-upload").textContent = stats.last_upload
      ? new Date(stats.last_upload).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })
      : "Noch keiner";
    $("#s-next-run").textContent = "Automatisch";
    $("#s-free-space").textContent = "siehe System";

    $("#st-total").textContent = stats.total ?? 0;
    $("#st-published").textContent = stats.published ?? 0;
    $("#st-ready").textContent = stats.ready_for_upload ?? 0;
    $("#st-failed").textContent = stats.failed ?? 0;
    $("#st-today").textContent = stats.today ?? 0;
  }

  // -----------------------------------------------------------------
  // Ansichtswechsel (Touch-Navigation, Abschnitt 21-22)
  // -----------------------------------------------------------------
  function switchView(view) {
    currentView = view;
    $all(".view").forEach(v => v.classList.remove("active"));
    $(`#view-${view}`).classList.add("active");
    $all(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === view));

    if (view === "videos") loadVideos();
    if (view === "tiktok") loadTiktok();
    if (view === "stats") loadStatsJobs();
    if (view === "logs") loadLogs();
    if (view === "settings") loadSettings();
    if (view === "system") loadSystemDetail();
  }

  $all(".nav-btn").forEach(btn => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
    btn.addEventListener("touchend", (e) => { e.preventDefault(); switchView(btn.dataset.view); });
  });

  // -----------------------------------------------------------------
  // Videos-Ansicht
  // -----------------------------------------------------------------
  function statusBadge(status) {
    const cls = ["READY", "PUBLISHED", "FAILED"].includes(status) ? status : "default";
    return `<span class="badge ${cls}">${status}</span>`;
  }

  async function loadVideos() {
    const resp = await fetch("/api/jobs?limit=60");
    const jobs = await resp.json();
    const grid = $("#videos-grid");
    grid.innerHTML = "";
    if (!jobs.length) {
      grid.innerHTML = `<div class="empty-hint">Noch keine Videos erstellt.</div>`;
      return;
    }
    jobs.forEach(job => {
      const card = document.createElement("div");
      card.className = "panel video-card";
      const duration = job.duration_s ? `${Math.round(job.duration_s)}s` : "–";
      const size = job.filesize_bytes ? `${(job.filesize_bytes / 1024 / 1024).toFixed(1)} MB` : "–";
      const manualBtn = job.status === "READY"
        ? `<a class="btn" style="display:block; margin-top:8px; text-align:center; font-size:11px; padding:8px;" href="/tiktok/manual/${job.id}">📤 Manuell hochladen</a>`
        : "";
      card.innerHTML = `
        <div class="thumb">${job.video_file ? "🎬" : "…"}</div>
        <div class="title">${job.title || job.topic || job.id}</div>
        <div class="meta"><span>${duration} · ${size}</span>${statusBadge(job.status)}</div>
        ${manualBtn}
      `;
      grid.appendChild(card);
    });
  }

  // -----------------------------------------------------------------
  // TikTok-Ansicht
  // -----------------------------------------------------------------
  async function loadTiktok() {
    const resp = await fetch("/api/status");
    const data = await resp.json();
    const box = $("#tiktok-status-box");
    if (!data.tiktok_configured) {
      box.innerHTML = `<div class="empty-hint" style="text-align:left;">
        TikTok ist noch nicht konfiguriert. Trage TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET und
        TIKTOK_REDIRECT_URI in der .env-Datei ein, um die offizielle TikTok Content Posting API
        zu verbinden. Videos werden trotzdem produziert und stehen für den manuellen Upload bereit.
      </div>`;
    } else if (data.tiktok_connected) {
      box.innerHTML = `<div style="display:flex; align-items:center; justify-content:space-between;">
        <span><span class="status-dot ok"></span>Mit TikTok verbunden (offizielle API)</span>
        <button class="btn danger" id="btn-tiktok-disconnect">Trennen</button>
      </div>`;
      $("#btn-tiktok-disconnect").addEventListener("click", async () => {
        await fetch("/api/tiktok/disconnect", { method: "POST" });
        loadTiktok();
      });
    } else {
      box.innerHTML = `<div style="display:flex; align-items:center; justify-content:space-between;">
        <span><span class="status-dot off"></span>Noch nicht verbunden</span>
        <a class="btn" href="/tiktok/connect">Mit TikTok verbinden</a>
      </div>`;
    }

    const urlResp = await fetch("/api/upload-url");
    const urlData = await urlResp.json();
    $("#upload-url").textContent = urlData.url;

    const jobsResp = await fetch("/api/jobs?limit=30");
    const jobs = await jobsResp.json();
    const grid = $("#tiktok-video-grid");
    grid.innerHTML = "";
    const relevantJobs = jobs.filter(j => ["READY", "PUBLISHED", "UPLOADING"].includes(j.status));
    if (!relevantJobs.length) {
      grid.innerHTML = `<div class="empty-hint">Noch keine hochladbaren Videos vorhanden.</div>`;
    }
    let anyNeedsManualUpload = false;
    relevantJobs.forEach(job => {
      const card = document.createElement("div");
      card.className = "panel video-card";
      const needsManual = job.status === "READY";
      if (needsManual) anyNeedsManualUpload = true;
      const manualButton = needsManual
        ? `<a class="btn" style="display:block; margin-top:10px; text-align:center;" href="/tiktok/manual/${job.id}">📤 Manuell auf TikTok hochladen</a>`
        : "";
      const errorNote = job.error
        ? `<div style="font-size:10px; color:#ff9aa4; margin-top:6px;">${job.error}</div>`
        : "";
      card.innerHTML = `
        <div class="thumb">🎬</div>
        <div class="title">${job.title || job.topic}</div>
        <div class="meta"><span>${job.hashtags || ""}</span>${statusBadge(job.status)}</div>
        ${errorNote}
        ${manualButton}
      `;
      grid.appendChild(card);
    });
  }

  // -----------------------------------------------------------------
  // Statistik-Ansicht
  // -----------------------------------------------------------------
  async function loadStatsJobs() {
    const resp = await fetch("/api/jobs?limit=30");
    const jobs = await resp.json();
    const box = $("#stats-job-list");
    box.innerHTML = "";
    jobs.forEach(job => {
      const row = document.createElement("div");
      row.className = "log-line";
      row.innerHTML = `<span class="time">${new Date(job.created_at).toLocaleString("de-DE")}</span>${job.topic || job.id} ${statusBadge(job.status)}`;
      box.appendChild(row);
    });
    const statsResp = await fetch("/api/stats");
    const stats = await statsResp.json();
    renderBottomBar(stats);
  }

  // -----------------------------------------------------------------
  // Logs-Ansicht
  // -----------------------------------------------------------------
  async function loadLogs() {
    const resp = await fetch("/api/logs?limit=250");
    const logs = await resp.json();
    const box = $("#logs-box");
    box.innerHTML = logs.map(l => `<div class="log-line ${l.level}"><span class="time">${l.time}</span>${l.message}</div>`).join("");
    box.scrollTop = box.scrollHeight;
  }

  // -----------------------------------------------------------------
  // Einstellungen-Ansicht
  // -----------------------------------------------------------------
  async function loadSettings() {
    const resp = await fetch("/api/settings");
    const cfg = await resp.json();
    $("#set-videos-per-day").value = cfg.videos_per_day ?? 2;
    $("#set-min-hours").value = cfg.min_hours_between_videos ?? 3;
    $("#set-ollama-model").value = (cfg.llm && cfg.llm.ollama_model) || "";
  }

  $("#btn-save-settings").addEventListener("click", async () => {
    const payload = {
      videos_per_day: parseInt($("#set-videos-per-day").value || "2", 10),
      min_hours_between_videos: parseInt($("#set-min-hours").value || "3", 10),
    };
    await fetch("/api/settings", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    switchView("settings");
  });

  $("#btn-run-now").addEventListener("click", async () => {
    const resp = await fetch("/api/agent/run-now", { method: "POST" });
    const data = await resp.json();
    if (!data.started) {
      alert("Es läuft bereits ein Job oder das Tageslimit wurde erreicht.");
    }
  });

  // -----------------------------------------------------------------
  // System-Ansicht (Detailwerte)
  // -----------------------------------------------------------------
  async function loadSystemDetail() {
    const resp = await fetch("/api/status");
    const data = await resp.json();
    const sys = data.system || {};
    const grid = $("#system-detail-grid");
    grid.innerHTML = `
      <div class="setting-field"><label>CPU-Auslastung</label><div>${sys.cpu_percent ?? "–"} %</div></div>
      <div class="setting-field"><label>RAM</label><div>${sys.ram?.used_mb ?? "–"} / ${sys.ram?.total_mb ?? "–"} MB</div></div>
      <div class="setting-field"><label>Speicher frei</label><div>${fmtBytesGB(sys.disk?.free_gb)}</div></div>
      <div class="setting-field"><label>Temperatur</label><div>${sys.temperature_c != null ? sys.temperature_c + " °C" : "nicht verfügbar (kein Raspberry-Sensor erkannt)"}</div></div>
      <div class="setting-field"><label>Uptime</label><div>${sys.uptime_label ?? "–"}</div></div>
      <div class="setting-field"><label>Internet</label><div>${sys.internet ? "Verbunden" : "Offline"}</div></div>
      <div class="setting-field"><label>Ollama</label><div>${sys.ollama ? "Aktiv" : "Nicht erreichbar (Fallback aktiv)"}</div></div>
      <div class="setting-field"><label>TTS-Engine</label><div>${sys.piper ? "Piper bereit" : "espeak-ng Fallback"}</div></div>
    `;
  }

  // -----------------------------------------------------------------
  // Start
  // -----------------------------------------------------------------
  Face.mount($("#face-stage"));
  tickClock();
  setInterval(tickClock, 1000);
  pollStatus();
  setInterval(pollStatus, 2000);
})();
