/**
 * face.js — Animations-Engine für das KI-Robotergesicht.
 *
 * Rendert das Gesicht als reines SVG (kein Canvas nötig), animiert per
 * requestAnimationFrame + CSS-Transitions. Keine externen Bibliotheken,
 * läuft komplett offline auf dem Raspberry Pi.
 *
 * Zustände (siehe Master-Prompt Abschnitt 4-6 + 24):
 *   IDLE, RESEARCH, THINKING, WRITING, TTS, VIDEO, SUCCESS, ERROR, WAITING, UPLOAD
 *
 * Öffentliche API:
 *   Face.mount(containerEl)   -> baut das SVG einmalig auf
 *   Face.setState(state, emotion) -> wechselt Zustand/Emotion (animiert weich)
 */
const Face = (() => {
  const SVG_NS = "http://www.w3.org/2000/svg";
  let root = null;
  let eyeL, eyeR, pupilL, pupilR, lidL, lidR, mouthPath, faceGroup;
  let currentState = "IDLE";
  let currentEmotion = "neutral";
  let lookTarget = { x: 0, y: 0 };
  let lookCurrent = { x: 0, y: 0 };
  let blinkTimer = 0;
  let nextBlinkAt = 2500;
  let idleLookTimer = 0;
  let nextIdleLookAt = 3000;
  let talkPhase = 0;
  let raf = null;

  function el(tag, attrs) {
    const e = document.createElementNS(SVG_NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }

  // -------------------------------------------------------------------
  // Mund-Pfade je Zustand (Viewbox 0..240 x 0..240, Mund um y=176)
  // -------------------------------------------------------------------
  const MOUTH_PATHS = {
    IDLE:     "M 96 174 Q 120 186 144 174",
    WAITING:  "M 98 176 Q 120 182 142 176",
    RESEARCH: "M 100 178 Q 120 176 140 178",
    THINKING: "M 98 180 Q 120 174 142 180",
    WRITING:  "M 98 177 Q 120 183 142 177",
    VIDEO:    "M 96 176 Q 120 188 144 176",
    UPLOAD:   "M 98 176 Q 120 186 142 176",
    SUCCESS:  "M 92 172 Q 120 196 148 172",
    ERROR:    "M 96 184 Q 120 170 144 184",
    TTS_A:    "M 100 172 Q 120 194 140 172",
    TTS_B:    "M 104 176 Q 120 182 136 176",
  };

  function buildSVG() {
    const svg = el("svg", { viewBox: "0 0 240 240", xmlns: SVG_NS });

    const defs = el("defs", {});
    defs.innerHTML = `
      <radialGradient id="headGrad" cx="35%" cy="30%" r="80%">
        <stop offset="0%" stop-color="#1c2f38"/>
        <stop offset="55%" stop-color="#101c22"/>
        <stop offset="100%" stop-color="#060b0e"/>
      </radialGradient>
      <linearGradient id="edgeGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#4be3ff" stop-opacity="0.9"/>
        <stop offset="50%" stop-color="#17b8d6" stop-opacity="0.25"/>
        <stop offset="100%" stop-color="#4be3ff" stop-opacity="0.9"/>
      </linearGradient>
      <radialGradient id="eyeGlow" cx="50%" cy="45%" r="60%">
        <stop offset="0%" stop-color="#bffaff"/>
        <stop offset="35%" stop-color="#4be3ff"/>
        <stop offset="75%" stop-color="#0f8fae"/>
        <stop offset="100%" stop-color="#063846"/>
      </radialGradient>
      <radialGradient id="irisDark" cx="50%" cy="50%" r="60%">
        <stop offset="0%" stop-color="#08181c"/>
        <stop offset="100%" stop-color="#01090b"/>
      </radialGradient>
      <filter id="softGlow" x="-60%" y="-60%" width="220%" height="220%">
        <feGaussianBlur stdDeviation="4.2" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
      <filter id="bigGlow" x="-80%" y="-80%" width="260%" height="260%">
        <feGaussianBlur stdDeviation="9" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    `;
    svg.appendChild(defs);

    faceGroup = el("g", { id: "faceGroup" });
    svg.appendChild(faceGroup);

    // Kopfform (weiche, futuristische Rundung mit Cyan-Kante)
    faceGroup.appendChild(el("rect", {
      x: 14, y: 14, width: 212, height: 212, rx: 58,
      fill: "url(#headGrad)", stroke: "url(#edgeGrad)", "stroke-width": 2.5,
    }));
    faceGroup.appendChild(el("rect", {
      x: 20, y: 20, width: 200, height: 200, rx: 52,
      fill: "none", stroke: "rgba(75,227,255,0.12)", "stroke-width": 1,
    }));

    // Augenbrauen-/Lid-Schatten-Bereich (dezente Tiefe oberhalb der Augen)
    faceGroup.appendChild(el("ellipse", {
      cx: 120, cy: 92, rx: 96, ry: 46, fill: "rgba(0,0,0,0.18)",
    }));

    // -------- Augen --------
    function buildEye(cx) {
      const g = el("g", { class: "eye-group", "data-cx": cx });

      const socket = el("ellipse", {
        cx, cy: 108, rx: 40, ry: 46, fill: "#03080a",
        stroke: "rgba(75,227,255,0.18)", "stroke-width": 1.5,
      });
      g.appendChild(socket);

      const glowBack = el("ellipse", {
        cx, cy: 108, rx: 36, ry: 42, fill: "url(#eyeGlow)", opacity: 0.9, filter: "url(#softGlow)",
      });
      g.appendChild(glowBack);

      const irisDark = el("ellipse", { cx, cy: 108, rx: 20, ry: 24, fill: "url(#irisDark)" });
      g.appendChild(irisDark);

      const pupilGroup = el("g", { class: "pupil-group" });
      const pupilGlow = el("ellipse", { cx, cy: 108, rx: 14, ry: 17, fill: "#4be3ff", opacity: 0.85, filter: "url(#softGlow)" });
      const pupilCore = el("ellipse", { cx, cy: 108, rx: 8, ry: 10, fill: "#e8fdff" });
      const reflection1 = el("circle", { cx: cx - 5, cy: 100, r: 3.4, fill: "#ffffff", opacity: 0.95 });
      const reflection2 = el("circle", { cx: cx + 6, cy: 112, r: 1.6, fill: "#ffffff", opacity: 0.6 });
      pupilGroup.appendChild(pupilGlow);
      pupilGroup.appendChild(pupilCore);
      pupilGroup.appendChild(reflection1);
      pupilGroup.appendChild(reflection2);
      g.appendChild(pupilGroup);

      const lid = el("rect", {
        class: "eyelid", x: cx - 42, y: 60, width: 84, height: 0, fill: "#0a141a",
      });
      g.appendChild(lid);

      return { g, pupilGroup, lid };
    }

    const left = buildEye(80);
    const right = buildEye(160);
    faceGroup.appendChild(left.g);
    faceGroup.appendChild(right.g);
    eyeL = left.g; pupilL = left.pupilGroup; lidL = left.lid;
    eyeR = right.g; pupilR = right.pupilGroup; lidR = right.lid;

    // -------- Mund --------
    mouthPath = el("path", {
      d: MOUTH_PATHS.IDLE, fill: "none", stroke: "#4be3ff",
      "stroke-width": 5, "stroke-linecap": "round", filter: "url(#softGlow)",
    });
    faceGroup.appendChild(mouthPath);

    // Status-Glow-Ring um das ganze Gesicht (ändert Farbe je nach Emotion)
    const statusRing = el("rect", {
      id: "statusRing", x: 6, y: 6, width: 228, height: 228, rx: 62,
      fill: "none", stroke: "#4be3ff", "stroke-width": 1.5, opacity: 0.35, filter: "url(#bigGlow)",
    });
    faceGroup.insertBefore(statusRing, faceGroup.firstChild);

    return svg;
  }

  function mount(container) {
    root = container;
    root.innerHTML = "";
    const svg = buildSVG();
    root.appendChild(svg);
    if (!raf) loop();
  }

  const EMOTION_COLORS = {
    neutral: "#4be3ff",
    focused: "#4be3ff",
    happy: "#3ddc97",
    concerned: "#ff5d6c",
  };

  function applyEmotionColor(emotion) {
    const color = EMOTION_COLORS[emotion] || EMOTION_COLORS.neutral;
    const ring = root.querySelector("#statusRing");
    if (ring) ring.setAttribute("stroke", color);
    if (mouthPath) mouthPath.setAttribute("stroke", color);
  }

  function setMouth(stateKey) {
    const d = MOUTH_PATHS[stateKey] || MOUTH_PATHS.IDLE;
    if (mouthPath) mouthPath.setAttribute("d", d);
  }

  // Blickrichtung je Zustand (leichte, glaubwürdige Bewegungen, siehe Abschnitt 4)
  const STATE_LOOK = {
    IDLE: () => ({ x: 0, y: 0 }),
    WAITING: () => ({ x: 0, y: 2 }),
    RESEARCH: () => ({ x: (Math.random() - 0.5) * 14, y: -4 }),
    THINKING: () => ({ x: 8, y: -8 }),
    WRITING: () => ({ x: -6, y: 5 }),
    VIDEO: () => ({ x: (Math.random() - 0.5) * 8, y: -2 }),
    UPLOAD: () => ({ x: 0, y: -6 }),
    SUCCESS: () => ({ x: 0, y: 0 }),
    ERROR: () => ({ x: 0, y: 3 }),
    TTS: () => ({ x: 0, y: 0 }),
  };

  function setState(stateKey, emotion) {
    currentState = stateKey || "IDLE";
    currentEmotion = emotion || "neutral";
    applyEmotionColor(currentEmotion);
    if (currentState !== "TTS") setMouth(currentState);
    const fn = STATE_LOOK[currentState] || STATE_LOOK.IDLE;
    lookTarget = fn();
  }

  function blink() {
    [lidL, lidR].forEach((lid) => {
      lid.style.transition = "height 90ms ease-in";
      lid.setAttribute("height", "92");
    });
    setTimeout(() => {
      [lidL, lidR].forEach((lid) => {
        lid.style.transition = "height 140ms ease-out";
        lid.setAttribute("height", "0");
      });
    }, 110);
  }

  function loop(ts) {
    if (ts === undefined) ts = performance.now();
    raf = requestAnimationFrame(loop);
    const dt = 16;

    // Blinzeln (natürlich, nicht nervös - alle 2.5-6s)
    blinkTimer += dt;
    if (blinkTimer > nextBlinkAt) {
      blink();
      blinkTimer = 0;
      nextBlinkAt = 2500 + Math.random() * 3500;
    }

    // Idle: gelegentliche kleine, unabhängige Blickwechsel
    if (currentState === "IDLE" || currentState === "WAITING") {
      idleLookTimer += dt;
      if (idleLookTimer > nextIdleLookAt) {
        lookTarget = { x: (Math.random() - 0.5) * 10, y: (Math.random() - 0.5) * 6 };
        idleLookTimer = 0;
        nextIdleLookAt = 2600 + Math.random() * 3000;
      }
    }

    // Sanftes Nachführen der Pupillen (kein Zappeln, weiches Easing)
    lookCurrent.x += (lookTarget.x - lookCurrent.x) * 0.06;
    lookCurrent.y += (lookTarget.y - lookCurrent.y) * 0.06;

    // Atmen/Pulsieren
    const breathe = Math.sin(ts / 1400) * 1.4;

    if (pupilL) pupilL.setAttribute("transform", `translate(${lookCurrent.x} ${lookCurrent.y + breathe * 0.2})`);
    if (pupilR) pupilR.setAttribute("transform", `translate(${lookCurrent.x} ${lookCurrent.y + breathe * 0.2})`);
    if (faceGroup) faceGroup.setAttribute("transform", `translate(0 ${breathe * 0.6})`);

    // TTS: glaubwürdige Mundbewegung synchron zur "Sprachproduktion"
    if (currentState === "TTS") {
      talkPhase += dt / 90;
      const open = (Math.sin(talkPhase) + 1) / 2;
      setMouth(open > 0.5 ? "TTS_A" : "TTS_B");
    }

    // VIDEO/UPLOAD: leichte zusätzliche Glow-Pulsation am Ring
    if (currentState === "VIDEO" || currentState === "UPLOAD") {
      const ring = root && root.querySelector("#statusRing");
      if (ring) ring.setAttribute("opacity", (0.3 + Math.abs(Math.sin(ts / 500)) * 0.35).toFixed(2));
    } else {
      const ring = root && root.querySelector("#statusRing");
      if (ring) ring.setAttribute("opacity", "0.35");
    }
  }

  return { mount, setState };
})();
