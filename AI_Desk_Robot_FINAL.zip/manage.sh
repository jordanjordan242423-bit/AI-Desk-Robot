#!/usr/bin/env bash
# ==============================================================================
# manage.sh - zentrale Verwaltung für AI Desk Robot (Master-Prompt Abschnitt 50)
#
# Nutzung: ./manage.sh <befehl>
#   start     - Dienste starten
#   stop      - Dienste stoppen
#   restart   - Dienste neu starten
#   status    - Status anzeigen
#   logs      - Live-Logs anzeigen (Backend)
#   test      - automatisierte Tests ausführen
#   backup    - Datenbank + Konfiguration sichern
#   update    - Python-Abhängigkeiten aktualisieren + Dienste neu starten
# ==============================================================================
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'
HAVE_SYSTEMD=false
command -v systemctl > /dev/null 2>&1 && HAVE_SYSTEMD=true

usage() {
  echo "Nutzung: ./manage.sh {start|stop|restart|status|logs|test|backup|update}"
  exit 1
}

cmd_start() {
  if $HAVE_SYSTEMD; then
    sudo systemctl start ai-desk-robot-backend.service
    sudo systemctl start ai-desk-robot-kiosk.service 2>/dev/null || true
    echo -e "${GREEN}Gestartet.${NC}"
  else
    echo "Kein systemd verfügbar - starte im Vordergrund (Strg+C zum Beenden):"
    "$SCRIPT_DIR/venv/bin/python" -m app.main
  fi
}

cmd_stop() {
  if $HAVE_SYSTEMD; then
    sudo systemctl stop ai-desk-robot-backend.service
    sudo systemctl stop ai-desk-robot-kiosk.service 2>/dev/null || true
    echo -e "${GREEN}Gestoppt.${NC}"
  else
    echo "Kein systemd verfügbar - bitte den Python-Prozess manuell beenden (Strg+C)."
  fi
}

cmd_restart() {
  if $HAVE_SYSTEMD; then
    sudo systemctl restart ai-desk-robot-backend.service
    sudo systemctl restart ai-desk-robot-kiosk.service 2>/dev/null || true
    echo -e "${GREEN}Neu gestartet.${NC}"
  else
    cmd_stop; cmd_start
  fi
}

cmd_status() {
  if $HAVE_SYSTEMD; then
    echo "--- Backend ---"
    systemctl status ai-desk-robot-backend.service --no-pager -l | head -20
    echo ""
    echo "--- Kiosk ---"
    systemctl status ai-desk-robot-kiosk.service --no-pager -l 2>/dev/null | head -20 || echo "(nicht eingerichtet)"
  else
    echo "Kein systemd verfügbar."
  fi
  echo ""
  PORT=$(grep -E '^FLASK_PORT=' .env 2>/dev/null | cut -d= -f2)
  PORT="${PORT:-8080}"
  if curl -fs "http://127.0.0.1:${PORT}/api/status" > /dev/null 2>&1; then
    echo -e "${GREEN}Backend antwortet auf Port ${PORT}.${NC}"
  else
    echo -e "${RED}Backend antwortet NICHT auf Port ${PORT}.${NC}"
  fi
}

cmd_logs() {
  if $HAVE_SYSTEMD; then
    sudo journalctl -u ai-desk-robot-backend.service -f -n 100
  else
    tail -f "$SCRIPT_DIR/data/logs/ai_desk_robot.log"
  fi
}

cmd_test() {
  "$SCRIPT_DIR/venv/bin/python" -m unittest discover -s "$SCRIPT_DIR/tests" -v
}

cmd_backup() {
  TS=$(date +%Y%m%d-%H%M%S)
  OUT="$SCRIPT_DIR/data/backups/backup-$TS.tar.gz"
  mkdir -p "$SCRIPT_DIR/data/backups"

  # Nur tatsächlich vorhandene Dateien sichern - vermeidet einen irreführenden
  # 'Backup erstellt'-Erfolg, wenn z.B. .env auf einem frisch entpackten, noch
  # nicht installierten System fehlt.
  BACKUP_ITEMS=()
  for item in data/db config.yaml .env; do
    [ -e "$SCRIPT_DIR/$item" ] && BACKUP_ITEMS+=("$item")
  done

  if [ ${#BACKUP_ITEMS[@]} -eq 0 ]; then
    echo -e "${RED}Kein Backup erstellt: keine der erwarteten Dateien (data/db, config.yaml, .env) gefunden.${NC}"
    return 1
  fi

  if tar -czf "$OUT" -C "$SCRIPT_DIR" "${BACKUP_ITEMS[@]}" 2>/tmp/ai_desk_robot_backup_error.log; then
    echo -e "${GREEN}Backup erstellt: $OUT${NC}"
    echo "(Enthält: ${BACKUP_ITEMS[*]} - Videos NICHT enthalten, siehe README)"
  else
    echo -e "${RED}Backup unvollständig oder fehlgeschlagen - Details: /tmp/ai_desk_robot_backup_error.log${NC}"
    return 1
  fi
}

cmd_update() {
  echo "Aktualisiere Python-Abhängigkeiten..."
  "$SCRIPT_DIR/venv/bin/pip" install --upgrade -r "$SCRIPT_DIR/requirements.txt"
  cmd_restart
}

case "${1:-}" in
  start) cmd_start ;;
  stop) cmd_stop ;;
  restart) cmd_restart ;;
  status) cmd_status ;;
  logs) cmd_logs ;;
  test) cmd_test ;;
  backup) cmd_backup ;;
  update) cmd_update ;;
  *) usage ;;
esac
