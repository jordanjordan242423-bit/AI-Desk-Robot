#!/usr/bin/env bash
# ==============================================================================
# uninstall.sh - entfernt AI Desk Robot sauber vom System (Abschnitt 51)
#
# Löscht NUR:
#   - die systemd-Services (Backend + Kiosk)
#   - die Python-venv innerhalb dieses Projektordners
#
# Löscht NICHT automatisch (Sicherheitsabfrage):
#   - das Projektverzeichnis selbst
#   - die Datenbank / erzeugten Videos / .env
#
# Nichts außerhalb dieses Projektordners wird angefasst.
# ==============================================================================
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo "=============================================================="
echo "  AI DESK ROBOT - Deinstallation"
echo "=============================================================="
echo ""
echo "Dieses Skript wird:"
echo "  1. die systemd-Dienste 'ai-desk-robot-backend' und 'ai-desk-robot-kiosk' stoppen und deaktivieren"
echo "  2. die zugehörigen systemd-Unit-Dateien aus /etc/systemd/system entfernen"
echo "  3. die Python-virtuelle-Umgebung (venv/) in diesem Ordner löschen"
echo ""
echo -e "${YELLOW}NICHT automatisch gelöscht werden: deine Datenbank (data/db), deine"
echo -e "erzeugten Videos (data/videos), deine .env-Datei und dieser Projektordner"
echo -e "selbst. Das entscheidest du am Ende separat.${NC}"
echo ""
read -r -p "Fortfahren? [j/N] " confirm
if [[ ! "$confirm" =~ ^[jJ]$ ]]; then
  echo "Abgebrochen."
  exit 0
fi

if command -v systemctl > /dev/null 2>&1; then
  echo ""
  echo "Stoppe und deaktiviere Dienste..."
  sudo systemctl stop ai-desk-robot-backend.service 2>/dev/null || true
  sudo systemctl stop ai-desk-robot-kiosk.service 2>/dev/null || true
  sudo systemctl disable ai-desk-robot-backend.service 2>/dev/null || true
  sudo systemctl disable ai-desk-robot-kiosk.service 2>/dev/null || true

  echo "Entferne systemd-Unit-Dateien..."
  sudo rm -f /etc/systemd/system/ai-desk-robot-backend.service
  sudo rm -f /etc/systemd/system/ai-desk-robot-kiosk.service
  sudo systemctl daemon-reload
  echo -e "${GREEN}systemd-Dienste entfernt.${NC}"
else
  echo "Kein systemd gefunden - Dienste-Schritt übersprungen."
fi

if [ -d "$SCRIPT_DIR/venv" ]; then
  rm -rf "$SCRIPT_DIR/venv"
  echo -e "${GREEN}Python-venv gelöscht.${NC}"
fi

echo ""
echo "=============================================================="
echo -e "${GREEN}Deinstallation der Dienste abgeschlossen.${NC}"
echo ""
echo "Folgendes liegt noch auf der Festplatte und wurde bewusst NICHT gelöscht:"
echo "  - $SCRIPT_DIR/data/db        (Datenbank)"
echo "  - $SCRIPT_DIR/data/videos    (erzeugte Videos)"
echo "  - $SCRIPT_DIR/.env           (deine Konfiguration/Secrets)"
echo ""
echo "Wenn du wirklich ALLES entfernen möchtest, lösche den kompletten Ordner:"
echo "  rm -rf \"$SCRIPT_DIR\""
echo "=============================================================="
