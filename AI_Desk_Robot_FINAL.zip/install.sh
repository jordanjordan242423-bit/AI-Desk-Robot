#!/usr/bin/env bash
# ==============================================================================
# install.sh - Vollautomatische Installation von AI Desk Robot
#
# Nutzung:
#   chmod +x install.sh
#   ./install.sh
#
# Was dieses Skript macht (Master-Prompt Abschnitt 31):
#    1. System-Pakete prüfen/installieren (Python venv, FFmpeg, espeak-ng, Chromium, ...)
#       -> HARTER ABBRUCH, falls eine Pflichtabhängigkeit (Python3/venv/FFmpeg) fehlt
#          und nicht installiert werden konnte.
#    2. Python-virtuelle-Umgebung erstellen -> harter Abbruch bei Fehlschlag
#    3. Python-Abhängigkeiten installieren -> harter Abbruch, falls Flask/PyYAML/
#       requests/psutil danach nachweislich nicht importierbar sind
#    4. Verzeichnisse anlegen
#    5. .env aus Vorlage erzeugen (falls nicht vorhanden)
#    6. Lokale KI (Ollama) automatisiert einrichten, falls Internet verfügbar
#       -> sonst klarer Hinweis, dass Ollama später manuell nachinstalliert werden muss
#    7. TTS (Piper) automatisiert einrichten + ECHTE Funktionsprüfung (keine stumme
#       Datei als 'Erfolg' akzeptieren) -> sonst bleibt espeak-ng als Fallback aktiv
#    8. Datenbank initialisieren
#    9. systemd-Services einrichten (Backend + Kiosk) mit korrektem User/Pfad
#   10. Autostart aktivieren
#   11. Selbsttests ausführen
#   12. klaren Erfolgs-/Fehlerbericht ausgeben
#
# Dieses Skript ist idempotent: mehrfaches Ausführen richtet nichts doppelt ein.
#
# WICHTIG: Schritte 1-3 sind HARTE Voraussetzungen. Schlägt einer davon fehl,
# bricht die Installation sofort ab (exit 1), BEVOR irgendein systemd-Dienst
# eingerichtet wird - es soll niemals ein kaputter/halb-funktionsfähiger Dienst
# automatisch gestartet und dauerhaft neu gestartet werden.
# ==============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

INSTALL_USER="${SUDO_USER:-$(whoami)}"
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

STEP=0
TOTAL_STEPS=12
FAILED_STEPS=()
WARNINGS=()

step() {
  STEP=$((STEP + 1))
  echo ""
  echo -e "${CYAN}[$STEP/$TOTAL_STEPS] $1${NC}"
}
ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${YELLOW}⚠${NC} $1"; WARNINGS+=("$1"); }
fail() { echo -e "  ${RED}✗${NC} $1"; FAILED_STEPS+=("$1"); }

abort_install() {
  echo ""
  echo -e "${RED}=============================================================="
  echo -e "  INSTALLATION ABGEBROCHEN"
  echo -e "==============================================================${NC}"
  echo -e "  ${RED}Grund: $1${NC}"
  echo ""
  echo "  Es wurde bewusst KEIN systemd-Dienst eingerichtet oder gestartet,"
  echo "  da eine grundlegende Pflichtabhängigkeit fehlt. Bitte das genannte"
  echo "  Problem beheben und ./install.sh erneut ausführen."
  echo "=============================================================="
  exit 1
}

# Prüft, ob eine Internetverbindung besteht (kurzer, nicht-blockierender Check
# mit kurzem Timeout - wichtig, damit die Installation bei fehlendem Internet
# nicht lange hängt, siehe auch app/system.py check_internet()).
has_internet() {
  curl -fsS --max-time 3 https://ollama.com > /dev/null 2>&1 && return 0
  curl -fsS --max-time 3 https://github.com > /dev/null 2>&1 && return 0
  return 1
}

echo "=============================================================="
echo "  AI DESK ROBOT - Installation"
echo "  Benutzer: $INSTALL_USER"
echo "  Zielverzeichnis: $SCRIPT_DIR"
echo "=============================================================="

if [ "$(id -u)" = "0" ] && [ -z "${SUDO_USER:-}" ]; then
  echo -e "${YELLOW}Hinweis: Dieses Skript läuft direkt als root (nicht über 'sudo').${NC}"
  echo -e "${YELLOW}Empfohlen ist, es als normaler Nutzer auszuführen (./install.sh) -"
  echo -e "das Skript nutzt intern selbst 'sudo', wo es benötigt wird.${NC}"
  echo ""
fi

# ------------------------------------------------------------------
# 1. System-Pakete (HARTE Pflichtabhängigkeiten: python3, venv, ffmpeg)
# ------------------------------------------------------------------
step "System-Pakete prüfen (Python, FFmpeg, espeak-ng, Chromium)"
if command -v apt-get > /dev/null 2>&1; then
  NEED_PKGS=()
  command -v python3 > /dev/null 2>&1 || NEED_PKGS+=(python3)
  python3 -c "import venv" > /dev/null 2>&1 || NEED_PKGS+=(python3-venv)
  python3 -c "import pip" > /dev/null 2>&1 || NEED_PKGS+=(python3-pip)
  command -v ffmpeg > /dev/null 2>&1 || NEED_PKGS+=(ffmpeg)
  command -v espeak-ng > /dev/null 2>&1 || NEED_PKGS+=(espeak-ng)
  command -v curl > /dev/null 2>&1 || NEED_PKGS+=(curl)
  command -v unclutter > /dev/null 2>&1 || NEED_PKGS+=(unclutter)
  command -v unzip > /dev/null 2>&1 || NEED_PKGS+=(unzip)

  if [ ${#NEED_PKGS[@]} -gt 0 ]; then
    echo "  Installiere fehlende Pakete: ${NEED_PKGS[*]}"
    if sudo apt-get update -qq && sudo apt-get install -y "${NEED_PKGS[@]}"; then
      ok "System-Pakete installiert"
    else
      warn "Einige System-Pakete konnten nicht automatisch installiert werden (kein Internet? kein sudo?)."
    fi
  else
    ok "Alle benötigten System-Pakete sind bereits vorhanden"
  fi

  # Chromium wird separat behandelt: Raspberry Pi OS nennt das Paket je nach
  # Version 'chromium-browser' ODER 'chromium' - beide Varianten werden erkannt
  # UND beim Installieren der Reihe nach ausprobiert, damit die Installation
  # nicht an einem falschen Paketnamen scheitert.
  if ! command -v chromium-browser > /dev/null 2>&1 && ! command -v chromium > /dev/null 2>&1; then
    echo "  Installiere Chromium (Paketname variiert je nach Raspberry Pi OS Version)..."
    if sudo apt-get install -y chromium-browser > /tmp/chromium_install.log 2>&1; then
      ok "Chromium installiert (Paket: chromium-browser)"
    elif sudo apt-get install -y chromium > /tmp/chromium_install.log 2>&1; then
      ok "Chromium installiert (Paket: chromium)"
    else
      warn "Chromium konnte nicht automatisch installiert werden (siehe /tmp/chromium_install.log). Bitte manuell installieren: 'sudo apt-get install chromium-browser' ODER 'sudo apt-get install chromium'."
    fi
  else
    ok "Chromium ist bereits vorhanden ($(command -v chromium-browser || command -v chromium))"
  fi
else
  warn "apt-get nicht gefunden (kein Debian/Raspberry Pi OS?) - System-Pakete müssen manuell installiert werden: python3-venv ffmpeg espeak-ng chromium"
fi

# Harte Prüfung: ohne Python3+venv+FFmpeg kann die App grundsätzlich nicht laufen.
MISSING_HARD=()
command -v python3 > /dev/null 2>&1 || MISSING_HARD+=("python3")
python3 -c "import venv" > /dev/null 2>&1 || MISSING_HARD+=("python3-venv (Modul 'venv')")
command -v ffmpeg > /dev/null 2>&1 || MISSING_HARD+=("ffmpeg")
command -v ffprobe > /dev/null 2>&1 || MISSING_HARD+=("ffprobe (Teil von ffmpeg)")

if [ ${#MISSING_HARD[@]} -gt 0 ]; then
  abort_install "Folgende Pflichtabhängigkeiten fehlen und konnten nicht automatisch installiert werden: ${MISSING_HARD[*]}. Bitte manuell installieren (z.B. 'sudo apt-get install python3 python3-venv ffmpeg') und die Installation erneut starten."
fi
ok "Pflichtabhängigkeiten (Python3, venv, FFmpeg/ffprobe) sind vorhanden"

# ------------------------------------------------------------------
# 2. Python-Venv (HART: Abbruch bei Fehlschlag)
# ------------------------------------------------------------------
step "Python-virtuelle-Umgebung erstellen"
if [ -d "$SCRIPT_DIR/venv" ] && [ -x "$SCRIPT_DIR/venv/bin/python" ]; then
  ok "venv existiert bereits"
else
  rm -rf "$SCRIPT_DIR/venv"
  if python3 -m venv "$SCRIPT_DIR/venv"; then
    ok "venv erstellt"
  else
    abort_install "Python-virtuelle-Umgebung konnte nicht erstellt werden ('python3 -m venv venv' ist fehlgeschlagen)."
  fi
fi

# ------------------------------------------------------------------
# 3. Python-Abhängigkeiten (HART: Abbruch, wenn Kernpakete danach nicht importierbar sind)
# ------------------------------------------------------------------
step "Python-Abhängigkeiten installieren"
"$SCRIPT_DIR/venv/bin/pip" install --upgrade pip -q || true
if "$SCRIPT_DIR/venv/bin/pip" install -q -r "$SCRIPT_DIR/requirements.txt"; then
  ok "pip install abgeschlossen"
else
  warn "pip install meldete einen Fehler (kein Internet? Paketkonflikt?) - wird unten zwingend geprüft."
fi

if "$SCRIPT_DIR/venv/bin/python" -c "import flask, yaml, requests, psutil" > /dev/null 2>&1; then
  ok "Kern-Abhängigkeiten (Flask, PyYAML, requests, psutil) sind funktionsfähig importierbar"
else
  abort_install "Flask/PyYAML/requests/psutil sind nach der Installation NICHT importierbar. Ohne diese Pakete kann die App nicht laufen (kein Internet beim Installieren? Prüfe 'venv/bin/pip install -r requirements.txt' manuell)."
fi

# ------------------------------------------------------------------
# 4. Verzeichnisse
# ------------------------------------------------------------------
step "Verzeichnisse anlegen"
mkdir -p "$SCRIPT_DIR"/data/{db,videos,audio,logs,backups}
mkdir -p "$SCRIPT_DIR"/static/img
mkdir -p "$SCRIPT_DIR"/vendor
chmod -R u+rwX "$SCRIPT_DIR/data"
ok "data/ Struktur bereit"

# ------------------------------------------------------------------
# 5. .env
# ------------------------------------------------------------------
step ".env-Konfiguration einrichten"
if [ -f "$SCRIPT_DIR/.env" ]; then
  ok ".env existiert bereits - wird nicht überschrieben"
else
  cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"
  RANDOM_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  if [ "$(uname)" = "Darwin" ]; then
    sed -i '' "s/^SECRET_KEY=.*/SECRET_KEY=${RANDOM_KEY}/" "$SCRIPT_DIR/.env"
  else
    sed -i "s/^SECRET_KEY=.*/SECRET_KEY=${RANDOM_KEY}/" "$SCRIPT_DIR/.env"
  fi
  ok ".env aus Vorlage erstellt (mit zufälligem SECRET_KEY)"
fi

# Hilfsfunktion: Wert einer Variable in .env sicher setzen/ersetzen
set_env_var() {
  local key="$1" value="$2"
  if grep -q "^${key}=" "$SCRIPT_DIR/.env"; then
    if [ "$(uname)" = "Darwin" ]; then
      sed -i '' "s#^${key}=.*#${key}=${value}#" "$SCRIPT_DIR/.env"
    else
      sed -i "s#^${key}=.*#${key}=${value}#" "$SCRIPT_DIR/.env"
    fi
  else
    echo "${key}=${value}" >> "$SCRIPT_DIR/.env"
  fi
}
get_env_var() {
  grep "^${1}=" "$SCRIPT_DIR/.env" 2>/dev/null | head -1 | cut -d= -f2-
}

# ------------------------------------------------------------------
# 6. Lokale KI (Ollama) automatisiert einrichten
# ------------------------------------------------------------------
step "Lokale KI (Ollama) einrichten"
if command -v ollama > /dev/null 2>&1; then
  ok "Ollama ist bereits installiert"
  OLLAMA_JUST_INSTALLED=false
elif has_internet; then
  echo "  Internet erkannt - installiere Ollama über das offizielle Installationsskript..."
  if curl -fsSL https://ollama.com/install.sh | sh > /tmp/ollama_install.log 2>&1; then
    ok "Ollama wurde installiert"
    OLLAMA_JUST_INSTALLED=true
  else
    warn "Ollama-Installation ist fehlgeschlagen (siehe /tmp/ollama_install.log). Die App funktioniert trotzdem über den regelbasierten Fallback. Ollama kann später jederzeit manuell nachinstalliert werden (siehe README)."
    OLLAMA_JUST_INSTALLED=false
  fi
else
  warn "Kein Internet erkannt - Ollama wurde NICHT installiert. Die App funktioniert vollständig über den eingebauten regelbasierten Fallback. Bitte Ollama SPÄTER manuell nachinstallieren, sobald Internet verfügbar ist: curl -fsSL https://ollama.com/install.sh | sh && ollama pull llama3.2:3b (siehe README, Abschnitt 'Lokale KI einrichten')."
  OLLAMA_JUST_INSTALLED=false
fi

if command -v ollama > /dev/null 2>&1; then
  # sicherstellen, dass der Ollama-Dienst läuft, bevor wir 'ollama pull' aufrufen
  if command -v systemctl > /dev/null 2>&1; then
    sudo systemctl enable ollama > /dev/null 2>&1 || true
    sudo systemctl start ollama > /dev/null 2>&1 || true
    sleep 2
  fi

  OLLAMA_MODEL_NAME="$(get_env_var OLLAMA_MODEL)"
  OLLAMA_MODEL_NAME="${OLLAMA_MODEL_NAME:-llama3.2:3b}"

  if ollama list 2>/dev/null | grep -q "$(echo "$OLLAMA_MODEL_NAME" | cut -d: -f1)"; then
    ok "Ollama-Modell '$OLLAMA_MODEL_NAME' ist bereits vorhanden"
  elif has_internet; then
    echo "  Lade Modell '$OLLAMA_MODEL_NAME' herunter (das kann auf dem Raspberry Pi einige Minuten dauern)..."
    if ollama pull "$OLLAMA_MODEL_NAME" > /tmp/ollama_pull.log 2>&1; then
      ok "Modell '$OLLAMA_MODEL_NAME' erfolgreich heruntergeladen"
    else
      warn "Modell '$OLLAMA_MODEL_NAME' konnte nicht heruntergeladen werden (siehe /tmp/ollama_pull.log). Die App nutzt bis dahin den regelbasierten Fallback. Später manuell nachholen: ollama pull $OLLAMA_MODEL_NAME"
    fi
  else
    warn "Kein Internet - Modell '$OLLAMA_MODEL_NAME' konnte nicht heruntergeladen werden. Bitte später nachholen: ollama pull $OLLAMA_MODEL_NAME"
  fi
fi

# ------------------------------------------------------------------
# 7. TTS (Piper) automatisiert einrichten + ECHTE Funktionsprüfung
# ------------------------------------------------------------------
step "TTS (Piper) einrichten"
PIPER_SETUP_OK=false
EXISTING_PIPER_VOICE="$(get_env_var PIPER_VOICE_PATH)"

if [ -n "$EXISTING_PIPER_VOICE" ] && [ -f "$EXISTING_PIPER_VOICE" ]; then
  ok "Piper-Stimmmodell bereits konfiguriert ($EXISTING_PIPER_VOICE)"
  PIPER_SETUP_OK=true
elif has_internet; then
  ARCH="$(uname -m)"
  case "$ARCH" in
    aarch64|arm64) PIPER_ARCH="linux_aarch64" ;;
    armv7l) PIPER_ARCH="linux_armv7" ;;
    x86_64) PIPER_ARCH="linux_x86_64" ;;
    *) PIPER_ARCH="" ;;
  esac

  if [ -z "$PIPER_ARCH" ]; then
    warn "Unbekannte CPU-Architektur ($ARCH) - Piper kann nicht automatisch installiert werden. espeak-ng bleibt als TTS-Fallback aktiv."
  else
    echo "  Lade Piper für $PIPER_ARCH herunter..."
    PIPER_TARBALL_URL="https://github.com/rhasspy/piper/releases/latest/download/piper_${PIPER_ARCH}.tar.gz"
    mkdir -p "$SCRIPT_DIR/vendor/piper"
    if curl -fsSL "$PIPER_TARBALL_URL" -o /tmp/piper.tar.gz 2>/tmp/piper_download.log && \
       tar -xzf /tmp/piper.tar.gz -C "$SCRIPT_DIR/vendor/piper" --strip-components=1 2>>/tmp/piper_download.log; then
      ok "Piper-Binary heruntergeladen und entpackt"

      VOICE_BASE_URL="https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/thorsten/medium"
      mkdir -p "$SCRIPT_DIR/vendor/piper-voices"
      if curl -fsSL "${VOICE_BASE_URL}/de_DE-thorsten-medium.onnx" -o "$SCRIPT_DIR/vendor/piper-voices/de_DE-thorsten-medium.onnx" 2>>/tmp/piper_download.log && \
         curl -fsSL "${VOICE_BASE_URL}/de_DE-thorsten-medium.onnx.json" -o "$SCRIPT_DIR/vendor/piper-voices/de_DE-thorsten-medium.onnx.json" 2>>/tmp/piper_download.log && \
         [ -s "$SCRIPT_DIR/vendor/piper-voices/de_DE-thorsten-medium.onnx" ]; then
        ok "Deutsches Stimmmodell (de_DE-thorsten-medium) heruntergeladen"

        PIPER_BIN_PATH="$SCRIPT_DIR/vendor/piper/piper"
        if [ -x "$PIPER_BIN_PATH" ]; then
          set_env_var "PIPER_BIN" "$PIPER_BIN_PATH"
          set_env_var "PIPER_VOICE_PATH" "$SCRIPT_DIR/vendor/piper-voices/de_DE-thorsten-medium.onnx"
          PIPER_SETUP_OK=true
        else
          warn "Piper-Binary nach dem Entpacken nicht ausführbar gefunden - espeak-ng bleibt als Fallback aktiv."
        fi
      else
        warn "Deutsches Piper-Stimmmodell konnte nicht heruntergeladen werden (siehe /tmp/piper_download.log). espeak-ng bleibt als Fallback aktiv."
      fi
    else
      warn "Piper-Binary konnte nicht heruntergeladen werden (siehe /tmp/piper_download.log, evtl. hat sich der Release-Name geändert). espeak-ng bleibt als zuverlässiger Fallback aktiv - siehe README für manuelle Installation."
    fi
  fi
else
  warn "Kein Internet erkannt - Piper wurde NICHT automatisch installiert. espeak-ng bleibt als zuverlässiger TTS-Fallback aktiv. Piper kann später jederzeit manuell nachgerüstet werden (siehe README, Abschnitt 'TTS einrichten')."
fi

# ECHTE Funktionsprüfung: niemals eine stumme/kaputte Piper-Installation als
# 'funktioniert' durchwinken - genau wie zur Laufzeit in app/providers/tts_provider.py.
if $PIPER_SETUP_OK; then
  echo "  Prüfe, ob Piper wirklich hörbare Sprachausgabe erzeugt..."
  PIPER_TEST_RESULT="$("$SCRIPT_DIR/venv/bin/python" -c "
import sys; sys.path.insert(0, '$SCRIPT_DIR')
from pathlib import Path
import tempfile
from app.providers import tts_provider
with tempfile.TemporaryDirectory() as tmp:
    out = Path(tmp) / 'test.wav'
    path, engine = tts_provider.synthesize('Dies ist ein Testsatz für die Sprachausgabe.', out, estimated_duration_s=5.0)
    print(engine)
" 2>/tmp/piper_functional_test.log)"

  if [ "$PIPER_TEST_RESULT" = "piper" ]; then
    ok "Piper wurde getestet und erzeugt echte, hörbare Sprachausgabe"
  else
    warn "Piper wurde installiert, aber der Funktionstest ergab Engine='$PIPER_TEST_RESULT' statt 'piper' (vermutlich stumme/fehlerhafte Ausgabe, siehe /tmp/piper_functional_test.log). Piper wird NICHT als aktiv markiert - espeak-ng bleibt der genutzte Fallback, bis das Problem behoben ist."
    set_env_var "PIPER_VOICE_PATH" ""
  fi
fi

if ! $PIPER_SETUP_OK || [ "${PIPER_TEST_RESULT:-}" != "piper" ]; then
  ok "espeak-ng ist als zuverlässiger TTS-Fallback aktiv (deutsche Stimme, funktioniert offline)"
fi

# ------------------------------------------------------------------
# 8. Datenbank initialisieren
# ------------------------------------------------------------------
step "Datenbank initialisieren"
if "$SCRIPT_DIR/venv/bin/python" -c "
import sys; sys.path.insert(0, '$SCRIPT_DIR')
from app import database
database.init_db()
print('OK')
" | grep -q OK; then
  ok "SQLite-Datenbank bereit ($SCRIPT_DIR/data/db/ai_desk_robot.sqlite3)"
else
  fail "Datenbank-Initialisierung fehlgeschlagen"
fi

# ------------------------------------------------------------------
# 9. systemd-Services einrichten
# ------------------------------------------------------------------
step "systemd-Services einrichten"
if command -v systemctl > /dev/null 2>&1; then
  SYSTEMD_DIR="/etc/systemd/system"
  for svc_template in "$SCRIPT_DIR"/systemd/*.service; do
    svc_name="$(basename "$svc_template")"
    tmp_file="$(mktemp)"
    sed -e "s#%INSTALL_DIR%#$SCRIPT_DIR#g" -e "s#%USER%#$INSTALL_USER#g" "$svc_template" > "$tmp_file"
    if sudo cp "$tmp_file" "$SYSTEMD_DIR/$svc_name"; then
      ok "$svc_name installiert"
    else
      fail "$svc_name konnte nicht nach $SYSTEMD_DIR kopiert werden (sudo-Rechte?)"
    fi
    rm -f "$tmp_file"
  done

  if sudo systemctl daemon-reload; then
    ok "systemd neu geladen"
  else
    fail "systemctl daemon-reload fehlgeschlagen"
  fi
else
  warn "systemd (systemctl) nicht gefunden - Autostart muss manuell eingerichtet werden (kein Raspberry Pi OS?)"
fi

# ------------------------------------------------------------------
# 10. Autostart aktivieren
# ------------------------------------------------------------------
step "Autostart aktivieren"
if command -v systemctl > /dev/null 2>&1; then
  if sudo systemctl enable ai-desk-robot-backend.service > /dev/null 2>&1; then
    ok "Backend-Autostart aktiviert"
  else
    fail "Backend-Autostart konnte nicht aktiviert werden"
  fi
  if sudo systemctl enable ai-desk-robot-kiosk.service > /dev/null 2>&1; then
    ok "Kiosk-Autostart aktiviert"
  else
    warn "Kiosk-Autostart konnte nicht aktiviert werden (kein grafischer Desktop? Prüfe 'raspi-config' -> Boot Options -> Desktop Autologin)"
  fi

  echo "  Starte Backend-Dienst jetzt..."
  if sudo systemctl restart ai-desk-robot-backend.service; then
    ok "Backend-Dienst gestartet"
  else
    fail "Backend-Dienst konnte nicht gestartet werden - siehe: journalctl -u ai-desk-robot-backend -n 50"
  fi
else
  warn "Kein systemd verfügbar - starte die App manuell mit: ./manage.sh start"
fi

# ------------------------------------------------------------------
# 11. Selbsttests
# ------------------------------------------------------------------
step "Selbsttests ausführen"
if "$SCRIPT_DIR/venv/bin/python" -m unittest discover -s "$SCRIPT_DIR/tests" -v 2>/tmp/ai_desk_robot_test_output.log; then
  ok "Alle automatisierten Tests erfolgreich"
else
  warn "Einige Tests sind fehlgeschlagen - Details in /tmp/ai_desk_robot_test_output.log. Die App funktioniert trotzdem in den meisten Fällen (viele Tests prüfen optionale externe Dienste wie Ollama/Piper/Internet)."
fi

# ------------------------------------------------------------------
# 12. Abschlussbericht
# ------------------------------------------------------------------
# Sicherheitsnetz: Wurde install.sh versehentlich direkt mit 'sudo ./install.sh'
# aufgerufen (statt normal als Nutzer, der intern bei Bedarf selbst sudo nutzt),
# wären venv/ und data/ als root angelegt worden - der systemd-Dienst läuft aber
# als normaler Nutzer (INSTALL_USER) und könnte dann nicht mehr in die Datenbank
# oder nach data/videos schreiben ('Permission denied'). Dieser Schritt korrigiert
# die Besitzrechte des gesamten Projektordners nachträglich, falls das Skript
# tatsächlich mit UID 0 lief.
if [ "$(id -u)" = "0" ] && [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
  echo ""
  echo "  Skript lief mit Root-Rechten (sudo ./install.sh) - korrigiere Besitzrechte auf '$INSTALL_USER'..."
  if chown -R "$INSTALL_USER:$INSTALL_USER" "$SCRIPT_DIR"; then
    ok "Besitzrechte des Projektordners auf '$INSTALL_USER' gesetzt"
  else
    warn "Besitzrechte konnten nicht automatisch korrigiert werden - bitte manuell prüfen: chown -R $INSTALL_USER:$INSTALL_USER '$SCRIPT_DIR'"
  fi
fi

echo ""
echo "=============================================================="
if [ ${#FAILED_STEPS[@]} -eq 0 ]; then
  echo -e "  ${GREEN}INSTALLATION ERFOLGREICH ABGESCHLOSSEN${NC}"
else
  echo -e "  ${YELLOW}INSTALLATION MIT WARNUNGEN/FEHLERN ABGESCHLOSSEN${NC}"
  echo ""
  echo "  Fehlgeschlagene Schritte:"
  for f in "${FAILED_STEPS[@]}"; do echo "    - $f"; done
fi
if [ ${#WARNINGS[@]} -gt 0 ]; then
  echo ""
  echo "  Hinweise/Warnungen:"
  for w in "${WARNINGS[@]}"; do echo "    - $w"; done
fi
echo ""
echo "  Dashboard:        http://$(hostname -I 2>/dev/null | awk '{print $1}' || echo 'RASPBERRY-PI-IP'):8080"
echo "  Manueller Upload:  http://$(hostname -I 2>/dev/null | awk '{print $1}' || echo 'RASPBERRY-PI-IP'):8765/upload"
echo ""
echo "  Nützliche Befehle:"
echo "    ./manage.sh status   - Status prüfen"
echo "    ./manage.sh logs     - Live-Logs ansehen"
echo "    ./manage.sh restart  - Neu starten"
echo ""
echo "  Details zu lokaler KI (Ollama) und TTS (Piper) siehe README.md."
echo "=============================================================="
