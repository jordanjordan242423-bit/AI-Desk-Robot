# AI Desk Robot

Ein vollautonomer KI-Content-Agent für Raspberry Pi 5 + 7"-HDMI-Touchdisplay.
Der Agent recherchiert selbstständig Themen, schreibt ein Skript, erzeugt eine
deutsche Sprachausgabe, baut ein fertiges TikTok-Video (1080×1920, H.264/AAC,
Untertitel), prüft es automatisch und lädt es hoch (offizielle TikTok API) oder
stellt es zum manuellen Upload bereit. Auf dem Display läuft dauerhaft ein
animiertes KI-Robotergesicht als Status-Dashboard.

---

## Inhalt

1. [Schnellstart](#schnellstart)
2. [Was du bekommst](#was-du-bekommst)
3. [Voraussetzungen](#voraussetzungen)
4. [Installation](#installation)
5. [Konfiguration](#konfiguration-env--configyaml)
6. [Lokale KI einrichten (Ollama)](#lokale-ki-einrichten-ollama)
7. [TTS einrichten (Piper)](#tts-einrichten-piper)
8. [TikTok einrichten (offizielle API)](#tiktok-einrichten-offizielle-api)
9. [Bedienung](#bedienung)
10. [manage.sh Befehle](#managesh-befehle)
11. [Troubleshooting](#troubleshooting)
12. [Backup & Wiederherstellung](#backup--wiederherstellung)
13. [Deinstallation](#deinstallation)
14. [Bekannte Grenzen dieser Entwicklungsumgebung](#bekannte-grenzen-dieser-entwicklungsumgebung)
15. [Projektstruktur](#projektstruktur)

---

## Schnellstart

```bash
# 1. ZIP auf den Raspberry Pi kopieren und entpacken
unzip AI_Desk_Robot_FINAL.zip
cd ai_desk_robot

# 2. Installation starten
chmod +x install.sh
./install.sh

# 3. Fertig - Dashboard ist erreichbar unter:
#    http://<RASPBERRY-PI-IP>:8080
```

Nach einem Neustart des Raspberry Pi startet die App automatisch (systemd) und
Chromium zeigt das Dashboard im Kiosk-Vollbildmodus.

---

## Was du bekommst

- **Vollautomatische Video-Pipeline**: Recherche → Themenauswahl → Faktenprüfung
  → Skript → Sprachausgabe → Video-Rendering → Untertitel → Qualitätsprüfung →
  Upload/Bereitstellung. Keine manuelle Themeneingabe nötig.
- **Lokal-first**: läuft grundsätzlich ohne bezahlte Cloud-APIs. Lokales LLM
  (Ollama), lokales TTS (Piper/espeak-ng), kostenlose RSS-Quellen und
  Wikipedia für Fakten, kostenloser Wetterdienst (Open-Meteo).
  Jede externe Komponente hat einen funktionierenden Fallback.
- **Animiertes Robotergesicht**: große, glühende KI-Augen mit Blinzeln,
  Blickbewegungen, "Atmen" und zustandsabhängigem Mund (Recherche, Denken,
  Sprechen, Rendern, Erfolg, Fehler, ...). Reines SVG/CSS/JS, keine
  externe Bibliothek, läuft offline.
- **Responsives Dashboard**: passt sich automatisch an die tatsächliche
  Display-Auflösung an (clamp/vw/vh/grid), keine Scrollbars, große
  Touch-Ziele, für 7"-Touchscreens optimiert.
- **TikTok nur offiziell**: Upload ausschließlich über die offizielle
  TikTok Content Posting API (OAuth2). Kein Cookie-Hack, kein
  Login-Bot. Ohne Einrichtung bleibt das Video für den manuellen
  Upload bereit (inkl. QR-Code fürs Handy).
- **Robuste Fehlerbehandlung**: jeder externe Schritt hat Retry/Fallback,
  Watchdog gegen hängende Jobs, automatischer Neustart via systemd.

---

## Voraussetzungen

- Raspberry Pi 5 (empfohlen: 8 GB RAM), Raspberry Pi OS (Debian-basiert) mit
  Desktop-Umgebung (für den Kiosk-Modus)
- 7"-HDMI-Touchdisplay (oder jeder andere HDMI-Bildschirm - die Oberfläche
  ist responsiv)
- Internetverbindung (für Recherche, Fakten, Wetter, optionalen TikTok-Upload).
  Läuft auch zeitweise offline weiter - siehe Fallback-Mechanismen.
- Für Videoerstellung: FFmpeg (wird von `install.sh` automatisch installiert)

**Nicht erforderlich:** Lautsprecher, Mikrofon, bezahlte API-Keys, GPIO-Taster
(optional unterstützt, aber nicht notwendig).

---

## Installation

```bash
chmod +x install.sh
./install.sh
```

Das Skript führt automatisch aus:

1. Prüft/installiert System-Pakete (`python3-venv`, `ffmpeg`, `espeak-ng`,
   `chromium-browser`, `curl`, `unclutter`) - **bricht sauber ab (exit 1)**,
   falls eine Pflichtabhängigkeit (Python3, `venv`, FFmpeg/ffprobe) fehlt und
   nicht installiert werden konnte, BEVOR irgendein Dienst eingerichtet wird
2. Erstellt eine Python-virtuelle-Umgebung (`venv/`) - bricht ab bei Fehlschlag
3. Installiert alle Python-Abhängigkeiten (`requirements.txt`) - bricht ab,
   falls Flask/PyYAML/requests/psutil danach nachweislich nicht importierbar sind
4. Legt die Datenverzeichnisse an (`data/db`, `data/videos`, `data/audio`,
   `data/logs`, `data/backups`)
5. Erstellt `.env` aus `.env.example` (mit zufällig erzeugtem `SECRET_KEY`)
6. **Richtet die lokale KI (Ollama) automatisiert ein**, wenn Internet
   verfügbar ist (Installation + Download von `llama3.2:3b`) - sonst klarer
   Hinweis zum späteren manuellen Nachinstallieren
7. **Richtet TTS (Piper) automatisiert ein**, wenn Internet verfügbar ist,
   inklusive echtem Funktionstest (keine stumme Ausgabe wird als Erfolg
   akzeptiert) - sonst bleibt `espeak-ng` als geprüfter Fallback aktiv
8. Initialisiert die SQLite-Datenbank
9. Richtet die systemd-Dienste ein (`ai-desk-robot-backend`,
   `ai-desk-robot-kiosk`) und aktiviert den Autostart
10. Startet den Backend-Dienst
11. Führt die automatisierten Tests aus
12. Gibt einen klaren Erfolgs-/Fehlerbericht aus (inkl. Dashboard-URL)

`install.sh` ist **idempotent** - mehrfaches Ausführen richtet nichts doppelt
ein und überschreibt keine bestehende `.env`.

Falls dein System **kein** systemd hat oder du keinen Desktop/Kiosk verwenden
willst, läuft das Backend trotzdem - starte es manuell mit `./manage.sh start`.

---

## Konfiguration (.env + config.yaml)

Es gibt zwei Konfigurationsebenen:

- **`.env`** - Secrets & Host-Einstellungen (Ports, API-Keys, TikTok-Zugangsdaten).
  Wird nie in Logs oder Git eingecheckt. Vorlage: `.env.example`.
- **`config.yaml`** - Verhaltenseinstellungen (Videos pro Tag, Sprache,
  Themenkategorien, Wetter-Standort, ...). Kann auch bequem über die
  Einstellungen-Ansicht im Dashboard geändert werden (Touch-freundlich).

Wichtige `.env`-Felder (alle optional, siehe `.env.example` für die volle Liste):

| Variable | Zweck | Pflicht? |
|---|---|---|
| `FLASK_PORT` | Port des Haupt-Dashboards (Standard 8080) | nein |
| `UPLOAD_PORT` | Port des manuellen Upload-Servers (Standard 8765) | nein |
| `OLLAMA_HOST` / `OLLAMA_MODEL` | lokales LLM | nein (Fallback aktiv) |
| `PIPER_BIN` / `PIPER_VOICE_PATH` | lokales TTS | nein (Fallback: espeak-ng) |
| `PEXELS_API_KEY` / `PIXABAY_API_KEY` | Stock-Videos für Hintergründe | nein (Fallback: lokal generiert) |
| `TIKTOK_CLIENT_KEY/SECRET/REDIRECT_URI` | offizieller TikTok-Upload | nein (Fallback: manueller Upload) |
| `GPIO_BUTTON_PIN` | physischer Taster zum Ansicht-Wechsel | nein |

---

## Lokale KI einrichten (Ollama)

**`install.sh` versucht dies automatisch**, wenn beim Installieren eine
Internetverbindung besteht: Es installiert Ollama über das offizielle
Installationsskript und lädt anschließend `llama3.2:3b` herunter (ein für
den Raspberry Pi 5 mit 8 GB RAM realistischer Kompromiss aus Qualität und
Geschwindigkeit). War beim Installieren kein Internet verfügbar, überspringt
`install.sh` diesen Schritt automatisch und zeigt am Ende einen klaren
Hinweis, dass Ollama später manuell nachinstalliert werden sollte. Ganz ohne
Ollama funktioniert die App trotzdem (regelbasierter Fallback baut Skripte
direkt aus den geprüften Fakten).

Manuelles Nachinstallieren, falls nötig:
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.2:3b
```

In `.env`:
```
OLLAMA_HOST=http://127.0.0.1:11434
OLLAMA_MODEL=llama3.2:3b
```

Der aktuelle Ollama-Status ist jederzeit im Dashboard unter "System" sichtbar.

---

## TTS einrichten (Piper)

**`install.sh` versucht auch dies automatisch**, wenn Internet verfügbar ist:
Es lädt die passende Piper-Binary für die erkannte CPU-Architektur sowie das
deutsche Stimmmodell `de_DE-thorsten-medium` herunter, trägt die Pfade in
`.env` ein - und führt danach einen **echten Funktionstest** durch (erzeugt
testweise eine Audiodatei und prüft, ob sie tatsächlich hörbaren Inhalt hat,
nicht nur eine leere/stumme Datei). Nur wenn dieser Test wirklich erfolgreich
ist, wird Piper aktiv genutzt. Schlägt der Download oder der Funktionstest
fehl (oder ist kein Internet verfügbar), bleibt automatisch `espeak-ng` als
zuverlässiger Fallback aktiv - klar im Installationsbericht vermerkt.

**Wichtige Sicherheitsgarantie:** Weder Piper noch espeak-ng werden jemals
als "erfolgreich" akzeptiert, wenn die erzeugte Audiodatei technisch zwar
gültig, aber praktisch stumm ist (z.B. durch ein fehlerhaftes Stimmmodell).
Das System prüft die tatsächliche Lautstärke (RMS-Amplitude) jeder erzeugten
Datei und fällt bei einer verdächtig stillen Ausgabe ehrlich auf die nächste
Engine bzw. am Ende sichtbar auf den Notfall-Pfad zurück - eine stille
Aufnahme wird niemals stillschweigend als normale, erfolgreiche
Sprachausgabe durchgewunken.

Manuelles Einrichten, falls die automatische Installation nicht greift:
```
PIPER_BIN=/pfad/zu/piper
PIPER_VOICE_PATH=/pfad/zu/de_DE-thorsten-medium.onnx
```

Reihenfolge der TTS-Fallback-Kette: **Piper → espeak-ng → Notfall-Stille**
(Notfall-Stille wird klar geloggt und sollte im Normalbetrieb nie auftreten -
falls doch, prüfe `./manage.sh logs`).

---

## TikTok einrichten (offizielle API)

Die Integration nutzt **ausschließlich** die offizielle TikTok Content
Posting API (OAuth2) - keine Cookie-Hacks, kein Login-Bot, keine
Captcha-Umgehung.

1. Auf [developers.tiktok.com](https://developers.tiktok.com) eine App
   registrieren und die Content Posting API aktivieren.
2. Client Key, Client Secret und Redirect-URI in `.env` eintragen:
   ```
   TIKTOK_CLIENT_KEY=...
   TIKTOK_CLIENT_SECRET=...
   TIKTOK_REDIRECT_URI=http://<RASPBERRY-PI-IP>:8080/tiktok/callback
   ```
3. Backend neu starten: `./manage.sh restart`
4. Im Dashboard unter "TikTok" auf "Mit TikTok verbinden" tippen und den
   offiziellen Autorisierungsbildschirm bestätigen.

Ohne diese Einrichtung zeigt die App **ehrlich** "nicht verbunden" an -
niemals einen vorgetäuschten Verbindungsstatus. Videos werden trotzdem
produziert und stehen im manuellen Upload-Bereich bereit (siehe QR-Code
im Dashboard unter "TikTok").

**Sicherheits-Hinweis:** Der Upload setzt standardmäßig `privacy_level:
SELF_ONLY` (nur für dich sichtbar), damit du neue Videos erst prüfen
kannst, bevor sie öffentlich werden. Passe das nach eigenem Ermessen in
`app/tiktok.py` an, sobald du der Pipeline vertraust.

**Vor jedem Upload wird zusätzlich die offizielle "Creator Info" abgefragt**
(Pflichtschritt der Content Posting API): daraus werden die für deinen
Account tatsächlich erlaubten Privacy-Level- und Interaktions-Einstellungen
übernommen, statt fest einprogrammierter Werte. Nach dem Hochladen wird der
echte Veröffentlichungsstatus abgefragt (nicht nur der HTTP-Status der
Upload-Anfrage) - erst ein bestätigter Erfolg zählt als "veröffentlicht".

### Manueller Upload-Fallback (Video geht nie verloren)

Wenn der automatische TikTok-Upload nicht eingerichtet ist, fehlschlägt oder
keine Berechtigung besteht, bleibt das fertige Video **immer** erhalten und
der Job wird **nicht** als komplett fehlgeschlagen markiert (Status bleibt
`READY`). Im Dashboard erscheint dann:

- ein gut sichtbarer Button **"📤 Manuell auf TikTok hochladen"** (in der
  TikTok- und der Videos-Ansicht) sowie ein oranger Punkt am TikTok-Symbol
  der Touch-Navigation, solange mindestens ein Video darauf wartet,
- ein Klick öffnet eine dedizierte Seite (`/tiktok/manual/<job-id>`) mit
  Videovorschau, Titel/Beschreibung/Hashtags, einem Download-Button und
  einem Hinweis auf den letzten Fehlerbund (falls vorhanden),
- ein job-spezifischer QR-Code auf dieser Seite führt direkt zu einer
  mobilen Einzelvideo-Seite (`http://<pi-ip>:8765/upload/<job-id>`), von wo
  aus das Video aufs Handy geladen und in der TikTok-App gepostet werden kann.

---

## Bedienung

Das Dashboard hat sieben Ansichten, erreichbar über die Touch-Navigation
am rechten Bildschirmrand:

- **Hauptansicht** - Robotergesicht, Systemstatus, aktueller Prozess, Thema
- **TikTok** - Verbindungsstatus, manueller Upload-Bereich mit QR-Code
- **Statistik** - Videos gesamt/heute, Erfolge, Fehler
- **Videos** - Archiv aller erstellten Videos mit Status
- **Logs** - laufende, verständliche Prozess-Logs
- **Einstellungen** - Videos/Tag, Mindestabstand, sofortiger Testlauf
- **System** - CPU, RAM, Speicher, Temperatur, Uptime, Dienststatus

Der Agent arbeitet vollständig selbstständig im Hintergrund. Die
Einstellungen-Ansicht bietet zusätzlich einen "Jetzt Video erstellen"-Button
für einen sofortigen Testlauf außerhalb des normalen Zeitplans.

---

## manage.sh Befehle

```bash
./manage.sh start     # Dienste starten
./manage.sh stop      # Dienste stoppen
./manage.sh restart   # Dienste neu starten
./manage.sh status    # Status von Backend + Kiosk anzeigen
./manage.sh logs      # Live-Logs verfolgen
./manage.sh test      # automatisierte Tests ausführen
./manage.sh backup    # Datenbank + Konfiguration sichern
./manage.sh update    # Python-Abhängigkeiten aktualisieren + neu starten
```

---

## Troubleshooting

**Dashboard zeigt nichts an / Chromium startet nicht**
→ `./manage.sh status` prüfen. Läuft der Backend-Dienst, aber kein Kiosk?
Prüfe, ob der Raspberry Pi mit automatischem Desktop-Login konfiguriert ist
(`sudo raspi-config` → *System Options* → *Boot / Auto Login* → *Desktop
Autologin*). Ohne automatischen grafischen Login kann der Kiosk-Dienst
keine Anzeige öffnen.

**"Wetter nicht konfiguriert"**
→ Kein Internet erreichbar, oder Open-Meteo antwortet nicht. Kein Grund zur
Sorge - der Rest der App funktioniert unabhängig vom Wetter weiter.

**Ollama-Status zeigt "Fallback aktiv"**
→ Ollama ist entweder nicht installiert oder nicht gestartet. Die App
funktioniert trotzdem (regelbasierter Fallback), Texte sind dann aber
einfacher. Siehe [Lokale KI einrichten](#lokale-ki-einrichten-ollama).

**TTS-Status zeigt "espeak-ng Fallback"**
→ Piper ist nicht eingerichtet. Funktioniert trotzdem, klingt aber
robotischer. Siehe [TTS einrichten](#tts-einrichten-piper).

**Ein Job hängt / "läuft" ewig**
→ Der eingebaute Watchdog markiert Jobs, die länger als 25 Minuten in einem
Schritt hängen, automatisch als `FAILED`. Der Scheduler startet danach von
selbst einen neuen Versuch. Details: `./manage.sh logs`.

**Video wird als FEHLGESCHLAGEN markiert**
→ Die Qualitätsprüfung (ffprobe) hat ein Problem gefunden (z.B. zu kurz,
falsche Auflösung, fehlende Audiospur). Grund steht im Fehlerfeld des Jobs
(Ansicht "Videos" bzw. `/api/jobs/<id>`) und in den Logs.

**Ich möchte den Fehlerbericht der Installation erneut sehen**
→ `/tmp/ai_desk_robot_test_output.log` (Testergebnisse) bzw.
`sudo journalctl -u ai-desk-robot-backend -n 100` (Laufzeit-Logs).

---

## Backup & Wiederherstellung

```bash
./manage.sh backup
```

Erstellt `data/backups/backup-<Zeitstempel>.tar.gz` mit Datenbank,
`config.yaml` und `.env`. Videos sind absichtlich **nicht** enthalten
(Größe) - bei Bedarf `data/videos/` separat sichern.

Wiederherstellen:
```bash
tar -xzf data/backups/backup-<Zeitstempel>.tar.gz -C /pfad/zum/projekt
./manage.sh restart
```

---

## Deinstallation

```bash
chmod +x uninstall.sh
./uninstall.sh
```

Entfernt die systemd-Dienste und die Python-venv. Datenbank, Videos und
`.env` bleiben **bewusst** erhalten (siehe Skript-Ausgabe für den Befehl,
falls du wirklich alles löschen möchtest).

---

## Bekannte Grenzen dieser Entwicklungsumgebung

Dieses Projekt wurde in einer Sandbox ohne Raspberry-Pi-Hardware und ohne
durchgehenden Internetzugang entwickelt und getestet. Ehrlich dokumentiert:

- **Kein echter Raspberry Pi / HDMI-Touchscreen / GPIO-Taster** stand zur
  Verfügung. Die Oberfläche wurde mit responsiven CSS-Techniken
  (`clamp()`, `vw`/`vh`, `grid`) gebaut und in mehreren Auflösungen
  geprüft, eine finale Sichtprüfung auf echter 7"-Hardware ersetzt das nicht.
- **Kein Ollama und kein Piper** konnten in der Entwicklungsumgebung installiert
  werden (kein Internetzugriff für den Download). Beide Integrationen sind
  vollständig implementiert und werden bei jedem Aufruf korrekt erkannt/genutzt,
  sobald sie auf dem Pi verfügbar sind - der Fallback-Pfad (regelbasiertes
  Skript bzw. espeak-ng) wurde hingegen **echt end-to-end getestet**.
- **Kein TikTok-Account/keine Developer-App** stand zum Testen zur Verfügung.
  Der OAuth2-Client folgt exakt der offiziell dokumentierten Content Posting
  API (Autorisierung, Token-Tausch, Refresh, Creator-Info-Abfrage,
  `FILE_UPLOAD`-Init, PUT-Upload, Status-Abfrage). Ohne echten Account konnte
  kein realer Roundtrip durchgeführt werden - insbesondere die exakten
  Feldnamen/Werte der Creator-Info- und Status-Antwort (z.B. ob ein Status
  wörtlich "PUBLISH_COMPLETE" heißt) konnten nicht gegen die echte API
  verifiziert werden. Die Auswertung ist deshalb bewusst defensiv (Teilstring-
  Erkennung von "COMPLETE"/"SUCCESS" bzw. "FAIL") gehalten. Bitte nach dem
  Verbinden ein erstes Testvideo genau prüfen (Standardeinstellung ist bewusst
  `SELF_ONLY`, also nur für dich sichtbar) und bei Bedarf die Status-Strings
  in `app/tiktok.py` (`_STATUS_SUCCESS_MARKERS`/`_STATUS_FAILURE_MARKERS`)
  an die tatsächliche API-Antwort anpassen.
- **QR-Code-Generator ist eine selbst geschriebene, abhängigkeitsfreie
  Implementierung** (da `pip install qrcode` in der Entwicklungsumgebung ohne
  Internet nicht möglich war). Die Modulmatrix wurde strukturell verifiziert
  (Finder-/Timing-/Alignment-Muster, BCH-Formatinfo), konnte aber mangels
  Internet **nicht gegen einen echten QR-Scanner getestet werden**. Als
  Sicherheitsnetz wird die Ziel-URL im Dashboard zusätzlich immer als Text
  angezeigt.
- **Das Video-/Untertitel-Rendering wurde hingegen vollständig echt getestet**:
  mit echtem FFmpeg wurden mehrere komplette Testvideos erzeugt (1080×1920,
  H.264/AAC), mit `ffprobe` unabhängig verifiziert, und einzelne Frames
  wurden visuell geprüft. Dabei wurden zwei echte Bugs gefunden und behoben
  (siehe Commit-/Entwicklungshistorie): ein Deadlock in der Datenbankschicht
  bei verschachtelten Cursor-Aufrufen, und eine fehlerhafte
  Untertitel-Positionierung/-Skalierung durch libass' implizite
  Referenzauflösung - behoben durch eine selbst geschriebene `.ass`-Datei
  mit explizitem `PlayResX`/`PlayResY`.

Kurz: **alles ist vollständig implementiert**, nichts ist ein Platzhalter
oder eine vorgetäuschte Funktion - aber die genannten Punkte solltest du
nach der ersten Installation auf deiner echten Hardware kurz gegenprüfen.

---

## Projektstruktur

```
ai_desk_robot/
├── app/
│   ├── main.py                 # Einstiegspunkt (Flask-App-Factory, Start)
│   ├── config.py                # .env + config.yaml Konfiguration
│   ├── database.py               # SQLite-Datenschicht
│   ├── agent.py                   # Zustandsmaschine der Video-Pipeline
│   ├── research.py                 # RSS-Recherche + lokaler Fallback-Pool
│   ├── topic_selector.py            # Themenauswahl, Dopplungserkennung
│   ├── fact_checker.py               # Wikipedia-Faktenprüfung
│   ├── script_generator.py            # Hook/Kontext/Fakten/Schluss + Metadaten
│   ├── media.py                        # Hintergrund-Visuals (Stock/lokal)
│   ├── subtitles.py                     # SRT + ASS Untertitel-Generierung
│   ├── video.py                          # FFmpeg-Rendering + QC (ffprobe)
│   ├── tiktok.py                          # offizielle TikTok Content Posting API
│   ├── scheduler.py                        # Zeitplan + Watchdog
│   ├── system.py                            # CPU/RAM/Disk/Temp/Netzwerk
│   ├── logging_setup.py                      # Logging inkl. Secret-Redaction
│   ├── providers/
│   │   ├── llm_provider.py                     # Ollama + regelbasierter Fallback
│   │   ├── tts_provider.py                      # Piper + espeak-ng + Notfall
│   │   └── weather_provider.py                   # Open-Meteo
│   ├── services/
│   │   └── qrcode_gen.py                          # eigenständiger QR-Generator
│   └── web/
│       ├── routes.py                                # Dashboard-API
│       └── upload_server.py                          # manueller Upload-Server
├── static/{css,js}/            # Design-System + Robotergesicht + Dashboard-Logik
├── templates/                  # Jinja2-Templates
├── data/{db,videos,audio,logs,backups}/
├── tests/                       # automatisierte Tests (unittest)
├── systemd/                     # Autostart-Unit-Dateien
├── install.sh / uninstall.sh / launcher.sh / manage.sh
├── requirements.txt / .env.example / config.yaml
└── README.md
```
