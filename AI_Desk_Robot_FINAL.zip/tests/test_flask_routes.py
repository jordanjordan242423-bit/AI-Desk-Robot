"""Tests für app.web.routes - alle wichtigen Flask-Endpunkte."""
import sys
import os
import unittest
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestFlaskRoutes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app.config as cfgmod
        cls._tmpdir = tempfile.mkdtemp()
        cfgmod.DB_PATH = Path(cls._tmpdir) / "test_routes.sqlite3"

        import app.database as database
        import importlib
        importlib.reload(database)
        database.init_db()
        cls.database = database

        from app.main import create_app
        cls.app = create_app()
        cls.app.testing = True
        cls.client = cls.app.test_client()

    def test_dashboard_loads(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"AI DESK ROBOT", r.data)
        # kritische Frontend-Assets müssen referenziert sein
        self.assertIn(b"face.js", r.data)
        self.assertIn(b"dashboard.js", r.data)
        self.assertIn(b"main.css", r.data)

    def test_status_endpoint(self):
        r = self.client.get("/api/status")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertIn("system", data)
        self.assertIn("agent", data)
        self.assertIn("stats", data)

    def test_jobs_endpoint(self):
        r = self.client.get("/api/jobs")
        self.assertEqual(r.status_code, 200)
        self.assertIsInstance(r.get_json(), list)

    def test_job_detail_404_for_unknown(self):
        r = self.client.get("/api/jobs/DOES-NOT-EXIST")
        self.assertEqual(r.status_code, 404)

    def test_stats_endpoint(self):
        r = self.client.get("/api/stats")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertIn("total", data)

    def test_logs_endpoint(self):
        r = self.client.get("/api/logs")
        self.assertEqual(r.status_code, 200)
        self.assertIsInstance(r.get_json(), list)

    def test_settings_get_and_post(self):
        r = self.client.get("/api/settings")
        self.assertEqual(r.status_code, 200)
        original = r.get_json()["videos_per_day"]

        r2 = self.client.post("/api/settings", json={"videos_per_day": 4})
        self.assertEqual(r2.status_code, 200)
        self.assertTrue(r2.get_json()["saved"])

        r3 = self.client.get("/api/settings")
        self.assertEqual(r3.get_json()["videos_per_day"], 4)

        # zurücksetzen, um andere Tests/echte Nutzung nicht zu beeinflussen
        self.client.post("/api/settings", json={"videos_per_day": original})

    def test_settings_post_rejects_invalid_values(self):
        """
        Regressionstest für einen echten Bug (Audit-Fund): ungültige Werte
        (z.B. null/String/außerhalb des sinnvollen Bereichs) durften NICHT
        ungeprüft in config.yaml persistiert werden - das hätte den Scheduler
        beim nächsten Durchlauf mit einem TypeError lahmgelegt.
        """
        r = self.client.get("/api/settings")
        original = r.get_json()["videos_per_day"]

        for bad_value in (None, "abc", -1, 0, 999, True, [1, 2]):
            r2 = self.client.post("/api/settings", json={"videos_per_day": bad_value})
            self.assertEqual(r2.status_code, 200)
            data = r2.get_json()
            self.assertIn("rejected", data, f"Wert {bad_value!r} hätte abgelehnt werden müssen")
            self.assertIn("videos_per_day", data["rejected"])

        # Der zuletzt gültige Wert darf durch die abgelehnten Versuche nicht verändert worden sein
        r3 = self.client.get("/api/settings")
        self.assertEqual(r3.get_json()["videos_per_day"], original)

    def test_settings_post_rejects_unknown_keys(self):
        """Unbekannte/nicht vorgesehene Einstellungsschlüssel dürfen nicht einfach
        durchgereicht werden (verhindert versehentliches Kaputtschreiben verschachtelter
        Konfigurationsbereiche wie 'llm' oder 'tiktok')."""
        r = self.client.post("/api/settings", json={"llm": "kaputter-wert"})
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertIn("rejected", data)
        self.assertIn("llm", data["rejected"])
        # 'llm' muss weiterhin ein Dict sein (nicht überschrieben worden)
        r2 = self.client.get("/api/settings")
        self.assertIsInstance(r2.get_json()["llm"], dict)

    def test_upload_qr_png(self):
        r = self.client.get("/api/upload-qr.png")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.content_type, "image/png")
        self.assertTrue(r.data.startswith(b"\x89PNG"))

    def test_upload_url_endpoint(self):
        r = self.client.get("/api/upload-url")
        self.assertEqual(r.status_code, 200)
        self.assertIn("url", r.get_json())

    def test_tiktok_connect_without_config_shows_hint(self):
        r = self.client.get("/tiktok/connect")
        self.assertEqual(r.status_code, 200)
        self.assertIn("nicht konfiguriert".encode("utf-8"), r.data)

    def test_tiktok_disconnect(self):
        r = self.client.post("/api/tiktok/disconnect")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json()["disconnected"])

    def test_agent_run_now_endpoint_responds(self):
        r = self.client.post("/api/agent/run-now")
        self.assertEqual(r.status_code, 200)
        self.assertIn("started", r.get_json())

    def test_404_handler_returns_json(self):
        r = self.client.get("/this-route-does-not-exist")
        self.assertEqual(r.status_code, 404)
        self.assertEqual(r.get_json()["error"], "not_found")

    def test_media_video_404_for_unknown_job(self):
        r = self.client.get("/media/video/UNKNOWN-JOB")
        self.assertEqual(r.status_code, 404)

    def test_media_download_404_for_unknown_job(self):
        r = self.client.get("/media/download/UNKNOWN-JOB")
        self.assertEqual(r.status_code, 404)

    def test_tiktok_manual_upload_404_without_real_video_file(self):
        """Die manuelle Upload-Seite darf nicht für Jobs ohne wirklich existierende
        Videodatei aufrufbar sein (verhindert kaputte/leere Seiten)."""
        self.database.create_job("JOB-MANUAL-404", category="Test")
        self.database.update_job("JOB-MANUAL-404", status="READY", video_file="/pfad/existiert/nicht.mp4")
        r = self.client.get("/tiktok/manual/JOB-MANUAL-404")
        self.assertEqual(r.status_code, 404)

    def test_tiktok_manual_upload_shows_video_info_when_file_exists(self):
        """Mit einer wirklich existierenden Videodatei muss die manuelle Upload-Seite
        Titel/Beschreibung/Hashtags anzeigen und einen Download-Button sowie einen
        job-spezifischen QR-Code enthalten (Video darf nie verloren gehen)."""
        with tempfile.TemporaryDirectory() as tmp:
            fake_video = Path(tmp) / "test.mp4"
            fake_video.write_bytes(b"FAKE_MP4_CONTENT")
            self.database.create_job("JOB-MANUAL-OK", category="Test")
            self.database.update_job(
                "JOB-MANUAL-OK", status="READY", video_file=str(fake_video),
                title="Mein Testtitel", description="Meine Testbeschreibung", hashtags="#test,#demo",
                error="Upload fehlgeschlagen: Simulierter Testfehler",
            )
            r = self.client.get("/tiktok/manual/JOB-MANUAL-OK")
            self.assertEqual(r.status_code, 200)
            self.assertIn(b"Mein Testtitel", r.data)
            self.assertIn(b"Meine Testbeschreibung", r.data)
            self.assertIn("herunterladen".encode("utf-8"), r.data.lower())
            self.assertIn("Simulierter Testfehler".encode("utf-8"), r.data)

            # Download-Route muss die echte Datei liefern
            dl = self.client.get("/media/download/JOB-MANUAL-OK")
            self.assertEqual(dl.status_code, 200)
            self.assertEqual(dl.data, b"FAKE_MP4_CONTENT")

            # job-spezifischer QR-Code muss ein gültiges PNG liefern
            qr = self.client.get("/api/upload-qr/JOB-MANUAL-OK.png")
            self.assertEqual(qr.status_code, 200)
            self.assertTrue(qr.data.startswith(b"\x89PNG"))


class TestUploadServer(unittest.TestCase):
    def test_upload_index_loads(self):
        from app.web.upload_server import upload_app
        client = upload_app.test_client()
        r = client.get("/upload")
        self.assertEqual(r.status_code, 200)

    def test_upload_video_404_for_unknown_job(self):
        from app.web.upload_server import upload_app
        client = upload_app.test_client()
        r = client.get("/upload/video/UNKNOWN-JOB")
        self.assertEqual(r.status_code, 404)

    def test_upload_single_404_without_real_video_file(self):
        from app.web.upload_server import upload_app
        from app import database
        database.init_db()
        database.create_job("JOB-UPLOAD-SINGLE-404", category="Test")
        database.update_job("JOB-UPLOAD-SINGLE-404", status="READY", video_file="/nicht/vorhanden.mp4")
        client = upload_app.test_client()
        r = client.get("/upload/JOB-UPLOAD-SINGLE-404")
        self.assertEqual(r.status_code, 404)

    def test_upload_single_and_stream_work_with_real_file(self):
        from app.web.upload_server import upload_app
        from app import database
        database.init_db()
        with tempfile.TemporaryDirectory() as tmp:
            fake_video = Path(tmp) / "test.mp4"
            fake_video.write_bytes(b"FAKE_MP4_BYTES")
            database.create_job("JOB-UPLOAD-SINGLE-OK", category="Test")
            database.update_job(
                "JOB-UPLOAD-SINGLE-OK", status="READY", video_file=str(fake_video),
                title="Mobiler Testtitel",
            )
            client = upload_app.test_client()
            r = client.get("/upload/JOB-UPLOAD-SINGLE-OK")
            self.assertEqual(r.status_code, 200)
            self.assertIn(b"Mobiler Testtitel", r.data)

            stream = client.get("/upload/stream/JOB-UPLOAD-SINGLE-OK")
            self.assertEqual(stream.status_code, 200)
            self.assertEqual(stream.data, b"FAKE_MP4_BYTES")


if __name__ == "__main__":
    unittest.main()
