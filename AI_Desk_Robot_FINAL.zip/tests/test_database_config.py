"""Tests für app.config und app.database."""
import sys
import os
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestConfig(unittest.TestCase):
    def test_config_loads_defaults(self):
        from app.config import config
        self.assertEqual(config.get("videos_per_day"), 2)
        self.assertEqual(config.get("language"), "de")
        self.assertIsInstance(config.get("topics.categories"), list)
        self.assertGreater(len(config.get("topics.categories")), 5)

    def test_config_set_and_get(self):
        from app.config import config
        original = config.get("videos_per_day")
        try:
            config.set("videos_per_day", 5)
            self.assertEqual(config.get("videos_per_day"), 5)
        finally:
            config.set("videos_per_day", original)

    def test_config_missing_key_returns_default(self):
        from app.config import config
        self.assertIsNone(config.get("does.not.exist"))
        self.assertEqual(config.get("does.not.exist", "fallback"), "fallback")

    def test_env_has_no_hardcoded_secrets(self):
        """Stellt sicher, dass keine Secrets im Code stehen (nur in .env / os.environ)."""
        from app.config import env
        # Standardwert für secret_key muss der offensichtliche Platzhalter sein, kein echtes Secret
        self.assertTrue(len(env.secret_key) > 0)

    def test_safe_int_never_crashes_on_malformed_env_values(self):
        """
        Regressionstest für einen echten Bug (Audit-Fund): ein fehlerhafter/leerer
        Wert für FLASK_PORT/UPLOAD_PORT/GPIO_BUTTON_PIN in .env durfte die App NICHT
        schon beim Modul-Import zum Absturz bringen (vorher: ungefangene ValueError).
        """
        from app.config import _safe_int
        self.assertEqual(_safe_int("abc", 8080), 8080)
        self.assertEqual(_safe_int("", 8080), 8080)
        self.assertEqual(_safe_int(None, 8080), 8080)
        self.assertEqual(_safe_int("9090", 8080), 9090)
        self.assertEqual(_safe_int("  9090  ", 8080), 9090)


class TestDatabase(unittest.TestCase):
    def setUp(self):
        # Eigene temporäre Datenbank pro Test, um Testläufe voneinander zu isolieren
        import app.config as cfgmod
        self._tmpdir = tempfile.mkdtemp()
        self._original_db_path = cfgmod.DB_PATH
        cfgmod.DB_PATH = Path(self._tmpdir) / "test.sqlite3"

        import app.database as database
        import importlib
        importlib.reload(database)
        self.database = database
        self.database.init_db()

    def tearDown(self):
        import app.config as cfgmod
        cfgmod.DB_PATH = self._original_db_path

    def test_create_and_get_job(self):
        self.database.create_job("JOB-TEST-1", category="Technik")
        job = self.database.get_job("JOB-TEST-1")
        self.assertIsNotNone(job)
        self.assertEqual(job["status"], "QUEUED")
        self.assertEqual(job["category"], "Technik")

    def test_update_job(self):
        self.database.create_job("JOB-TEST-2", category="Natur")
        self.database.update_job("JOB-TEST-2", status="READY", topic="Testthema")
        job = self.database.get_job("JOB-TEST-2")
        self.assertEqual(job["status"], "READY")
        self.assertEqual(job["topic"], "Testthema")

    def test_list_jobs_and_filter(self):
        self.database.create_job("JOB-A", category="Technik")
        self.database.create_job("JOB-B", category="Natur")
        self.database.update_job("JOB-B", status="READY")
        all_jobs = self.database.list_jobs(limit=10)
        self.assertEqual(len(all_jobs), 2)
        ready_jobs = self.database.list_jobs(limit=10, status="READY")
        self.assertEqual(len(ready_jobs), 1)
        self.assertEqual(ready_jobs[0]["id"], "JOB-B")

    def test_stats_summary_no_deadlock(self):
        """Regressionstest für den behobenen Deadlock (verschachtelter db_cursor-Aufruf)."""
        self.database.create_job("JOB-STATS", category="Technik")
        self.database.update_job("JOB-STATS", status="PUBLISHED")
        stats = self.database.stats_summary()
        self.assertEqual(stats["total"], 1)
        self.assertEqual(stats["published"], 1)
        self.assertIn("today", stats)

    def test_active_job_excludes_terminal_states(self):
        self.database.create_job("JOB-ACTIVE", category="Technik")
        self.database.update_job("JOB-ACTIVE", status="SCRIPTING")
        active = self.database.active_job()
        self.assertIsNotNone(active)
        self.assertEqual(active["id"], "JOB-ACTIVE")

        self.database.update_job("JOB-ACTIVE", status="READY")
        active2 = self.database.active_job()
        self.assertIsNone(active2)

    def test_used_topics_and_recent(self):
        self.database.add_used_topic("Testthema XYZ", "Technik")
        recent = self.database.recent_topics(days=30)
        self.assertIn("Testthema XYZ", recent)

    def test_events_logging(self):
        self.database.log_event("INFO", "Testereignis")
        self.database.log_event("ERROR", "Testfehler")
        events = self.database.recent_events(limit=10)
        self.assertEqual(len(events), 2)
        errors = self.database.error_count_last_days(days=7)
        self.assertEqual(errors, 1)

    def test_tiktok_tokens_roundtrip(self):
        self.database.save_tiktok_tokens("access123", "refresh456", "2030-01-01T00:00:00", "open789")
        tokens = self.database.get_tiktok_tokens()
        self.assertEqual(tokens["access_token"], "access123")
        self.database.clear_tiktok_tokens()
        self.assertIsNone(self.database.get_tiktok_tokens())


if __name__ == "__main__":
    unittest.main()
