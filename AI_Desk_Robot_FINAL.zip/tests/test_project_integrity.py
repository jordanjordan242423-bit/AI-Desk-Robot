"""
Tests für die Projektstruktur selbst: Installationsskripte, systemd-Units,
Vollständigkeit, keine vergessenen Platzhalter (Master-Prompt Abschnitt 41).
"""
import sys
import os
import re
import unittest
import subprocess
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
PROJECT_ROOT = Path(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestInstallScripts(unittest.TestCase):
    def test_required_scripts_exist_and_executable(self):
        for name in ("install.sh", "uninstall.sh", "launcher.sh", "manage.sh"):
            path = PROJECT_ROOT / name
            self.assertTrue(path.exists(), f"{name} fehlt")
            self.assertTrue(os.access(path, os.X_OK), f"{name} ist nicht ausführbar")

    def test_scripts_have_valid_bash_syntax(self):
        for name in ("install.sh", "uninstall.sh", "launcher.sh", "manage.sh"):
            path = PROJECT_ROOT / name
            result = subprocess.run(["bash", "-n", str(path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, f"{name} hat einen Syntaxfehler:\n{result.stderr}")

    def test_systemd_units_exist(self):
        for name in ("ai-desk-robot-backend.service", "ai-desk-robot-kiosk.service"):
            path = PROJECT_ROOT / "systemd" / name
            self.assertTrue(path.exists(), f"{name} fehlt")
            content = path.read_text(encoding="utf-8")
            self.assertIn("[Unit]", content)
            self.assertIn("[Service]", content)
            self.assertIn("[Install]", content)
            self.assertIn("Restart=always", content)

    def test_requirements_file_exists_and_nonempty(self):
        path = PROJECT_ROOT / "requirements.txt"
        self.assertTrue(path.exists())
        content = path.read_text(encoding="utf-8")
        self.assertIn("Flask", content)
        self.assertIn("psutil", content)

    def test_env_example_has_no_real_secrets(self):
        path = PROJECT_ROOT / ".env.example"
        self.assertTrue(path.exists())
        content = path.read_text(encoding="utf-8")
        # Alle Key-Felder müssen leer oder offensichtliche Platzhalter sein
        for line in content.splitlines():
            if line.startswith("TIKTOK_CLIENT_SECRET="):
                self.assertEqual(line.strip(), "TIKTOK_CLIENT_SECRET=")

    def test_config_yaml_exists_and_valid(self):
        import yaml
        path = PROJECT_ROOT / "config.yaml"
        self.assertTrue(path.exists())
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        self.assertEqual(data["videos_per_day"], 2)
        self.assertIn("topics", data)

    def test_install_sh_aborts_hard_on_missing_core_dependency(self):
        """Regressionstest: install.sh muss bei fehlenden Pflichtabhängigkeiten
        (Python3/venv/FFmpeg, Flask/PyYAML/requests/psutil) sauber mit exit 1
        abbrechen, BEVOR irgendein systemd-Dienst eingerichtet wird."""
        content = (PROJECT_ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("abort_install", content)
        self.assertIn("exit 1", content)
        # Eine echte abort_install-Aufrufstelle (nicht nur die Kopfkommentar-Erwähnung)
        # muss vor dem tatsächlichen 'step \"systemd-Services einrichten\"'-Aufruf stehen.
        real_abort_call_pos = content.find('abort_install "Flask')
        real_systemd_step_pos = content.find('step "systemd-Services einrichten"')
        self.assertGreater(real_abort_call_pos, -1, "Erwarteter abort_install-Aufruf für fehlende Python-Pakete nicht gefunden")
        self.assertGreater(real_systemd_step_pos, -1, "Erwarteter systemd-Einrichtungsschritt nicht gefunden")
        self.assertLess(real_abort_call_pos, real_systemd_step_pos)

    def test_install_sh_automates_ollama_setup(self):
        """Regressionstest: install.sh muss versuchen, Ollama + Modell automatisiert
        einzurichten, und bei fehlendem Internet klar auf manuelles Nachholen hinweisen."""
        content = (PROJECT_ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("ollama.com/install.sh", content)
        self.assertIn("ollama pull", content)
        self.assertIn("has_internet", content)
        self.assertIn("manuell nachinstallieren", content)

    def test_install_sh_automates_piper_setup_with_functional_check(self):
        """Regressionstest: install.sh muss Piper automatisiert einzurichten versuchen
        UND danach echt testen, dass die Ausgabe hörbar (nicht still) ist."""
        content = (PROJECT_ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("piper", content.lower())
        self.assertIn("tts_provider.synthesize", content)
        self.assertIn("espeak-ng", content)

    def test_install_sh_handles_both_chromium_package_names(self):
        """Regressionstest: install.sh muss sowohl 'chromium-browser' als auch
        'chromium' als mögliche Paketnamen probieren (Raspberry Pi OS Version-abhängig)."""
        content = (PROJECT_ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("chromium-browser", content)
        self.assertIn("apt-get install -y chromium", content)

    def test_tts_provider_has_no_silent_success_path(self):
        """Regressionstest: tts_provider.synthesize() darf keinen Rückgabepfad mehr
        haben, der Stille als Erfolg zurückgibt - nur noch TTSError bei Fehlschlag."""
        content = (PROJECT_ROOT / "app" / "providers" / "tts_provider.py").read_text(encoding="utf-8")
        self.assertNotIn('"stille_notfall"', content)
        self.assertIn("raise TTSError", content)

    def test_script_generator_has_hard_quality_gate(self):
        content = (PROJECT_ROOT / "app" / "script_generator.py").read_text(encoding="utf-8")
        self.assertIn("class ScriptQualityError", content)
        self.assertIn("raise ScriptQualityError", content)

    def test_fact_checker_returns_none_type_hint_present(self):
        """Statische Absicherung: build_fact_base() muss laut Signatur None
        zurückgeben können (siehe funktionalen Test in test_research_script_fallbacks.py
        für das tatsächliche Verhalten ohne vertrauenswürdige Quelle)."""
        content = (PROJECT_ROOT / "app" / "fact_checker.py").read_text(encoding="utf-8")
        self.assertIn("return None", content)

    def test_dashboard_js_has_manual_tiktok_upload_button(self):
        content = (PROJECT_ROOT / "static" / "js" / "dashboard.js").read_text(encoding="utf-8")
        self.assertIn("/tiktok/manual/", content)


class TestNoForbiddenPlaceholders(unittest.TestCase):
    """Master-Prompt Abschnitt 41: keine TODO/FIXME/'coming soon'/'not implemented' im Produktivcode."""

    FORBIDDEN_PATTERNS = [r"\bTODO\b", r"\bFIXME\b", r"coming soon", r"not implemented", r"demo only"]
    SCAN_DIRS = ["app", "static", "templates"]

    def test_no_placeholder_markers_in_source(self):
        violations = []
        for scan_dir in self.SCAN_DIRS:
            base = PROJECT_ROOT / scan_dir
            if not base.exists():
                continue
            for path in base.rglob("*"):
                if path.is_file() and path.suffix in (".py", ".js", ".html", ".css"):
                    text = path.read_text(encoding="utf-8", errors="ignore")
                    for pattern in self.FORBIDDEN_PATTERNS:
                        if re.search(pattern, text, re.IGNORECASE):
                            violations.append(f"{path.relative_to(PROJECT_ROOT)}: Muster '{pattern}' gefunden")
        self.assertEqual(violations, [], "Platzhalter gefunden:\n" + "\n".join(violations))


class TestProjectFilesComplete(unittest.TestCase):
    REQUIRED_FILES = [
        "app/main.py", "app/config.py", "app/database.py", "app/agent.py",
        "app/research.py", "app/topic_selector.py", "app/fact_checker.py",
        "app/script_generator.py", "app/media.py", "app/subtitles.py", "app/video.py",
        "app/tiktok.py", "app/scheduler.py", "app/system.py", "app/logging_setup.py",
        "app/providers/llm_provider.py", "app/providers/tts_provider.py", "app/providers/weather_provider.py",
        "app/services/qrcode_gen.py",
        "app/web/routes.py", "app/web/upload_server.py",
        "static/css/main.css", "static/js/face.js", "static/js/dashboard.js",
        "templates/dashboard.html", "templates/upload.html",
        "templates/tiktok_manual_upload.html", "templates/upload_single.html",
        "install.sh", "uninstall.sh", "launcher.sh", "manage.sh",
        "systemd/ai-desk-robot-backend.service", "systemd/ai-desk-robot-kiosk.service",
        "requirements.txt", ".env.example", "config.yaml", "README.md",
    ]

    def test_all_required_files_present(self):
        missing = [f for f in self.REQUIRED_FILES if not (PROJECT_ROOT / f).exists()]
        self.assertEqual(missing, [], f"Fehlende Dateien: {missing}")


if __name__ == "__main__":
    unittest.main()
