"""Tests für app.agent (Prozessliste/Face-States) und app.scheduler (Entscheidungslogik)."""
import sys
import os
import unittest
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestAgentProcessList(unittest.TestCase):
    def test_process_list_no_job(self):
        from app.agent import get_process_list, PIPELINE_STEPS
        result = get_process_list(None)
        self.assertEqual(len(result), len(PIPELINE_STEPS))
        for item in result:
            self.assertEqual(item["status"], "pending")

    def test_process_list_marks_done_and_active(self):
        from app.agent import get_process_list
        job = {"status": "TTS"}
        result = get_process_list(job)
        statuses = {item["key"]: item["status"] for item in result}
        self.assertEqual(statuses["RESEARCHING"], "done")
        self.assertEqual(statuses["SELECTING"], "done")
        self.assertEqual(statuses["TTS"], "active")
        self.assertEqual(statuses["RENDERING"], "pending")

    def test_process_list_marks_failed(self):
        from app.agent import get_process_list
        job = {"status": "FAILED"}
        result = get_process_list(job)
        # Mindestens ein Schritt muss als 'failed' markiert sein, keiner als 'active'
        statuses = [item["status"] for item in result]
        self.assertIn("failed", statuses)
        self.assertNotIn("active", statuses)

    def test_slugify(self):
        from app.agent import _slugify
        result = _slugify("Warum die Venus rückwärts rotiert!")
        self.assertNotIn(" ", result)
        self.assertNotIn("!", result)
        self.assertTrue(len(result) <= 40)

    def test_try_reserve_run_slot_is_atomic_under_concurrency(self):
        """
        Regressionstest für eine echte Race Condition (Audit-Fund): Scheduler und
        der manuelle 'Jetzt Video erstellen'-Button prüften vorher unabhängig
        voneinander, ob bereits ein Job läuft, BEVOR der jeweils gestartete Thread
        selbst 'is_running=True' setzte - dadurch konnten (fast) gleichzeitige
        Aufrufe beide erfolgreich reservieren und zwei parallele Jobs starten.
        Dieser Test lässt viele Threads gleichzeitig um die Reservierung
        konkurrieren und prüft, dass GENAU EINER gewinnt.
        """
        import threading
        from app import agent

        agent.state.is_running = False
        results = []
        results_lock = threading.Lock()

        def attempt():
            got_it = agent.try_reserve_run_slot()
            with results_lock:
                results.append(got_it)

        threads = [threading.Thread(target=attempt) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        try:
            self.assertEqual(results.count(True), 1, "Genau EIN Aufrufer darf den Lauf-Slot reservieren können")
            self.assertEqual(results.count(False), 19)
        finally:
            agent.state.is_running = False  # aufräumen für nachfolgende Tests

    def test_try_reserve_run_slot_releases_correctly(self):
        from app import agent
        agent.state.is_running = False
        self.assertTrue(agent.try_reserve_run_slot())
        self.assertFalse(agent.try_reserve_run_slot(), "Ein zweiter Versuch darf fehlschlagen, während der erste noch aktiv ist")
        agent.state.is_running = False
        self.assertTrue(agent.try_reserve_run_slot(), "Nach Freigabe muss eine neue Reservierung wieder möglich sein")
        agent.state.is_running = False


class TestSchedulerLogic(unittest.TestCase):
    def setUp(self):
        import app.config as cfgmod
        self._tmpdir = tempfile.mkdtemp()
        cfgmod.DB_PATH = Path(self._tmpdir) / "test_scheduler.sqlite3"
        import app.database as database
        import importlib
        importlib.reload(database)
        database.init_db()
        self.database = database

        import app.scheduler as scheduler
        importlib.reload(scheduler)
        self.scheduler = scheduler

        import app.agent as agent
        self.agent = agent
        agent.state.is_running = False
        agent.state.current_job_id = None

    def test_should_start_when_nothing_running_and_no_jobs_today(self):
        self.assertTrue(self.scheduler._should_start_new_job())

    def test_should_not_start_when_daily_limit_reached(self):
        from app.config import config
        limit = config.get("videos_per_day", 2)
        for i in range(limit):
            self.database.create_job(f"JOB-LIMIT-{i}", category="Technik")
            self.database.update_job(f"JOB-LIMIT-{i}", status="READY")
        self.assertFalse(self.scheduler._should_start_new_job())

    def test_should_not_start_when_active_job_exists(self):
        self.database.create_job("JOB-ACTIVE-SCHED", category="Technik")
        self.database.update_job("JOB-ACTIVE-SCHED", status="SCRIPTING")
        self.assertFalse(self.scheduler._should_start_new_job())

    def test_should_not_start_when_agent_already_running(self):
        self.agent.state.is_running = True
        try:
            self.assertFalse(self.scheduler._should_start_new_job())
        finally:
            self.agent.state.is_running = False


if __name__ == "__main__":
    unittest.main()
