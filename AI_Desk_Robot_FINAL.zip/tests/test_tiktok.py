"""
Tests für app.tiktok - Creator-Info-Auswertung und Veröffentlichungsstatus-Polling.

Da kein echter TikTok-Developer-Account zur Verfügung steht, werden die HTTP-Aufrufe
gezielt gemockt, um die reine Auswertungslogik (welche Einstellungen werden gewählt,
wie wird der Status interpretiert) zu verifizieren.
"""
import sys
import os
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestResolvePostSettings(unittest.TestCase):
    def test_prefers_self_only_when_allowed(self):
        from app.tiktok import _resolve_post_settings
        creator_info = {
            "privacy_level_options": ["PUBLIC_TO_EVERYONE", "SELF_ONLY", "MUTUAL_FOLLOW_FRIENDS"],
            "comment_disabled": False, "duet_disabled": False, "stitch_disabled": False,
        }
        settings = _resolve_post_settings(creator_info)
        self.assertEqual(settings["privacy_level"], "SELF_ONLY")

    def test_falls_back_to_first_allowed_option_when_self_only_not_available(self):
        from app.tiktok import _resolve_post_settings
        creator_info = {"privacy_level_options": ["PUBLIC_TO_EVERYONE", "MUTUAL_FOLLOW_FRIENDS"]}
        settings = _resolve_post_settings(creator_info)
        self.assertEqual(settings["privacy_level"], "PUBLIC_TO_EVERYONE")

    def test_defaults_to_self_only_when_no_options_given(self):
        from app.tiktok import _resolve_post_settings
        settings = _resolve_post_settings({})
        self.assertEqual(settings["privacy_level"], "SELF_ONLY")

    def test_respects_platform_disabled_interactions(self):
        from app.tiktok import _resolve_post_settings
        creator_info = {
            "privacy_level_options": ["SELF_ONLY"],
            "comment_disabled": True, "duet_disabled": True, "stitch_disabled": False,
        }
        settings = _resolve_post_settings(creator_info)
        self.assertTrue(settings["disable_comment"])
        self.assertTrue(settings["disable_duet"])
        self.assertFalse(settings["disable_stitch"])


class TestWaitForPublishResult(unittest.TestCase):
    @patch("app.tiktok.check_publish_status")
    def test_returns_success_on_complete_status(self, mock_check):
        from app.tiktok import wait_for_publish_result
        mock_check.return_value = {"data": {"status": "PUBLISH_COMPLETE"}}
        result = wait_for_publish_result("pub123", timeout_s=5, poll_interval_s=0.1)
        self.assertEqual(result["resolved_status"], "SUCCESS")

    @patch("app.tiktok.check_publish_status")
    def test_raises_on_failed_status(self, mock_check):
        from app.tiktok import wait_for_publish_result, TikTokAPIError
        mock_check.return_value = {"data": {"status": "FAILED"}}
        with self.assertRaises(TikTokAPIError):
            wait_for_publish_result("pub123", timeout_s=5, poll_interval_s=0.1)

    @patch("app.tiktok.check_publish_status")
    def test_raises_on_timeout_without_terminal_status(self, mock_check):
        from app.tiktok import wait_for_publish_result, TikTokAPIError
        mock_check.return_value = {"data": {"status": "PROCESSING_UPLOAD"}}
        with self.assertRaises(TikTokAPIError):
            wait_for_publish_result("pub123", timeout_s=0.3, poll_interval_s=0.1)


class TestUploadVideoNeverLosesVideoOnFailure(unittest.TestCase):
    """
    Regressionstest für die zentrale Anforderung: schlägt der automatische Upload
    fehl (egal an welcher Stelle), muss upload_video() eine Exception werfen -
    der Aufrufer (app.agent) fängt das ab und belässt den Job auf READY, statt
    ihn als FAILED zu markieren oder das Video zu verwerfen.
    """
    @patch("app.tiktok.is_connected", return_value=True)
    @patch("app.tiktok._refresh_if_needed", return_value="fake-token")
    @patch("app.tiktok.query_creator_info", side_effect=Exception("Creator-Info nicht erreichbar"))
    def test_upload_video_raises_when_creator_info_fails(self, mock_info, mock_refresh, mock_connected):
        from app.tiktok import upload_video
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            fake_video = Path(tmp) / "test.mp4"
            fake_video.write_bytes(b"FAKE")
            with self.assertRaises(Exception):
                upload_video(fake_video, "Titel", "Beschreibung")


if __name__ == "__main__":
    unittest.main()
