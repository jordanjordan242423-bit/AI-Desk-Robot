"""Tests für app.services.qrcode_gen, app.subtitles, app.system."""
import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestQRCodeGenerator(unittest.TestCase):
    def test_generate_matrix_structure(self):
        from app.services.qrcode_gen import generate_matrix
        matrix = generate_matrix("http://192.168.1.50:8765/upload")
        self.assertGreater(len(matrix), 20)
        # quadratisch
        for row in matrix:
            self.assertEqual(len(row), len(matrix))

    def test_finder_patterns_present(self):
        """Prüft, dass die drei charakteristischen 7x7-Eckmuster (Finder Patterns) vorhanden sind."""
        from app.services.qrcode_gen import generate_matrix
        matrix = generate_matrix("https://example.com")
        size = len(matrix)
        # Oben-links: äußerer Rahmen muss vollständig schwarz sein (erste Zeile des Finder-Patterns)
        self.assertTrue(all(matrix[0][c] == 1 for c in range(7)))
        self.assertTrue(all(matrix[c][0] == 1 for c in range(7)))
        # Unten-links Finder-Pattern
        self.assertTrue(all(matrix[size - 7][c] == 1 for c in range(7)))

    def test_png_bytes_are_valid_png(self):
        from app.services.qrcode_gen import generate_qr_png
        png = generate_qr_png("http://test.local/upload")
        self.assertTrue(png.startswith(b"\x89PNG\r\n\x1a\n"))
        self.assertGreater(len(png), 100)

    def test_svg_output_valid(self):
        from app.services.qrcode_gen import generate_qr_svg
        svg = generate_qr_svg("http://test.local/upload")
        self.assertTrue(svg.startswith("<svg"))
        self.assertIn("</svg>", svg)

    def test_too_long_text_raises_clear_error(self):
        from app.services.qrcode_gen import generate_matrix
        with self.assertRaises(ValueError):
            generate_matrix("x" * 500)


class TestSubtitles(unittest.TestCase):
    def test_generate_srt_creates_segments(self):
        from app.subtitles import generate_srt
        import tempfile
        from pathlib import Path
        text = "Dies ist ein Testsatz. Und noch ein zweiter Satz mit mehr Inhalt für die Segmentierung."
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "test.srt"
            result = generate_srt(text, 10.0, out)
            self.assertTrue(result.exists())
            content = result.read_text(encoding="utf-8")
            self.assertIn("-->", content)
            self.assertIn("1\n", content)

    def test_generate_ass_has_correct_playres(self):
        from app.subtitles import generate_ass
        import tempfile
        from pathlib import Path
        text = "Ein Testsatz für die ASS-Untertitel-Generierung mit korrekter Positionierung."
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "test.ass"
            result = generate_ass(text, 8.0, out, video_width=1080, video_height=1920)
            content = result.read_text(encoding="utf-8")
            self.assertIn("PlayResX: 1080", content)
            self.assertIn("PlayResY: 1920", content)
            self.assertIn("[Events]", content)
            self.assertIn("Dialogue:", content)

    def test_ass_filter_escapes_path(self):
        from app.subtitles import ass_subtitle_filter
        from pathlib import Path
        result = ass_subtitle_filter(Path("/some/path/subtitles.ass"))
        self.assertTrue(result.startswith("subtitles="))


class TestSystem(unittest.TestCase):
    def test_full_status_never_raises(self):
        from app import system
        status = system.full_status()
        self.assertIn("cpu_percent", status)
        self.assertIn("ram", status)
        self.assertIn("disk", status)
        self.assertIn("internet", status)
        self.assertIsInstance(status["internet"], bool)

    def test_format_uptime(self):
        from app.system import format_uptime
        result = format_uptime(3661)  # 1h 1m 1s
        self.assertIn("h", result)
        self.assertIn("m", result)

    def test_temperature_does_not_crash_without_sensor(self):
        from app.system import get_temperature_c
        # Darf None zurückgeben, darf aber NIE eine Exception werfen (Abschnitt 45)
        try:
            result = get_temperature_c()
            self.assertTrue(result is None or isinstance(result, float))
        except Exception as e:
            self.fail(f"get_temperature_c() hat eine Exception geworfen: {e}")

    def test_check_piper_false_without_binary(self):
        """Regressionstest für den behobenen Bug: check_piper() darf NICHT allein
        deshalb True liefern, weil PIPER_VOICE_PATH irgendein (nicht-leerer) String
        ist - Binary und Stimmdatei müssen tatsächlich existieren."""
        from app import system
        from app.config import env
        original_bin = env.piper_bin
        original_voice = env.piper_voice_path
        try:
            env.piper_bin = "definitiv-nicht-vorhandene-piper-binary-xyz"
            env.piper_voice_path = "/pfad/der/nicht/existiert.onnx"
            self.assertFalse(system.check_piper())
        finally:
            env.piper_bin = original_bin
            env.piper_voice_path = original_voice

    def test_check_piper_false_with_empty_voice_file(self):
        """Auch eine leere (0 Byte) 'Stimmdatei' darf nicht als bereit gelten."""
        from app import system
        from app.config import env
        import tempfile
        from pathlib import Path
        original_bin = env.piper_bin
        original_voice = env.piper_voice_path
        try:
            with tempfile.TemporaryDirectory() as tmp:
                empty_voice = Path(tmp) / "empty.onnx"
                empty_voice.write_bytes(b"")
                env.piper_bin = "bash"  # existiert praktisch immer, nur zum Testen der Datei-Prüfung
                env.piper_voice_path = str(empty_voice)
                self.assertFalse(system.check_piper())
        finally:
            env.piper_bin = original_bin
            env.piper_voice_path = original_voice


if __name__ == "__main__":
    unittest.main()
