"""
Tests für app.research, app.topic_selector, app.fact_checker, app.script_generator,
app.providers.llm_provider, app.providers.tts_provider.

Da dieses Sandbox-Environment ohne Internet läuft, testen diese Tests explizit den
für die Bewertung wichtigsten Pfad: dass ALLE Fallback-Mechanismen ohne Absturz
funktionieren (Master-Prompt: 'App darf nicht komplett abstürzen').
"""
import sys
import os
import unittest
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


class TestResearch(unittest.TestCase):
    def test_gather_topics_never_empty(self):
        """Auch ohne Internet/RSS muss der lokale Fallback-Pool greifen (Abschnitt 10)."""
        from app.research import gather_topics
        topics = gather_topics()
        self.assertGreater(len(topics), 0)
        for t in topics:
            self.assertTrue(t.title)
            self.assertTrue(t.category)

    def test_fetch_feed_extracts_title_from_real_rss_xml(self):
        """
        Regressionstest für einen echten Bug (Audit-Fund): 'item.find(a) or item.find(b)'
        wertete ElementTree-Elemente über ihre KIND-ELEMENTE aus (nicht ihren Text),
        wodurch ein normales <title>Text</title> ohne Kind-Tags als 'falsy' galt und
        der Titel bei jedem echten RSS-Feed leer blieb. Dieser Test simuliert einen
        echten RSS-Feed (ohne Netzwerk, über einen gemockten HTTP-Response) und prüft,
        dass Titel und Beschreibung korrekt extrahiert werden.
        """
        from unittest.mock import patch, MagicMock
        from app.research import _fetch_feed

        rss_xml = b"""<?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <title>Testkanal</title>
            <item>
              <title>Echter Testtitel ohne Kind-Elemente</title>
              <description>Echte Testbeschreibung fuer den Regressionstest.</description>
            </item>
            <item>
              <title>Zweiter Titel</title>
              <description>Zweite Beschreibung.</description>
            </item>
          </channel>
        </rss>"""

        fake_response = MagicMock()
        fake_response.content = rss_xml
        fake_response.raise_for_status = lambda: None

        with patch("app.research.requests.get", return_value=fake_response):
            candidates = _fetch_feed("https://example.invalid/feed.xml")

        self.assertEqual(len(candidates), 2)
        self.assertEqual(candidates[0].title, "Echter Testtitel ohne Kind-Elemente")
        self.assertEqual(candidates[0].summary, "Echte Testbeschreibung fuer den Regressionstest.")
        self.assertEqual(candidates[1].title, "Zweiter Titel")

    def test_fetch_feed_strips_html_and_entities_from_description(self):
        """
        Regressionstest für einen echten Bug (Audit-Fund): RSS-Beschreibungen
        enthalten in der Praxis oft rohes HTML und Entities - das darf NICHT
        ungefiltert in Skript/Untertitel/TTS landen.
        """
        from unittest.mock import patch, MagicMock
        from app.research import _fetch_feed

        rss_xml = """<?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <item>
              <title>Titel mit &amp; Sonderzeichen</title>
              <description>&lt;p&gt;Ein Satz mit &lt;b&gt;HTML&lt;/b&gt; und &amp; Et-Zeichen.&lt;/p&gt;</description>
            </item>
          </channel>
        </rss>""".encode("utf-8")

        fake_response = MagicMock()
        fake_response.content = rss_xml
        fake_response.raise_for_status = lambda: None

        with patch("app.research.requests.get", return_value=fake_response):
            candidates = _fetch_feed("https://example.invalid/feed2.xml")

        self.assertEqual(len(candidates), 1)
        self.assertNotIn("<", candidates[0].title)
        self.assertNotIn("<", candidates[0].summary)
        self.assertNotIn("&amp;", candidates[0].summary)
        self.assertIn("HTML", candidates[0].summary)
        self.assertIn("&", candidates[0].summary)  # entschlüsselt aus &amp;
        self.assertEqual(candidates[0].title, "Titel mit & Sonderzeichen")


class TestTopicSelector(unittest.TestCase):
    def setUp(self):
        # Stellt sicher, dass die Datenbank-Tabellen existieren, unabhängig davon,
        # ob dieses Testmodul isoliert oder als Teil der Gesamt-Suite läuft
        # (init_db() ist idempotent: CREATE TABLE IF NOT EXISTS).
        from app import database
        database.init_db()

    def test_select_topic_returns_candidate(self):
        from app.topic_selector import select_topic
        candidate = select_topic()
        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.title)

    def test_similarity_detects_near_duplicates(self):
        from app.topic_selector import _similarity
        a = "Warum die Venus rückwärts rotiert"
        b = "Warum rotiert die Venus rückwärts im Vergleich zu anderen Planeten"
        score = _similarity(a, b)
        self.assertGreater(score, 0.5)

    def test_similarity_low_for_different_topics(self):
        from app.topic_selector import _similarity
        a = "Warum die Venus rückwärts rotiert"
        b = "Wie Zugvögel sich orientieren"
        score = _similarity(a, b)
        self.assertLess(score, 0.3)

    def test_select_topic_with_facts_and_script_passes_category_through(self):
        """
        Regressionstest: die Kategorie des gewählten Kandidaten muss an
        generate_script() durchgereicht werden, damit kategoriespezifische
        Hashtags (z.B. #weltraum für Kategorie 'Weltraum') tatsächlich greifen,
        statt immer nur auf den generischen '#wissenswert'-Fallback zu fallen.
        """
        from app.topic_selector import select_topic_with_facts_and_script
        candidate, fact_base, script = select_topic_with_facts_and_script()
        self.assertIsNotNone(candidate)
        self.assertIsNotNone(script)
        # Mindestens EIN Hashtag sollte nicht der generische Fallback sein,
        # wenn die Kategorie eine bekannte Zuordnung hat.
        from app.script_generator import _CATEGORY_TAGS
        expected_tags = _CATEGORY_TAGS.get(candidate.category)
        if expected_tags:
            hashtag_words = [t.lstrip("#") for t in script.hashtags]
            self.assertTrue(
                any(tag in hashtag_words for tag in expected_tags),
                f"Erwartete kategoriespezifische Hashtags {expected_tags} nicht in {hashtag_words} gefunden",
            )


class TestFactChecker(unittest.TestCase):
    def test_build_fact_base_returns_none_without_trustworthy_source(self):
        """
        Regressionstest für die aktualisierte Anforderung: OHNE Internet (Wikipedia
        nicht erreichbar) und OHNE eine ausreichend substantielle Ersatzbeschreibung
        muss build_fact_base() None liefern - NIEMALS einen generischen Ersatzsatz.
        """
        from app.fact_checker import build_fact_base
        fb = build_fact_base("Ein völlig erfundenes Test-Thema XYZ 12345")
        self.assertIsNone(fb)

    def test_fact_base_uses_fallback_summary_if_substantial(self):
        from app.fact_checker import build_fact_base
        fb = build_fact_base(
            "Noch ein erfundenes Thema ABC98765",
            fallback_summary="Dies ist ein ausreichend langer Testsatz als Ersatzbeschreibung, "
                              "der über die Mindestlänge für eine vertrauenswürdige Faktenbasis hinausgeht."
        )
        self.assertIsNotNone(fb)
        self.assertTrue(fb.facts)

    def test_fact_base_none_for_too_short_fallback_summary(self):
        """Eine sehr kurze/dürftige Ersatzbeschreibung darf NICHT als ausreichende
        Faktenbasis akzeptiert werden (keine generischen/dünnen Ersatzinhalte)."""
        from app.fact_checker import build_fact_base
        fb = build_fact_base("Noch ein Thema DEF54321", fallback_summary="Kurz.")
        self.assertIsNone(fb)


class TestLLMProvider(unittest.TestCase):
    def test_generate_falls_back_without_ollama(self):
        from app.providers import llm_provider
        text, source = llm_provider.generate("- Fakt eins\n- Fakt zwei\nSchreibe einen Hook.")
        self.assertTrue(text)
        self.assertIn(source, ("ollama", "fallback_regelbasiert"))

    def test_ollama_available_does_not_raise(self):
        from app.providers import llm_provider
        result = llm_provider.ollama_available()
        self.assertIsInstance(result, bool)


class TestTTSProvider(unittest.TestCase):
    def test_synthesize_succeeds_with_working_engine(self):
        """Mit einer funktionierenden (echten oder Test-)Engine muss eine echte
        Audiodatei mit dem korrekten Engine-Namen zurückgegeben werden."""
        from app.providers import tts_provider
        with tempfile.TemporaryDirectory() as tmp:
            out_path = Path(tmp) / "test.wav"
            result_path, engine = tts_provider.synthesize("Dies ist ein Testsatz.", out_path, estimated_duration_s=5.0)
            self.assertTrue(result_path.exists())
            self.assertGreater(result_path.stat().st_size, 0)
            self.assertIn(engine, ("piper", "espeak"))

    def test_synthesize_raises_when_no_engine_available(self):
        """
        Regressionstest für die abgesicherte Anforderung: Wenn WEDER Piper NOCH
        espeak-ng verfügbar sind, darf NIEMALS eine stille Ersatzdatei als Erfolg
        zurückgegeben werden - synthesize() muss stattdessen eine TTSError werfen,
        damit der Job korrekt als FAILED markiert wird (nie READY/uploadbereit).
        """
        from app.providers import tts_provider
        original_path = os.environ.get("PATH", "")
        try:
            # Leerer PATH -> weder Piper noch espeak-ng/espeak sind auffindbar
            os.environ["PATH"] = ""
            with tempfile.TemporaryDirectory() as tmp:
                out_path = Path(tmp) / "test.wav"
                with self.assertRaises(tts_provider.TTSError):
                    tts_provider.synthesize("Testsatz ohne verfügbare Engine.", out_path, estimated_duration_s=5.0)
                self.assertFalse(out_path.exists(), "Es darf keine (stille) Datei zurückbleiben, wenn synthesize() fehlschlägt.")
        finally:
            os.environ["PATH"] = original_path

    def test_synthesize_rejects_engine_that_silently_fails(self):
        """
        End-to-End-Regressionstest: Eine 'espeak-ng'-Binary, die Exit-Code 0 liefert aber
        nur Stille erzeugt (z.B. wegen fehlendem Sprachmodell), darf NICHT als 'engine=espeak'
        (also als echter Erfolg) durchgehen. synthesize() muss stattdessen eine TTSError werfen
        (kein stiller Notfall-Erfolg mehr - siehe test_synthesize_raises_when_no_engine_available).
        """
        from app.providers import tts_provider
        import stat

        with tempfile.TemporaryDirectory() as fake_bin_dir, tempfile.TemporaryDirectory() as work_dir:
            fake_espeak = Path(fake_bin_dir) / "espeak-ng"
            fake_espeak.write_text(
                "#!/usr/bin/env bash\n"
                "OUT=\"\"\n"
                "while [[ $# -gt 0 ]]; do\n"
                "  case \"$1\" in\n"
                "    -w) OUT=\"$2\"; shift 2 ;;\n"
                "    -v|-s) shift 2 ;;\n"
                "    *) shift ;;\n"
                "  esac\n"
                "done\n"
                "python3 -c \"import wave,struct; wf=wave.open('$OUT','w'); wf.setnchannels(1); "
                "wf.setsampwidth(2); wf.setframerate(22050); wf.writeframes(struct.pack('<h',0)*22050)\"\n"
                "exit 0\n"
            )
            fake_espeak.chmod(fake_espeak.stat().st_mode | stat.S_IEXEC)

            original_path = os.environ.get("PATH", "")
            # bash/python3 müssen weiterhin auffindbar sein (für das Fake-Skript selbst),
            # aber KEINE echte espeak-ng/Piper-Installation darf im Pfad sein - nur unser
            # stummes Fake-espeak-ng soll gefunden werden.
            os.environ["PATH"] = f"{fake_bin_dir}:/usr/bin:/bin"
            try:
                out_path = Path(work_dir) / "test.wav"
                with self.assertRaises(
                    tts_provider.TTSError,
                    msg="Eine stumme Ausgabe der 'espeak-ng'-Engine wurde faelschlich als Erfolg akzeptiert!"
                ):
                    tts_provider.synthesize("Testsatz.", out_path, estimated_duration_s=5.0)
            finally:
                os.environ["PATH"] = original_path

    def test_silence_fallback_respects_estimated_duration(self):
        from app.providers import tts_provider
        with tempfile.TemporaryDirectory() as tmp:
            out_path = Path(tmp) / "test_silence.wav"
            # Erzwingt den Notfall-Pfad durch Prüfung der internen Funktion direkt
            tts_provider._write_silence_wav(out_path, duration_s=20.0)
            duration = tts_provider.get_wav_duration_s(out_path)
            self.assertAlmostEqual(duration, 20.0, delta=0.5)

    def test_silent_output_from_real_engine_is_rejected_not_accepted_as_success(self):
        """
        Regressionstest für die Anforderung: ein technisch 'erfolgreicher' TTS-Aufruf
        (Exit-Code 0, Datei vorhanden) darf NIEMALS als echte Sprachausgabe durchgehen,
        wenn die erzeugte Audiodatei tatsächlich stumm ist.
        """
        from app.providers import tts_provider
        with tempfile.TemporaryDirectory() as tmp:
            silent_path = Path(tmp) / "silent.wav"
            tts_provider._write_silence_wav(silent_path, duration_s=5.0)
            self.assertTrue(tts_provider._wav_is_effectively_silent(silent_path))

    def test_audible_output_is_not_flagged_as_silent(self):
        from app.providers import tts_provider
        import wave
        import struct
        import math
        with tempfile.TemporaryDirectory() as tmp:
            audible_path = Path(tmp) / "audible.wav"
            rate = 22050
            duration = 1.0
            n = int(rate * duration)
            with wave.open(str(audible_path), "w") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(rate)
                samples = [int(12000 * math.sin(2 * math.pi * 220 * t / rate)) for t in range(n)]
                wf.writeframes(struct.pack(f"<{n}h", *samples))
            self.assertFalse(tts_provider._wav_is_effectively_silent(audible_path))


class TestScriptGenerator(unittest.TestCase):
    def test_generate_script_no_duplicate_sentences_in_fallback(self):
        """Regressionstest: der Fallback-Pfad darf nicht denselben Satz mehrfach wiederholen."""
        from app.script_generator import generate_script
        from app.fact_checker import FactBase
        fb = FactBase(
            topic="Testthema",
            facts=[
                "Dies ist der einzige verfügbare, aber ausreichend lange und inhaltsreiche Testfakt für "
                "diesen Testlauf, der genügend Wörter enthält, um die Mindestdauer des Skripts zu erreichen."
            ],
            source_name="test", verified=False,
        )
        script = generate_script("Testthema", fb)
        sentences = [s.strip() for s in script.full_text.split(".") if s.strip()]
        # Keine zwei identischen Sätze im generierten Text
        self.assertEqual(len(sentences), len(set(sentences)))

    def test_generate_script_produces_metadata(self):
        from app.script_generator import generate_script
        from app.fact_checker import FactBase
        fb = FactBase(
            topic="Testthema",
            facts=[
                "Dies ist der erste ausführliche Testfakt mit ausreichend vielen Wörtern.",
                "Dies ist der zweite ausführliche Testfakt, der ebenfalls genug Substanz enthält.",
                "Und hier folgt noch ein dritter, ebenfalls hinreichend langer Testfakt.",
            ],
            source_name="test", verified=True,
        )
        script = generate_script("Testthema", fb, category="Wissenschaft")
        self.assertTrue(script.title)
        self.assertTrue(script.description)
        self.assertGreater(len(script.hashtags), 0)
        for tag in script.hashtags:
            self.assertTrue(tag.startswith("#"))
        self.assertIn("#wissenschaft", script.hashtags)

    def test_generate_script_raises_on_too_short_content(self):
        """Regressionstest: ein zu kurzes/dünnes Skript darf NICHT akzeptiert werden -
        generate_script() muss eine ScriptQualityError werfen statt stillschweigend
        ein minderwertiges Video zu produzieren."""
        from app.script_generator import generate_script, ScriptQualityError
        from app.fact_checker import FactBase
        fb = FactBase(topic="Testthema", facts=["Kurz."], source_name="test", verified=False)
        with self.assertRaises(ScriptQualityError):
            generate_script("Testthema", fb)

    def test_generate_script_uses_full_fallback_on_partial_ollama_failure(self):
        """
        Regressionstest für einen echten Bug (Audit-Fund): schlägt NUR EINER der
        drei LLM-Aufrufe (Hook/Kontext/Outro) fehl (z.B. Timeout unter Last auf
        dem Pi), während die anderen beiden über Ollama erfolgreich sind, darf
        NICHT der generische, abschnitts-unspezifische Fallback-Text des
        fehlgeschlagenen Aufrufs unverändert als 'ollama-generiert' durchgehen.
        Stattdessen muss konsequent der geprüfte, differenzierte regelbasierte
        Aufbau für ALLE drei Abschnitte verwendet werden.
        """
        from unittest.mock import patch
        from app.script_generator import generate_script
        from app.fact_checker import FactBase

        fb = FactBase(
            topic="Testthema",
            facts=[
                "Erster ausführlicher Testfakt mit ausreichend viel Substanz und genügend Wörtern für die Mindestdauer.",
                "Zweiter ausführlicher Testfakt mit ebenfalls ausreichend viel Substanz und genügend Wörtern dabei.",
            ],
            source_name="test", verified=True,
        )

        # Simuliert: Hook-Aufruf schlägt auf Ollama fehl (Fallback-Text kommt zurück),
        # Kontext und Outro laufen erfolgreich über Ollama.
        def fake_generate(prompt, system=None, timeout=60):
            if "Hook)" in prompt:
                return "irgendein grob zusammengesetzter Fallback-Text mit vielen Fakten", "fallback_regelbasiert"
            return "Ein von Ollama formulierter Satz.", "ollama"

        with patch("app.script_generator.llm_provider.generate", side_effect=fake_generate):
            script = generate_script("Testthema", fb, category="Wissenschaft")

        self.assertEqual(script.llm_source, "fallback_regelbasiert")
        # Der Hook muss der geprüfte, kurze Standard-Hook sein - NICHT der lange,
        # unpassende Fallback-Text aus dem fehlgeschlagenen Einzelaufruf.
        self.assertEqual(script.hook, "Wusstest du das über Testthema?")


if __name__ == "__main__":
    unittest.main()
