"""
Tests für app.video und app.media - nutzen ECHTES FFmpeg (kein Mock), da FFmpeg
eine harte Voraussetzung des Produkts ist und lokal ohne Internet funktionieren muss.
"""
import sys
import os
import shutil
import unittest
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

FFMPEG_AVAILABLE = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


@unittest.skipUnless(FFMPEG_AVAILABLE, "FFmpeg/ffprobe nicht installiert - Video-Tests übersprungen")
class TestVideoPipeline(unittest.TestCase):
    def test_local_background_generation(self):
        from app.media import _generate_local_background
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "bg.mp4"
            _generate_local_background(out, duration_s=3.0, width=480, height=854)
            self.assertTrue(out.exists())
            self.assertGreater(out.stat().st_size, 1000)

    def test_pexels_falls_back_when_download_is_not_a_valid_video(self):
        """
        Regressionstest für einen echten Bug (Audit-Fund): ein 'erfolgreicher' HTTP-
        Download, der aber keine echte Videodatei enthält (z.B. eine Fehler-/Rate-
        Limit-Antwort als Bytes), durfte NICHT als gültiger Hintergrund akzeptiert
        werden - sonst wäre die komplette Pipeline beim späteren FFmpeg-Rendering
        abgestürzt, obwohl der lokale Fallback zuverlässig funktioniert.
        """
        from unittest.mock import patch, MagicMock
        from app import media
        from app.config import env as app_env

        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            original_key = app_env.pexels_api_key
            app_env.pexels_api_key = "fake-test-key"
            try:
                search_resp = MagicMock()
                search_resp.raise_for_status = lambda: None
                search_resp.json.return_value = {
                    "videos": [{"video_files": [{"link": "https://example.invalid/video.mp4", "width": 720, "height": 1280}]}]
                }
                broken_video_resp = MagicMock()
                broken_video_resp.raise_for_status = lambda: None
                broken_video_resp.content = b"NOT_A_REAL_VIDEO_JUST_AN_ERROR_PAGE" * 100

                def fake_get(url, **kwargs):
                    if "videos/search" in url:
                        return search_resp
                    return broken_video_resp

                with patch("app.media.requests.get", side_effect=fake_get):
                    result = media._try_pexels("Testthema", out_dir / "background_stock.mp4", 10.0)

                self.assertFalse(result, "Ein ungültiger Download durfte nicht als Erfolg gewertet werden")
                self.assertFalse((out_dir / "background_stock.mp4").exists(), "Ungültige Datei hätte aufgeräumt werden müssen")
            finally:
                app_env.pexels_api_key = original_key

    def test_get_background_video_falls_back_to_local_when_stock_invalid(self):
        """End-to-End: get_background_video() muss trotz eines ungültigen Pexels-
        Downloads einen funktionierenden lokalen Hintergrund liefern."""
        from unittest.mock import patch, MagicMock
        from app import media
        from app.config import env as app_env

        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            original_key = app_env.pexels_api_key
            app_env.pexels_api_key = "fake-test-key"
            try:
                broken_resp = MagicMock()
                broken_resp.raise_for_status = lambda: None
                broken_resp.json.return_value = {
                    "videos": [{"video_files": [{"link": "https://example.invalid/video.mp4", "width": 720, "height": 1280}]}]
                }
                broken_resp.content = b"KAPUTTER_INHALT" * 50

                with patch("app.media.requests.get", return_value=broken_resp):
                    path, source = media.get_background_video("Testthema", 6.0, out_dir)

                self.assertEqual(source, "lokal_generiert")
                self.assertTrue(path.exists())
                self.assertGreater(path.stat().st_size, 1000)
            finally:
                app_env.pexels_api_key = original_key

    def test_full_video_build_and_qc_pass(self):
        """Baut ein komplettes kleines Testvideo (Hintergrund + Stille-Audio + Untertitel)
        und prüft es mit der echten quality_check()-Funktion via ffprobe."""
        from app import media, subtitles, video
        from app.providers import tts_provider

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            duration = 16.0

            audio_path = tmp_path / "audio.wav"
            tts_provider._write_silence_wav(audio_path, duration_s=duration)

            bg_path, source = media.get_background_video("Testthema", duration, tmp_path)
            self.assertTrue(bg_path.exists())

            ass_path = tmp_path / "subs.ass"
            subtitles.generate_ass("Dies ist ein Testsatz für das Testvideo.", duration, ass_path,
                                    video_width=480, video_height=854)

            out_video = tmp_path / "final.mp4"
            # Kleinere Testauflösung für Geschwindigkeit - Zielauflösung wird separat
            # im echten End-to-End-Testlauf (siehe README/Entwicklungsdoku) mit 1080x1920 geprüft.
            original_w, original_h = video.TARGET_WIDTH, video.TARGET_HEIGHT
            video.TARGET_WIDTH, video.TARGET_HEIGHT = 480, 854
            try:
                video.build_video(bg_path, audio_path, ass_path, out_video, duration)
                self.assertTrue(out_video.exists())

                qc = video.quality_check(out_video, expected_min_s=10.0, expected_max_s=30.0)
                self.assertTrue(qc.has_video)
                self.assertTrue(qc.has_audio)
                self.assertEqual((qc.width, qc.height), (480, 854))
            finally:
                video.TARGET_WIDTH, video.TARGET_HEIGHT = original_w, original_h

    def test_quality_check_fails_on_missing_file(self):
        from app import video
        qc = video.quality_check(Path("/nonexistent/video.mp4"))
        self.assertFalse(qc.passed)
        self.assertIn("existiert nicht", qc.reasons[0])

    def test_quality_check_fails_on_too_short_video(self):
        from app import media, video
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            bg = tmp_path / "short.mp4"
            media._generate_local_background(bg, duration_s=2.0, width=480, height=854)
            qc = video.quality_check(bg, expected_min_s=15.0, expected_max_s=60.0)
            self.assertFalse(qc.passed)


if __name__ == "__main__":
    unittest.main()
