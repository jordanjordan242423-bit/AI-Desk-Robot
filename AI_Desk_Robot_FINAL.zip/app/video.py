"""
Video-Erstellung (Master-Prompt Abschnitt 13 + 14 + 17).

Baut aus Hintergrundclip + TTS-Audio + Untertiteln ein fertiges, TikTok-optimiertes
Video: 1080x1920 (9:16), H.264, AAC, passende FPS, eingebrannte Untertitel.

Danach automatische Qualitätsprüfung per ffprobe (Abschnitt 17):
Datei existiert, lesbar, korrekte Auflösung/Dauer, Audio+Video-Stream vorhanden,
Dateigröße plausibel.
"""
from __future__ import annotations
import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from .subtitles import ass_subtitle_filter
from .logging_setup import logger

TARGET_WIDTH = 1080
TARGET_HEIGHT = 1920
TARGET_FPS = 30


class VideoBuildError(Exception):
    pass


def build_video(background_path: Path, audio_path: Path, ass_path: Path, out_path: Path, duration_s: float) -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    subtitle_filter = ass_subtitle_filter(ass_path)

    vf = (
        f"scale={TARGET_WIDTH}:{TARGET_HEIGHT}:force_original_aspect_ratio=increase,"
        f"crop={TARGET_WIDTH}:{TARGET_HEIGHT},"
        f"{subtitle_filter},"
        f"format=yuv420p"
    )

    cmd = [
        "ffmpeg", "-y",
        "-stream_loop", "-1", "-i", str(background_path),
        "-i", str(audio_path),
        "-t", str(duration_s),
        "-vf", vf,
        "-r", str(TARGET_FPS),
        "-c:v", "libx264", "-preset", "medium", "-crf", "21",
        "-c:a", "aac", "-b:a", "160k",
        "-map", "0:v:0", "-map", "1:a:0",
        "-shortest",
        str(out_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, timeout=600)
    if proc.returncode != 0 or not out_path.exists():
        raise VideoBuildError(f"FFmpeg-Fehler beim Videobau: {proc.stderr.decode('utf-8', 'ignore')[-800:]}")
    return out_path


@dataclass
class QCResult:
    passed: bool
    reasons: list
    duration_s: float = 0.0
    width: int = 0
    height: int = 0
    has_audio: bool = False
    has_video: bool = False
    filesize_bytes: int = 0


def quality_check(video_path: Path, expected_min_s: float = 15.0, expected_max_s: float = 90.0) -> QCResult:
    reasons = []
    if not video_path.exists():
        return QCResult(passed=False, reasons=["Datei existiert nicht"])

    filesize = video_path.stat().st_size
    if filesize < 20_000:
        reasons.append(f"Dateigröße unplausibel klein ({filesize} Bytes)")

    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(video_path)],
            capture_output=True, timeout=30,
        )
        if probe.returncode != 0:
            return QCResult(passed=False, reasons=[f"ffprobe-Fehler: {probe.stderr.decode('utf-8','ignore')[:300]}"],
                             filesize_bytes=filesize)
        info = json.loads(probe.stdout)
    except Exception as exc:
        return QCResult(passed=False, reasons=[f"Video nicht lesbar/beschädigt: {exc}"], filesize_bytes=filesize)

    streams = info.get("streams", [])
    video_streams = [s for s in streams if s.get("codec_type") == "video"]
    audio_streams = [s for s in streams if s.get("codec_type") == "audio"]
    has_video = len(video_streams) > 0
    has_audio = len(audio_streams) > 0

    if not has_video:
        reasons.append("Kein Video-Stream gefunden")
    if not has_audio:
        reasons.append("Kein Audio-Stream gefunden")

    width = video_streams[0].get("width", 0) if video_streams else 0
    height = video_streams[0].get("height", 0) if video_streams else 0
    if (width, height) != (TARGET_WIDTH, TARGET_HEIGHT):
        reasons.append(f"Unerwartete Auflösung: {width}x{height} statt {TARGET_WIDTH}x{TARGET_HEIGHT}")

    duration = float(info.get("format", {}).get("duration", 0.0))
    if duration < expected_min_s:
        reasons.append(f"Video zu kurz ({duration:.1f}s < {expected_min_s}s)")
    if duration > expected_max_s + 15:
        reasons.append(f"Video deutlich zu lang ({duration:.1f}s)")

    if has_audio:
        # leere/stille Audiodatei grob erkennen: sehr geringe Bitrate deutet auf Problem hin
        abr = audio_streams[0].get("bit_rate")
        if abr and int(abr) < 4000:
            reasons.append("Audiospur wirkt verdächtig leise/leer")

    passed = len(reasons) == 0
    return QCResult(
        passed=passed, reasons=reasons, duration_s=duration, width=width, height=height,
        has_audio=has_audio, has_video=has_video, filesize_bytes=filesize,
    )
