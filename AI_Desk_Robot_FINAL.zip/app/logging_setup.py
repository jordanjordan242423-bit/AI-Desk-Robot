"""
Logging-Setup.

Ziele:
- verständliche, kurze Logzeilen (siehe Master-Prompt Abschnitt 28)
- Datei-Logs mit Rotation (damit die SD-Karte nicht vollläuft)
- In-Memory-Ringpuffer, den das Dashboard per API abfragen kann (keine Log-Datei-Parserei im Frontend)
- Keine Secrets werden geloggt (Filter auf bekannte Schlüsselnamen)
"""
from __future__ import annotations
import logging
import logging.handlers
import re
import threading
from collections import deque
from datetime import datetime
from .config import LOG_DIR

_SECRET_PATTERNS = [
    re.compile(r"(api[_-]?key)\s*[=:]\s*\S+", re.IGNORECASE),
    re.compile(r"(client[_-]?secret)\s*[=:]\s*\S+", re.IGNORECASE),
    re.compile(r"(token)\s*[=:]\s*\S+", re.IGNORECASE),
    re.compile(r"(password)\s*[=:]\s*\S+", re.IGNORECASE),
]


def _redact(msg: str) -> str:
    for pat in _SECRET_PATTERNS:
        msg = pat.sub(r"\1=***REDACTED***", msg)
    return msg


class RingBufferHandler(logging.Handler):
    """Hält die letzten N Logzeilen im Speicher für die Dashboard-Logansicht."""

    def __init__(self, capacity: int = 500):
        super().__init__()
        self.buffer = deque(maxlen=capacity)
        self._lock = threading.Lock()

    def emit(self, record: logging.LogRecord):
        try:
            msg = _redact(self.format(record))
            with self._lock:
                self.buffer.append({
                    "time": datetime.fromtimestamp(record.created).strftime("%H:%M:%S"),
                    "level": record.levelname,
                    "message": msg,
                })
        except Exception:
            pass

    def get_recent(self, limit: int = 200):
        with self._lock:
            items = list(self.buffer)[-limit:]
        return items


ring_handler = RingBufferHandler(capacity=1000)


class RedactingFormatter(logging.Formatter):
    def format(self, record):
        original = super().format(record)
        return _redact(original)


def setup_logging(name: str = "ai_desk_robot") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # bereits initialisiert

    logger.setLevel(logging.INFO)
    fmt = RedactingFormatter("[%(asctime)s] %(message)s", datefmt="%H:%M:%S")

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logger.addHandler(console)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_DIR / "ai_desk_robot.log", maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    ring_handler.setFormatter(fmt)
    logger.addHandler(ring_handler)

    logger.propagate = False
    return logger


logger = setup_logging()
