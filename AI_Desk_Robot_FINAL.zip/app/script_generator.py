"""
Skripterstellung (Master-Prompt Abschnitt 14 + 42).

Struktur: HOOK -> KONTEXT -> FAKT 1..N -> SCHLUSS, ca. 30-60 Sekunden gesprochen.
Nutzt das LLM (Ollama) um die Fakten in einen packenden, deutschen TikTok-Skript-Ton
zu bringen; fällt bei LLM-Ausfall auf einen regelbasierten Aufbau zurück, der die
geprüften Fakten direkt verwendet (siehe llm_provider.generate).

Danach: eine ECHTE Skript-Qualitätsprüfung (Länge, Wiederholungsgrad, faktischer
Gehalt). Schlägt sie fehl, wird KEIN Ersatzinhalt gebaut und auch nicht einfach mit
einer Log-Warnung weitergemacht - stattdessen wirft generate_script() eine
ScriptQualityError. Der Aufrufer (app.topic_selector.select_topic_with_facts_and_script)
verwirft das Thema dann vollständig und versucht den nächsten Kandidaten.

Danach automatische Generierung von Titel, Beschreibung und Hashtags für TikTok.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import List
from .fact_checker import FactBase
from .providers import llm_provider
from .logging_setup import logger

# ca. 2.3 Wörter/Sekunde ist ein realistischer Wert für ruhig gesprochenes Deutsch
_WORDS_PER_SECOND = 2.3

# Harte Qualitätsschwellen (siehe _validate_script)
_MIN_DURATION_S = 12.0
_MIN_UNIQUE_WORD_RATIO = 0.40
_MIN_FACT_CONTENT_CHARS = 40


class ScriptQualityError(Exception):
    """Wird geworfen, wenn ein generiertes Skript die Mindestqualität nicht erreicht
    (zu kurz, zu repetitiv, oder faktisch zu dünn). Der Aufrufer verwirft daraufhin
    das Thema und versucht einen anderen Kandidaten - es wird NIEMALS ein
    minderwertiges Skript einfach durchgewunken."""
    pass


@dataclass
class VideoScript:
    hook: str
    context: str
    facts: List[str]
    outro: str
    full_text: str
    estimated_duration_s: float
    llm_source: str
    title: str = ""
    description: str = ""
    hashtags: List[str] = field(default_factory=list)


_SYSTEM_PROMPT = (
    "Du schreibst kurze, deutsche TikTok-Wissensvideo-Skripte. "
    "Stil: locker, verständlich, spannend, aber sachlich korrekt. "
    "Erfinde NIEMALS Zahlen oder Fakten, die nicht gegeben sind. "
    "Antworte NUR mit dem gesprochenen Text, ohne Regieanweisungen, ohne Emojis, ohne Anführungszeichen."
)

# Bekannte Kategorie -> Hashtag-Zuordnung (nutzt die ECHTE Themenkategorie, nicht den Titel)
_CATEGORY_TAGS = {
    "Weltraum": ["weltraum", "astronomie", "space"],
    "Technik": ["technik", "tech"],
    "Wissenschaft": ["wissenschaft", "science"],
    "Natur": ["natur", "nature"],
    "Geschichte": ["geschichte", "history"],
    "kuriose Fakten": ["fakten", "kurios"],
    "Tiere": ["tiere", "animals"],
    "Psychologie": ["psychologie", "mindset"],
    "Alltagsfakten": ["alltagsfakten", "wusstestduschon"],
    "Forschung": ["forschung", "wissenschaft"],
    "Erfindungen": ["erfindungen", "geschichte"],
    "Energie": ["energie", "technik"],
    "Computer": ["computer", "technik"],
    "KI": ["ki", "ai", "technik"],
    "Astronomie": ["astronomie", "weltraum"],
    "Geografie": ["geografie", "erde"],
    "außergewöhnliche Ereignisse": ["ungewöhnlich", "geschichte"],
}


def _build_prompt(topic: str, facts: List[str], section: str) -> str:
    facts_block = "\n".join(f"- {f}" for f in facts)
    instructions = {
        "hook": (
            f"Thema: {topic}\nGeprüfte Fakten:\n{facts_block}\n\n"
            "Schreibe EINEN einzigen, sehr knackigen Satz (Hook) für den Anfang eines TikTok-Videos "
            "zu diesem Thema, der sofort Neugier weckt. Maximal 15 Wörter."
        ),
        "context": (
            f"Thema: {topic}\nGeprüfte Fakten:\n{facts_block}\n\n"
            "Schreibe 1-2 kurze Sätze, die kurz erklären, worum es geht (Kontext). Maximal 30 Wörter."
        ),
        "outro": (
            f"Thema: {topic}\nGeprüfte Fakten:\n{facts_block}\n\n"
            "Schreibe einen kurzen, runden Schlusssatz für das Video. Maximal 20 Wörter."
        ),
    }
    return instructions[section]


def _clean(text: str) -> str:
    text = text.strip().strip('"').strip("'")
    text = re.sub(r"\s+", " ", text)
    # Regieanweisungen wie [Hook] oder (lächelnd) entfernen
    text = re.sub(r"\[[^\]]*\]|\([^)]*\)", "", text).strip()
    return text


def generate_script(topic: str, fact_base: FactBase, category: str = "") -> VideoScript:
    facts = fact_base.facts[:5]

    hook_raw, src1 = llm_provider.generate(_build_prompt(topic, facts, "hook"), system=_SYSTEM_PROMPT, timeout=60)
    context_raw, src2 = llm_provider.generate(_build_prompt(topic, facts, "context"), system=_SYSTEM_PROMPT, timeout=60)
    outro_raw, src3 = llm_provider.generate(_build_prompt(topic, facts, "outro"), system=_SYSTEM_PROMPT, timeout=60)

    # WICHTIG (echter Bug, per Audit gefunden): Es reicht NICHT, dass IRGENDEINER der
    # drei Aufrufe über Ollama erfolgreich war. Bei einem teilweisen Ausfall (z.B. ein
    # einzelner Ollama-Aufruf läuft auf einem ausgelasteten Raspberry Pi in ein Timeout,
    # während die anderen beiden durchgehen) würde sonst der generische, nicht
    # abschnittsspezifische Fallback-Text (aus llm_provider._fallback_text, der nur
    # grob alle Fakten aneinanderreiht) unverändert als vermeintlich vollwertiger
    # LLM-Hook/-Kontext/-Outro übernommen - das ergäbe einen unpassenden, evtl. viel
    # zu langen "Hook". Nur wenn ALLE DREI Aufrufe über Ollama liefen, gilt die
    # Quelle als 'ollama'; sonst wird konsequent der geprüfte, differenzierte
    # regelbasierte Aufbau für ALLE drei Abschnitte verwendet.
    llm_source = "ollama" if src1 == src2 == src3 == "ollama" else "fallback_regelbasiert"

    if llm_source == "fallback_regelbasiert":
        # Kein LLM verfügbar: statt dreimal denselben generischen Text zu verwenden
        # (das würde sich im Video repetitiv/unnatürlich anhören), wird hier direkt aus
        # den geprüften Fakten ein differenzierter Hook/Kontext/Outro gebaut - jeder
        # Abschnitt bekommt einen eigenen, unterschiedlichen Satz.
        hook = f"Wusstest du das über {topic}?"
        context = _clean(facts[0]) if facts else f"Heute geht es um {topic}."
        outro = "Ziemlich spannend, oder?"
        if len(facts) > 1:
            fact_sentences = [_clean(f) for f in facts[1:]]
        else:
            fact_sentences = []
    else:
        hook = _clean(hook_raw) or f"Wusstest du das über {topic}?"
        context = _clean(context_raw) or f"Heute geht es um {topic}."
        outro = _clean(outro_raw) or "Verrückt, oder?"
        fact_sentences = [_clean(f) for f in facts]

    full_text = " ".join([hook, context] + fact_sentences + [outro])
    word_count = len(full_text.split())
    duration = round(word_count / _WORDS_PER_SECOND, 1)

    script = VideoScript(
        hook=hook, context=context, facts=fact_sentences, outro=outro,
        full_text=full_text, estimated_duration_s=duration, llm_source=llm_source,
    )
    _generate_metadata(script, topic, category)
    _validate_script(script, fact_base)
    return script


def _generate_metadata(script: VideoScript, topic: str, category: str):
    script.title = script.hook[:70] if script.hook else topic[:70]

    desc = script.context
    if len(desc) > 150:
        desc = desc[:147] + "..."
    script.description = desc

    base_tags = ["wissen", "fakten"]
    extra = _CATEGORY_TAGS.get(category, []) or ["wissenswert"]
    tags = list(dict.fromkeys(base_tags + extra))[:5]
    script.hashtags = [f"#{t}" for t in tags]


def _validate_script(script: VideoScript, fact_base: FactBase):
    """
    ECHTE Skript-Qualitätsprüfung. Wirft ScriptQualityError bei Hart-Kriterien,
    statt nur zu loggen - ein minderwertiges Skript wird NIEMALS akzeptiert.
    """
    if script.estimated_duration_s < _MIN_DURATION_S:
        raise ScriptQualityError(
            f"Skript zu kurz ({script.estimated_duration_s:.1f}s < {_MIN_DURATION_S}s Minimum)."
        )

    words = script.full_text.lower().split()
    if words:
        unique_ratio = len(set(words)) / len(words)
        if unique_ratio < _MIN_UNIQUE_WORD_RATIO:
            raise ScriptQualityError(
                f"Skript zu repetitiv (nur {unique_ratio:.0%} eindeutige Wörter, "
                f"Minimum {_MIN_UNIQUE_WORD_RATIO:.0%})."
            )

    # Faktischer Gehalt: im regelbasierten Fallback-Pfad ist der Kontext-Satz selbst
    # ein echter, aus der Quelle stammender Fakt (siehe generate_script) - daher zählt
    # er hier mit, damit auch Themen mit nur einem einzigen, aber echten Fakt nicht
    # fälschlich als 'zu dünn' verworfen werden.
    fact_content_chars = len(script.context) + sum(len(f) for f in script.facts)
    if fact_content_chars < _MIN_FACT_CONTENT_CHARS:
        raise ScriptQualityError(
            f"Skript faktisch zu dünn (nur {fact_content_chars} Zeichen an Faktinhalt, "
            f"Minimum {_MIN_FACT_CONTENT_CHARS})."
        )

    if script.estimated_duration_s > 100:
        logger.info("Skript ist recht lang - wird beim Rendern ggf. leicht schneller gesprochen wirken (kein Hart-Kriterium).")
