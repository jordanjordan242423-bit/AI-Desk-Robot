"""
Manueller Upload-Fallback-Server (Master-Prompt Abschnitt 19).

Läuft auf einem eigenen Port (Standard 8765), damit er unabhängig vom
Haupt-Dashboard vom Handy aus erreichbar ist (z.B. über QR-Code gescannt).

Zeigt fertige Videos (Status READY oder PUBLISHED) mit Titel, Beschreibung,
Hashtags und Download-Button - so kann das Video bequem vom Handy geöffnet
und manuell bei TikTok hochgeladen werden, falls die offizielle API nicht
eingerichtet ist oder ein automatischer Upload fehlgeschlagen ist.
"""
from __future__ import annotations
from pathlib import Path
from flask import Flask, render_template, send_file, abort, jsonify

from .. import database
from ..config import BASE_DIR

upload_app = Flask(
    "ai_desk_robot_upload",
    template_folder=str(BASE_DIR / "templates"),
    static_folder=str(BASE_DIR / "static"),
)


@upload_app.route("/upload")
def upload_index():
    jobs = database.list_jobs(limit=50)
    ready_jobs = [j for j in jobs if j.get("status") in ("READY", "PUBLISHED") and j.get("video_file")]
    return render_template("upload.html", jobs=ready_jobs)


@upload_app.route("/upload/stream/<job_id>")
def upload_stream(job_id):
    """Inline-Wiedergabe (kein 'attachment') für das <video>-Element auf der
    mobilen Einzelvideo-Seite - getrennt von /upload/video/<job_id>, das für
    den expliziten Download-Button gedacht ist."""
    job = database.get_job(job_id)
    if not job or not job.get("video_file"):
        abort(404)
    path = Path(job["video_file"])
    if not path.exists():
        abort(404)
    return send_file(path, mimetype="video/mp4")


@upload_app.route("/upload/video/<job_id>")
def upload_video_file(job_id):
    job = database.get_job(job_id)
    if not job or not job.get("video_file"):
        abort(404)
    path = Path(job["video_file"])
    if not path.exists():
        abort(404)
    filename = f"{job.get('title') or job_id}.mp4".replace("/", "-")
    return send_file(path, mimetype="video/mp4", as_attachment=True, download_name=filename)


@upload_app.route("/upload/<job_id>")
def upload_single(job_id):
    """
    Mobile Einzelvideo-Seite für ein bestimmtes Video (verlinkt über den
    job-spezifischen QR-Code von der 'Manuell auf TikTok hochladen'-Seite im
    Haupt-Dashboard). Zeigt direkt dieses eine Video mit Vorschau, Titel,
    Beschreibung und Download-Button - ohne erst durch die Gesamtliste
    scrollen zu müssen.
    """
    job = database.get_job(job_id)
    if not job or not job.get("video_file") or not Path(job["video_file"]).exists():
        abort(404)
    return render_template("upload_single.html", job=job)


@upload_app.route("/upload/api/jobs")
def upload_api_jobs():
    jobs = database.list_jobs(limit=50)
    ready_jobs = [j for j in jobs if j.get("status") in ("READY", "PUBLISHED") and j.get("video_file")]
    return jsonify(ready_jobs)
