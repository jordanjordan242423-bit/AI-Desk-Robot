"""
Flask-Routen für das Hauptdashboard (Port siehe FLASK_PORT, Standard 8080).

Das Frontend ist eine Single-Page-Oberfläche (kein Reload zwischen Ansichten,
wichtig für den Kiosk-Betrieb auf dem 7-Zoll-Touchscreen). Alle Ansichten
(Hauptansicht, TikTok, Statistik, Videos, Logs, Einstellungen, System) liegen
in einem HTML-Dokument und werden per JavaScript ein-/ausgeblendet.

Diese Datei stellt ausschließlich JSON-APIs + die Auslieferung von Medien/QR bereit.
"""
from __future__ import annotations
import uuid
from pathlib import Path
from flask import Blueprint, jsonify, request, render_template, send_file, abort, Response

from .. import database, system, agent, scheduler, tiktok
from ..config import config, env, VIDEOS_DIR
from ..providers import weather_provider
from ..logging_setup import ring_handler, logger
from ..services import qrcode_gen

bp = Blueprint("main", __name__)

_tiktok_oauth_state = {"value": ""}


@bp.route("/")
def dashboard():
    return render_template("dashboard.html")


# ---------------------------------------------------------------------------
# Status / Agent / System
# ---------------------------------------------------------------------------
@bp.route("/api/status")
def api_status():
    return jsonify({
        "system": system.full_status(),
        "weather": weather_provider.get_weather(),
        "agent": agent.get_agent_snapshot(),
        "stats": database.stats_summary(),
        "tiktok_configured": tiktok.is_configured(),
        "tiktok_connected": tiktok.is_connected(),
    })


@bp.route("/api/agent/run-now", methods=["POST"])
def api_agent_run_now():
    started = scheduler.trigger_manual_run()
    return jsonify({"started": started})


# ---------------------------------------------------------------------------
# Jobs / Videos
# ---------------------------------------------------------------------------
@bp.route("/api/jobs")
def api_jobs():
    status_filter = request.args.get("status")
    limit = int(request.args.get("limit", 100))
    return jsonify(database.list_jobs(limit=limit, status=status_filter))


@bp.route("/api/jobs/<job_id>")
def api_job_detail(job_id):
    job = database.get_job(job_id)
    if not job:
        abort(404)
    return jsonify(job)


@bp.route("/media/video/<job_id>")
def media_video(job_id):
    job = database.get_job(job_id)
    if not job or not job.get("video_file"):
        abort(404)
    path = Path(job["video_file"])
    if not path.exists():
        abort(404)
    return send_file(path, mimetype="video/mp4")


@bp.route("/media/download/<job_id>")
def media_download(job_id):
    """Wie /media/video/<job_id>, aber als Download (Content-Disposition: attachment)
    mit sprechendem Dateinamen - für den 'Video herunterladen'-Button der manuellen
    TikTok-Upload-Seite."""
    job = database.get_job(job_id)
    if not job or not job.get("video_file"):
        abort(404)
    path = Path(job["video_file"])
    if not path.exists():
        abort(404)
    filename = f"{(job.get('title') or job_id)}.mp4".replace("/", "-")
    return send_file(path, mimetype="video/mp4", as_attachment=True, download_name=filename)


# ---------------------------------------------------------------------------
# Statistik
# ---------------------------------------------------------------------------
@bp.route("/api/stats")
def api_stats():
    return jsonify(database.stats_summary())


# ---------------------------------------------------------------------------
# Logs
# ---------------------------------------------------------------------------
@bp.route("/api/logs")
def api_logs():
    limit = int(request.args.get("limit", 200))
    return jsonify(ring_handler.get_recent(limit=limit))


@bp.route("/api/events")
def api_events():
    limit = int(request.args.get("limit", 100))
    return jsonify(database.recent_events(limit=limit))


# ---------------------------------------------------------------------------
# Einstellungen
# ---------------------------------------------------------------------------
# WICHTIG (echter Bug, per Audit gefunden): /api/settings (POST) persistierte
# vorher JEDEN vom Client gesendeten Schlüssel/Wert ungeprüft direkt nach
# config.yaml. Ein ungültiger Wert (z.B. 'null' durch einen leeren Zahlen-Input
# im Browser, der als JSON 'null' serialisiert wird) für 'videos_per_day' hätte
# beim nächsten Scheduler-Durchlauf zu einem TypeError geführt ('>=' zwischen
# int und None) - der Scheduler hätte das zwar abgefangen und weiterlaufen
# lassen, aber die autonome Video-Erstellung wäre dauerhaft (bis zur manuellen
# Korrektur der config.yaml) lahmgelegt gewesen, ohne dass das im Dashboard
# sichtbar geworden wäre. Diese Validierung verhindert das.
_SETTINGS_VALIDATORS = {
    "videos_per_day": lambda v: isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 10,
    "min_hours_between_videos": lambda v: isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 24,
}


@bp.route("/api/settings", methods=["GET"])
def api_settings_get():
    return jsonify(config.as_dict())


@bp.route("/api/settings", methods=["POST"])
def api_settings_post():
    payload = request.get_json(force=True, silent=True) or {}
    rejected = {}
    for key, value in payload.items():
        validator = _SETTINGS_VALIDATORS.get(key)
        if validator is None:
            rejected[key] = "unbekannter oder nicht änderbarer Schlüssel"
            logger.info(f"Einstellungen: unbekannter Schlüssel '{key}' abgelehnt")
            continue
        if not validator(value):
            rejected[key] = "ungültiger Wert"
            logger.info(f"Einstellungen: ungültiger Wert für '{key}' abgelehnt: {value!r}")
            continue
        config.set(key, value)
    logger.info("Einstellungen aktualisiert")
    response = {"saved": True, "settings": config.as_dict()}
    if rejected:
        response["rejected"] = rejected
    return jsonify(response)


# ---------------------------------------------------------------------------
# TikTok OAuth
# ---------------------------------------------------------------------------
@bp.route("/tiktok/connect")
def tiktok_connect():
    if not tiktok.is_configured():
        return render_template("tiktok_not_configured.html")
    state = uuid.uuid4().hex
    _tiktok_oauth_state["value"] = state
    url = tiktok.build_authorize_url(state)
    return f'<html><head><meta http-equiv="refresh" content="0; url={url}"></head></html>'


@bp.route("/tiktok/callback")
def tiktok_callback():
    code = request.args.get("code")
    state = request.args.get("state")
    if not code or state != _tiktok_oauth_state["value"]:
        return render_template("tiktok_error.html", error="Ungültiger oder abgelaufener Autorisierungscode.")
    try:
        tiktok.exchange_code_for_token(code)
        return render_template("tiktok_success.html")
    except Exception as exc:
        return render_template("tiktok_error.html", error=str(exc))


@bp.route("/api/tiktok/disconnect", methods=["POST"])
def api_tiktok_disconnect():
    tiktok.disconnect()
    return jsonify({"disconnected": True})


# ---------------------------------------------------------------------------
# Manueller TikTok-Upload-Fallback (Punkt: Video darf niemals verloren gehen)
# ---------------------------------------------------------------------------
@bp.route("/tiktok/manual/<job_id>")
def tiktok_manual_upload(job_id):
    """
    Dedizierte Seite für den manuellen TikTok-Upload-Fallback: erscheint, wenn
    der automatische Upload nicht möglich war (TikTok nicht verbunden) oder
    fehlgeschlagen ist. Das fertige Video geht dabei NIE verloren - diese Seite
    zeigt es direkt mit Titel/Beschreibung/Hashtags und bietet Vorschau,
    Download sowie einen QR-Code zum Öffnen auf dem Handy.
    """
    job = database.get_job(job_id)
    if not job or not job.get("video_file") or not Path(job["video_file"]).exists():
        abort(404)
    upload_port = config.get("upload_server.port", env.upload_port)
    host = request.host.split(":")[0]
    mobile_url = f"http://{host}:{upload_port}/upload/{job_id}"
    return render_template("tiktok_manual_upload.html", job=job, mobile_url=mobile_url)


# ---------------------------------------------------------------------------
# QR-Code für den manuellen Upload-Server
# ---------------------------------------------------------------------------
@bp.route("/api/upload-qr/<job_id>.png")
def api_upload_qr_job(job_id):
    """QR-Code, der direkt auf die mobile Einzelvideo-Seite für dieses Video zeigt
    (statt nur auf die allgemeine Upload-Übersicht)."""
    upload_port = config.get("upload_server.port", env.upload_port)
    host = request.host.split(":")[0]
    url = f"http://{host}:{upload_port}/upload/{job_id}"
    png_bytes = qrcode_gen.generate_qr_png(url, module_px=6, border=3)
    return Response(png_bytes, mimetype="image/png")


@bp.route("/api/upload-qr.png")
def api_upload_qr():
    upload_port = config.get("upload_server.port", env.upload_port)
    host = request.host.split(":")[0]
    url = f"http://{host}:{upload_port}/upload"
    png_bytes = qrcode_gen.generate_qr_png(url, module_px=6, border=3)
    return Response(png_bytes, mimetype="image/png")


@bp.route("/api/upload-url")
def api_upload_url():
    upload_port = config.get("upload_server.port", env.upload_port)
    host = request.host.split(":")[0]
    return jsonify({"url": f"http://{host}:{upload_port}/upload"})
