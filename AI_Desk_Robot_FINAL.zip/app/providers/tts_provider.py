"""
TTS-Anbindung (Master-Prompt Abschnitt 12).

Priorität:
1. Piper (lokal, kostenlos, gute deutsche Stimmen wie de_DE-thorsten-medium)
2. espeak-ng (lokal, kostenlos, auf praktisch jedem Linux/Raspberry Pi vorinstallierbar,
   klingt robotischer, funktioniert aber garantiert offline ohne Zusatz-Download)
3. Schlagen BEIDE fehl (oder liefern nur stumme Ausgabe): synthesize() wirft eine
   TTSError. Es gibt KEINEN dritten 'stillen Notfall-Erfolg' mehr - der Agent
   markiert den Job dann korrekt als FAILED, statt ein Video mit stummer
   Tonspur als READY/uploadbereit zu behandeln.

Keine kostenpflichtige TTS-API ist Pflicht.
"""
from __future__ import annotations
import shutil
import subprocess
import wave
import struct
import math
from pathlib import Path
from ..config import env
from ..logging_setup import logger


class TTSError(Exception):
    pass


def piper_available() -> bool:
    return shutil.which(env.piper_bin) is not None and bool(env.piper_voice_path) and Path(env.piper_voice_path).exists()


def espeak_available() -> bool:
    return shutil.which("espeak-ng") is not None or shutil.which("espeak") is not None


def _wav_is_effectively_silent(path: Path, rms_threshold: float = 60.0, max_analyze_seconds: float = 20.0) -> bool:
    """
    Prüft, ob eine WAV-Datei praktisch nur Stille enthält (sehr niedrige RMS-Amplitude).

    Hintergrund: Piper/espeak-ng können mit Exit-Code 0 eine technisch gültige,
    aber PRAKTISCH STUMME Datei erzeugen (z.B. bei einem beschädigten/fehlenden
    Stimmmodell, falscher Sprache oder einem stillen Rendering-Bug). Ohne diese
    Prüfung würde ein solcher Fall fälschlich als 'engine=piper'/'engine=espeak'
    (also als echter TTS-Erfolg) durchgewunken - genau das darf laut Vorgabe
    NIEMALS passieren. Diese Funktion erzwingt: nur echte, hörbare Sprachausgabe
    zählt als Erfolg: alles andere führt zu einem TTSError, der die Engine
    zur nächsten Fallback-Stufe (oder ganz zum Abbruch) weiterreicht.
    """
    try:
        with wave.open(str(path), "rb") as wf:
            sampwidth = wf.getsampwidth()
            framerate = wf.getframerate() or 22050
            n_frames = wf.getnframes()
            if n_frames == 0:
                return True
            frames_to_read = min(n_frames, int(framerate * max_analyze_seconds))
            raw = wf.readframes(frames_to_read)

        if sampwidth != 2:
            # Nur 16-bit-PCM wird analysiert (das erzeugen sowohl Piper als auch
            # espeak-ng standardmäßig); bei anderen Formaten wird nicht blockiert,
            # um keine falschen Fehlalarme bei exotischen Ausgabeformaten zu riskieren.
            return False

        count = len(raw) // 2
        if count == 0:
            return True
        samples = struct.unpack(f"<{count}h", raw)
        mean_square = sum(s * s for s in samples) / count
        rms = math.sqrt(mean_square)
        return rms < rms_threshold
    except Exception:
        # Bei Unsicherheit (z.B. exotisches/fehlerhaftes WAV) lieber nicht blockieren -
        # der nachgelagerte video.quality_check() per ffprobe fängt echte Defekte ohnehin ab.
        return False


def _run_piper(text: str, out_path: Path) -> None:
    cmd = [env.piper_bin, "--model", env.piper_voice_path, "--output_file", str(out_path)]
    proc = subprocess.run(cmd, input=text.encode("utf-8"), capture_output=True, timeout=180)
    if proc.returncode != 0 or not out_path.exists() or out_path.stat().st_size == 0:
        raise TTSError(f"Piper-Fehler (Code {proc.returncode}): {proc.stderr.decode('utf-8', 'ignore')[:300]}")
    if _wav_is_effectively_silent(out_path):
        raise TTSError(
            "Piper hat eine technisch gültige, aber praktisch stumme Audiodatei erzeugt "
            "(vermutlich fehlerhaftes/fehlendes Stimmmodell). Wird NICHT als Erfolg akzeptiert."
        )


def _run_espeak(text: str, out_path: Path) -> None:
    binary = shutil.which("espeak-ng") or shutil.which("espeak")
    if not binary:
        raise TTSError("espeak-ng/espeak nicht installiert.")
    cmd = [binary, "-v", "de", "-s", "165", "-w", str(out_path), text]
    proc = subprocess.run(cmd, capture_output=True, timeout=120)
    if proc.returncode != 0 or not out_path.exists() or out_path.stat().st_size == 0:
        raise TTSError(f"espeak-Fehler (Code {proc.returncode}): {proc.stderr.decode('utf-8', 'ignore')[:300]}")
    if _wav_is_effectively_silent(out_path):
        raise TTSError(
            "espeak-ng hat eine technisch gültige, aber praktisch stumme Audiodatei erzeugt. "
            "Wird NICHT als Erfolg akzeptiert."
        )


def _write_silence_wav(out_path: Path, duration_s: float = 3.0, sample_rate: int = 22050) -> None:
    """
    Erzeugt eine stille WAV-Datei.

    WICHTIG: Diese Funktion wird von synthesize() NICHT MEHR automatisch als
    'Notfall-Erfolg' verwendet (siehe Änderungshistorie: eine stille Datei darf
    niemals stillschweigend als erfolgreiche TTS-Ausgabe durchgehen). Sie bleibt
    als kleine Hilfsfunktion für Tests erhalten, die gezielt eine stille Datei
    erzeugen wollen (z.B. um video.quality_check() oder _wav_is_effectively_silent()
    zu testen).
    """
    n_samples = int(duration_s * sample_rate)
    with wave.open(str(out_path), "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        silence_frame = struct.pack("<h", 0)
        wf.writeframes(silence_frame * n_samples)


def synthesize(text: str, out_path: Path, estimated_duration_s: float = 30.0) -> tuple[Path, str]:
    """
    Erzeugt eine Sprachdatei aus Text.
    Rückgabe bei Erfolg: (pfad, engine) - engine ist 'piper' oder 'espeak'.

    WICHTIG (abgesicherte Anforderung): Wenn WEDER Piper NOCH espeak-ng eine
    echte, hörbare Sprachausgabe erzeugen können, wird HIER eine TTSError
    geworfen - es wird NIEMALS eine stille Datei als Ersatz zurückgegeben und
    als 'Erfolg' behandelt. Der Aufrufer (app.agent.run_single_job) lässt diese
    Exception bewusst bis zur äußeren Fehlerbehandlung durchreichen, wodurch der
    Job korrekt als FAILED markiert wird, statt fälschlich auf READY/Upload-bereit
    zu laufen.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []

    if piper_available():
        try:
            _run_piper(text, out_path)
            return out_path, "piper"
        except Exception as exc:
            logger.info(f"Piper fehlgeschlagen ({exc}), versuche espeak-ng.")
            errors.append(f"Piper: {exc}")

    if espeak_available():
        try:
            _run_espeak(text, out_path)
            return out_path, "espeak"
        except Exception as exc:
            logger.info(f"espeak-ng fehlgeschlagen ({exc}).")
            errors.append(f"espeak-ng: {exc}")

    if out_path.exists():
        try:
            out_path.unlink()
        except OSError:
            pass

    detail = "; ".join(errors) if errors else "keine TTS-Engine installiert (weder Piper noch espeak-ng)"
    raise TTSError(
        f"Keine funktionierende TTS-Engine verfügbar - Job wird NICHT mit stiller "
        f"Ersatzaudiodatei fortgesetzt. Details: {detail}"
    )


def get_wav_duration_s(path: Path) -> float:
    try:
        with wave.open(str(path), "rb") as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            return frames / float(rate) if rate else 0.0
    except Exception:
        return 0.0
