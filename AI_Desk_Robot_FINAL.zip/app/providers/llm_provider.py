"""
Lokale-KI-Anbindung (Master-Prompt Abschnitt 11 + 59).

Priorität:
1. Ollama (lokal, kostenlos) - z.B. llama3.2:3b, für Raspberry Pi 5 8GB realistisch
2. kontrollierter regelbasierter Fallback, falls Ollama nicht erreichbar ist
   (baut Skripte aus Recherche-Fakten nach festem Muster zusammen - langsamer/simpler,
    aber die App läuft trotzdem weiter und produziert echte Videos statt abzustürzen)

OpenAI wird bewusst NICHT als Pflicht eingebaut. Wer möchte, kann optional einen
eigenen Provider ergänzen (siehe README) - das System funktioniert aber ohne ihn.

Keine API-Keys im Code. Kein Zwang zu bezahlten Diensten.
"""
from __future__ import annotations
import json
import requests
from typing import Optional
from ..config import env
from ..logging_setup import logger


class LLMUnavailableError(Exception):
    pass


def _ollama_generate(prompt: str, system: Optional[str] = None, timeout: int = 120) -> str:
    payload = {
        "model": env.ollama_model,
        "prompt": prompt,
        "stream": False,
    }
    if system:
        payload["system"] = system
    resp = requests.post(f"{env.ollama_host}/api/generate", json=payload, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    text = data.get("response", "").strip()
    if not text:
        raise LLMUnavailableError("Ollama hat eine leere Antwort geliefert.")
    return text


def ollama_available() -> bool:
    try:
        r = requests.get(f"{env.ollama_host}/api/tags", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


def generate(prompt: str, system: Optional[str] = None, timeout: int = 120) -> tuple[str, str]:
    """
    Erzeugt Text über das konfigurierte LLM.
    Rückgabe: (text, quelle) - quelle ist 'ollama' oder 'fallback_regelbasiert'.
    Wirft niemals unkontrolliert - bei Fehlern greift der Fallback.
    """
    try:
        text = _ollama_generate(prompt, system=system, timeout=timeout)
        return text, "ollama"
    except Exception as exc:
        logger.info(f"Ollama nicht verfügbar oder Fehler ({exc}). Nutze regelbasierten Fallback.")
        return _fallback_text(prompt), "fallback_regelbasiert"


def _fallback_text(prompt: str) -> str:
    """
    Sehr einfacher, aber funktionierender Fallback ohne LLM:
    Extrahiert aus dem Prompt übergebene Fakten (die Aufrufer betten sie strukturiert ein)
    und formt daraus einen einfachen, aber sauberen Fließtext.
    Dieser Pfad ist bewusst simpel gehalten - Ziel ist "funktioniert immer",
    nicht "so gut wie ein LLM".
    """
    lines = [l.strip() for l in prompt.splitlines() if l.strip()]
    facts = [l for l in lines if l.startswith("- ") or l.startswith("FAKT")]
    if not facts:
        facts = lines[-5:] if len(lines) > 5 else lines
    cleaned = [f.lstrip("-FAKT: ").strip() for f in facts if f]
    cleaned = [c for c in cleaned if c][:5]
    if not cleaned:
        cleaned = ["Dazu liegen aktuell keine ausreichenden Informationen vor."]
    return " ".join(cleaned)
