"""
Wetter-Anbindung (Master-Prompt Abschnitt 25).

Nutzt Open-Meteo (https://open-meteo.com) - kostenlos, ohne API-Key.
Wenn nicht erreichbar: klarer Hinweis statt kaputter Optik, App bleibt unabhängig vom Wetter.
"""
from __future__ import annotations
import requests
from ..config import config
from ..logging_setup import logger

_WEATHER_CODE_LABELS = {
    0: "Klar", 1: "Überwiegend klar", 2: "Teilweise bewölkt", 3: "Bewölkt",
    45: "Nebel", 48: "Nebel mit Reifglätte",
    51: "Leichter Nieselregen", 53: "Nieselregen", 55: "Starker Nieselregen",
    61: "Leichter Regen", 63: "Regen", 65: "Starker Regen",
    71: "Leichter Schneefall", 73: "Schneefall", 75: "Starker Schneefall",
    80: "Regenschauer", 81: "Regenschauer", 82: "Heftige Regenschauer",
    95: "Gewitter", 96: "Gewitter mit Hagel", 99: "Starkes Gewitter mit Hagel",
}

_cache = {"data": None, "ts": 0}
_CACHE_TTL_S = 900  # 15 Minuten - keine unnötige Netzwerklast


def get_weather() -> dict:
    import time
    now = time.time()
    if _cache["data"] and (now - _cache["ts"]) < _CACHE_TTL_S:
        return _cache["data"]

    lat = config.get("weather.latitude", 49.0069)
    lon = config.get("weather.longitude", 8.4037)
    label = config.get("weather.city_label", "")

    try:
        resp = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={"latitude": lat, "longitude": lon, "current_weather": "true"},
            timeout=4,
        )
        resp.raise_for_status()
        data = resp.json()
        cw = data.get("current_weather", {})
        code = cw.get("weathercode", -1)
        result = {
            "available": True,
            "temperature_c": cw.get("temperature"),
            "windspeed_kmh": cw.get("windspeed"),
            "condition": _WEATHER_CODE_LABELS.get(code, "Unbekannt"),
            "city_label": label,
        }
        _cache["data"] = result
        _cache["ts"] = now
        return result
    except Exception as exc:
        logger.info(f"Wetter nicht abrufbar ({exc}). Zeige Fallback-Status.")
        result = {
            "available": False,
            "temperature_c": None,
            "windspeed_kmh": None,
            "condition": "Wetter nicht konfiguriert",
            "city_label": label,
        }
        _cache["data"] = result
        _cache["ts"] = now
        return result
