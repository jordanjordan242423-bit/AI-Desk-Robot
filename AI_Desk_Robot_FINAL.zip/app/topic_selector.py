"""
Themenauswahl (Master-Prompt Abschnitt 8 + 9).

Ablauf:
1. Kandidaten aus research.gather_topics() holen
2. bereits verwendete Themen (letzte N Tage) herausfiltern
3. Dopplungen innerhalb der Kandidaten zusammenfassen (einfache Ähnlichkeit über
   gemeinsame signifikante Wörter, keine externen NLP-Abhängigkeiten nötig)
4. Kategorie-Vielfalt erzwingen (nicht 5x hintereinander dieselbe Kategorie)
5. ein Thema mit ECHTEN, geprüften Fakten und einem qualitativ ausreichenden
   Skript auswählen - Kandidaten ohne vertrauenswürdige Fakten oder mit
   misslungenem Skript werden verworfen, statt mit Ersatzinhalten akzeptiert
   zu werden (siehe select_topic_with_facts_and_script).

Keine manuelle Eingabe nötig - der Agent entscheidet vollständig selbst.
"""
from __future__ import annotations
import re
import random
from dataclasses import dataclass
from typing import List, Optional, Tuple
from . import database
from .research import TopicCandidate, gather_topics
from .config import config
from .logging_setup import logger

_STOPWORDS = {
    "der", "die", "das", "und", "oder", "ein", "eine", "einen", "im", "in", "auf", "für",
    "mit", "von", "zu", "den", "dem", "wie", "warum", "über", "bei", "ist", "sind", "als",
}


def _significant_words(text: str) -> set:
    words = re.findall(r"[a-zA-ZäöüÄÖÜß]{4,}", text.lower())
    return {w for w in words if w not in _STOPWORDS}


def _similarity(a: str, b: str) -> float:
    wa, wb = _significant_words(a), _significant_words(b)
    if not wa or not wb:
        return 0.0
    overlap = len(wa & wb)
    return overlap / min(len(wa), len(wb))


def _dedupe(candidates: List[TopicCandidate]) -> List[TopicCandidate]:
    unique: List[TopicCandidate] = []
    for cand in candidates:
        if any(_similarity(cand.title, u.title) > 0.6 for u in unique):
            continue
        unique.append(cand)
    return unique


def _recently_used_categories(n: int = 3) -> List[str]:
    jobs = database.list_jobs(limit=n)
    return [j["category"] for j in jobs if j.get("category")]


def build_candidate_pool() -> List[TopicCandidate]:
    """
    Baut den gefilterten, vielfältigen, gemischten Kandidaten-Pool auf
    (Dopplungen entfernt, kürzlich verwendete Themen möglichst vermieden,
    Kategorie-Vielfalt bevorzugt, Reihenfolge zufällig gemischt).

    Wird sowohl von select_topic() (einfache Auswahl, v.a. für Tests) als auch
    von select_topic_with_facts_and_script() (echte Pipeline mit Qualitätsprüfung
    und Retry über mehrere Kandidaten) verwendet.
    """
    candidates = gather_topics()
    if not candidates:
        return []

    candidates = _dedupe(candidates)

    avoid_days = config.get("topics.avoid_repeat_days", 21)
    used = set(t.lower() for t in database.recent_topics(days=avoid_days))
    filtered = [c for c in candidates if not any(_similarity(c.title, u) > 0.7 for u in used)]
    if not filtered:
        filtered = candidates

    recent_categories = _recently_used_categories(n=2)
    diverse = [c for c in filtered if c.category not in recent_categories]
    pool = diverse if diverse else filtered

    pool = list(pool)
    random.shuffle(pool)
    return pool


def select_topic() -> Optional[TopicCandidate]:
    """Einfache Themenauswahl OHNE Fakten-/Skriptprüfung (v.a. für Tests/Übersicht).
    Die echte Produktions-Pipeline nutzt select_topic_with_facts_and_script()."""
    pool = build_candidate_pool()
    if not pool:
        logger.info("Keine Themenkandidaten verfügbar (weder RSS noch Fallback-Pool). Überspringe diesen Lauf.")
        return None
    chosen = pool[0]
    logger.info(f"Thema ausgewählt: '{chosen.title}' (Kategorie: {chosen.category})")
    return chosen


def select_topic_with_facts_and_script(max_attempts: int = 6) -> Tuple[Optional[TopicCandidate], Optional[object], Optional[object]]:
    """
    Kombinierte Auswahl: probiert Kandidaten der Reihe nach durch, bis einer
    sowohl eine vertrauenswürdige Faktenbasis als auch ein qualitativ
    ausreichendes Skript liefert. Kandidaten, die daran scheitern, werden
    verworfen (kein Ersatzinhalt, kein generischer Text) und der nächste
    Kandidat wird versucht.

    Rückgabe: (candidate, fact_base, script) oder (None, None, None), wenn
    kein Kandidat innerhalb von max_attempts geeignet war.
    """
    from .fact_checker import build_fact_base
    from .script_generator import generate_script, ScriptQualityError

    pool = build_candidate_pool()
    if not pool:
        logger.info("Keine Themenkandidaten verfügbar (weder RSS noch Fallback-Pool).")
        return None, None, None

    attempts = 0
    for candidate in pool:
        if attempts >= max_attempts:
            break
        attempts += 1

        fact_base = build_fact_base(candidate.title, fallback_summary=candidate.summary)
        if fact_base is None:
            logger.info(f"Thema '{candidate.title}' verworfen: keine vertrauenswürdigen Fakten gefunden.")
            continue

        try:
            script = generate_script(candidate.title, fact_base, category=candidate.category)
        except ScriptQualityError as exc:
            logger.info(f"Thema '{candidate.title}' verworfen: Skript-Qualitätsprüfung fehlgeschlagen ({exc}).")
            continue

        logger.info(f"Thema ausgewählt: '{candidate.title}' (Kategorie: {candidate.category}, Versuch {attempts})")
        return candidate, fact_base, script

    logger.info(f"Kein geeignetes Thema nach {attempts} Versuchen gefunden (Fakten- oder Skriptqualität unzureichend).")
    return None, None, None
