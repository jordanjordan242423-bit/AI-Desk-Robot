"""
SQLite-Datenschicht.

Speichert (siehe Master-Prompt Abschnitt 26 + 48):
- Jobs (ein Job = ein Video von der Idee bis zum Upload)
- verwendete Themen (zur Dopplungsvermeidung)
- Systemevents / Fehler
- Einstellungen-Historie (optional simple)

Es wird bewusst KEIN ORM verwendet - für dieses Projekt reicht sqlite3 direkt,
das hält die Abhängigkeiten und die Pi-Last niedrig.
"""
from __future__ import annotations
import sqlite3
import json
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Optional, Any
from .config import DB_PATH

_lock = threading.RLock()  # RLock: verhindert Deadlocks bei verschachtelten db_cursor()-Aufrufen im selben Thread

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'QUEUED',
    topic TEXT,
    category TEXT,
    script TEXT,
    sources TEXT,
    tts_file TEXT,
    video_file TEXT,
    subtitle_file TEXT,
    title TEXT,
    description TEXT,
    hashtags TEXT,
    duration_s REAL,
    filesize_bytes INTEGER,
    error TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    published_at TEXT,
    tiktok_video_id TEXT
);

CREATE TABLE IF NOT EXISTS used_topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL,
    category TEXT,
    used_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level TEXT NOT NULL,
    message TEXT NOT NULL,
    job_id TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tiktok_tokens (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    access_token TEXT,
    refresh_token TEXT,
    expires_at TEXT,
    open_id TEXT
);

CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at);
CREATE INDEX IF NOT EXISTS idx_used_topics_used_at ON used_topics(used_at);
"""


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


@contextmanager
def db_cursor():
    with _lock:
        conn = get_connection()
        try:
            cur = conn.cursor()
            yield cur
            conn.commit()
        finally:
            conn.close()


def init_db():
    with db_cursor() as cur:
        cur.executescript(SCHEMA)


def _now() -> str:
    return datetime.utcnow().isoformat()


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------
def create_job(job_id: str, category: str) -> None:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO jobs (id, status, category, created_at, updated_at) VALUES (?,?,?,?,?)",
            (job_id, "QUEUED", category, _now(), _now()),
        )


def update_job(job_id: str, **fields: Any) -> None:
    if not fields:
        return
    fields["updated_at"] = _now()
    cols = ", ".join(f"{k}=?" for k in fields)
    values = list(fields.values()) + [job_id]
    with db_cursor() as cur:
        cur.execute(f"UPDATE jobs SET {cols} WHERE id=?", values)


def get_job(job_id: str) -> Optional[dict]:
    with db_cursor() as cur:
        cur.execute("SELECT * FROM jobs WHERE id=?", (job_id,))
        row = cur.fetchone()
        return dict(row) if row else None


def list_jobs(limit: int = 100, status: Optional[str] = None) -> list[dict]:
    with db_cursor() as cur:
        if status:
            cur.execute("SELECT * FROM jobs WHERE status=? ORDER BY created_at DESC LIMIT ?", (status, limit))
        else:
            cur.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]


def active_job() -> Optional[dict]:
    """Der Job, an dem der Agent aktuell arbeitet (nicht abgeschlossen, nicht fehlgeschlagen)."""
    terminal = ("PUBLISHED", "FAILED", "READY")
    with db_cursor() as cur:
        cur.execute(
            f"SELECT * FROM jobs WHERE status NOT IN ({','.join('?' * len(terminal))}) "
            "ORDER BY created_at ASC LIMIT 1",
            terminal,
        )
        row = cur.fetchone()
        return dict(row) if row else None


def jobs_today_count() -> int:
    today = datetime.utcnow().date().isoformat()
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) as c FROM jobs WHERE created_at LIKE ?", (f"{today}%",))
        return cur.fetchone()["c"]


def last_job_created_at() -> Optional[datetime]:
    with db_cursor() as cur:
        cur.execute("SELECT created_at FROM jobs ORDER BY created_at DESC LIMIT 1")
        row = cur.fetchone()
        if not row:
            return None
        return datetime.fromisoformat(row["created_at"])


def stats_summary() -> dict:
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) c FROM jobs")
        total = cur.fetchone()["c"]
        cur.execute("SELECT COUNT(*) c FROM jobs WHERE status='PUBLISHED'")
        published = cur.fetchone()["c"]
        cur.execute("SELECT COUNT(*) c FROM jobs WHERE status='READY'")
        ready = cur.fetchone()["c"]
        cur.execute("SELECT COUNT(*) c FROM jobs WHERE status='FAILED'")
        failed = cur.fetchone()["c"]
        cur.execute("SELECT MAX(published_at) p FROM jobs WHERE published_at IS NOT NULL")
        last_upload = cur.fetchone()["p"]
        today = jobs_today_count()
        return {
            "total": total,
            "published": published,
            "ready_for_upload": ready,
            "failed": failed,
            "today": today,
            "last_upload": last_upload,
        }


# ---------------------------------------------------------------------------
# Themen-Historie
# ---------------------------------------------------------------------------
def add_used_topic(topic: str, category: str) -> None:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO used_topics (topic, category, used_at) VALUES (?,?,?)",
            (topic, category, _now()),
        )


def recent_topics(days: int = 21) -> list[str]:
    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
    with db_cursor() as cur:
        cur.execute("SELECT topic FROM used_topics WHERE used_at >= ?", (cutoff,))
        return [r["topic"] for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# Events / Fehler
# ---------------------------------------------------------------------------
def log_event(level: str, message: str, job_id: Optional[str] = None) -> None:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO events (level, message, job_id, created_at) VALUES (?,?,?,?)",
            (level, message, job_id, _now()),
        )


def recent_events(limit: int = 200) -> list[dict]:
    with db_cursor() as cur:
        cur.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]


def error_count_last_days(days: int = 7) -> int:
    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) c FROM events WHERE level='ERROR' AND created_at >= ?", (cutoff,))
        return cur.fetchone()["c"]


# ---------------------------------------------------------------------------
# TikTok Tokens
# ---------------------------------------------------------------------------
def save_tiktok_tokens(access_token: str, refresh_token: str, expires_at: str, open_id: str) -> None:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO tiktok_tokens (id, access_token, refresh_token, expires_at, open_id) "
            "VALUES (1, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET access_token=?, refresh_token=?, expires_at=?, open_id=?",
            (access_token, refresh_token, expires_at, open_id,
             access_token, refresh_token, expires_at, open_id),
        )


def get_tiktok_tokens() -> Optional[dict]:
    with db_cursor() as cur:
        cur.execute("SELECT * FROM tiktok_tokens WHERE id=1")
        row = cur.fetchone()
        return dict(row) if row else None


def clear_tiktok_tokens() -> None:
    with db_cursor() as cur:
        cur.execute("DELETE FROM tiktok_tokens WHERE id=1")
