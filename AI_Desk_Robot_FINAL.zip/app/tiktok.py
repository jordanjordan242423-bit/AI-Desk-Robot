"""
TikTok-Integration (Master-Prompt Abschnitt 18 + 19).

WICHTIG: Ausschließlich die offizielle TikTok Content Posting API (OAuth2) wird verwendet.
KEINE Browser-Hacks, KEIN Cookie-Diebstahl, KEINE Captcha-Umgehung, KEINE Login-Automatisierung.

Diese Klasse zeigt IMMER ehrlich an, ob eine Verbindung wirklich besteht (echter Access-Token
in der Datenbank) - es wird niemals ein 'verbunden'-Status vorgetäuscht.

Ablauf:
1. Der Nutzer richtet eine TikTok-Developer-App ein (client_key/client_secret/redirect_uri in .env)
2. Über /tiktok/connect im Dashboard wird der offizielle OAuth-Consent-Screen geöffnet
3. Nach Zustimmung liefert TikTok einen Code, der hier gegen Access-/Refresh-Token
   ausgetauscht wird (offizieller Token-Endpunkt)
4. Access-Token wird zum Hochladen über den offiziellen Video-Upload-Endpunkt genutzt
5. Refresh-Token wird genutzt, um abgelaufene Access-Token automatisch zu erneuern

Wenn TikTok nicht eingerichtet ist: Video wird trotzdem produziert und bleibt im
Status READY für den manuellen Upload-Fallback (siehe upload_server.py).
"""
from __future__ import annotations
import time
import requests
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional
from .config import env
from . import database
from .logging_setup import logger

AUTH_BASE = "https://www.tiktok.com/v2/auth/authorize/"
TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/"
CREATOR_INFO_URL = "https://open.tiktokapis.com/v2/post/publish/creator_info/query/"
VIDEO_INIT_URL = "https://open.tiktokapis.com/v2/post/publish/video/init/"
STATUS_URL = "https://open.tiktokapis.com/v2/post/publish/status/fetch/"

SCOPES = "video.publish,video.upload"


class TikTokNotConfiguredError(Exception):
    pass


class TikTokAPIError(Exception):
    pass


def is_configured() -> bool:
    return env.tiktok_configured()


def is_connected() -> bool:
    tokens = database.get_tiktok_tokens()
    return bool(tokens and tokens.get("access_token"))


def build_authorize_url(state: str) -> str:
    if not is_configured():
        raise TikTokNotConfiguredError(
            "TikTok ist nicht konfiguriert. Bitte TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET "
            "und TIKTOK_REDIRECT_URI in der .env-Datei setzen."
        )
    params = (
        f"client_key={env.tiktok_client_key}&scope={SCOPES}&response_type=code"
        f"&redirect_uri={requests.utils.quote(env.tiktok_redirect_uri, safe='')}&state={state}"
    )
    return f"{AUTH_BASE}?{params}"


def query_creator_info(access_token: str) -> dict:
    """
    Fragt die offizielle 'Creator Info'-Auskunft ab (Pflichtschritt der TikTok
    Content Posting API vor jedem Direct-Post-Upload). Liefert u.a. die für
    diesen Creator tatsächlich erlaubten Privacy-Level-Optionen sowie ob
    Kommentare/Duett/Stitch plattformseitig deaktiviert sind.

    WICHTIG (ehrliche Einschränkung): Der genaue Feldname und die Werte-Struktur
    dieser Antwort konnten mangels eines echten TikTok-Developer-Accounts in
    dieser Entwicklungsumgebung nicht gegen die echte API verifiziert werden.
    Die Implementierung folgt der offiziell dokumentierten Struktur (Felder
    'privacy_level_options', 'comment_disabled', 'duet_disabled',
    'stitch_disabled', 'max_video_post_duration_sec'). Das Auswerten in
    upload_video() ist defensiv gehalten (fehlende Felder -> sichere Defaults),
    damit ein unerwartetes Antwortformat nicht zu einem Absturz führt.
    """
    resp = requests.post(
        CREATOR_INFO_URL,
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json; charset=UTF-8"},
        timeout=15,
    )
    data = resp.json()
    if resp.status_code != 200:
        raise TikTokAPIError(f"Creator-Info-Abfrage fehlgeschlagen (HTTP {resp.status_code}): {data}")
    return data.get("data", {}) or {}


def _resolve_post_settings(creator_info: dict) -> dict:
    """Leitet aus der Creator-Info die tatsächlich zulässigen/sinnvollen
    post_info-Felder ab, statt fest verdrahtete Werte zu verwenden."""
    allowed_privacy = creator_info.get("privacy_level_options") or ["SELF_ONLY"]
    # Bevorzugt weiterhin die sicherste Option (nur für den Ersteller sichtbar),
    # aber NUR falls diese laut Creator-Info auch tatsächlich erlaubt ist -
    # sonst wird die erste vom Account tatsächlich erlaubte Option verwendet.
    if "SELF_ONLY" in allowed_privacy:
        privacy_level = "SELF_ONLY"
    else:
        privacy_level = allowed_privacy[0]

    return {
        "privacy_level": privacy_level,
        "disable_comment": bool(creator_info.get("comment_disabled", False)),
        "disable_duet": bool(creator_info.get("duet_disabled", False)),
        "disable_stitch": bool(creator_info.get("stitch_disabled", False)),
        "allowed_privacy_options": allowed_privacy,
        "max_video_post_duration_sec": creator_info.get("max_video_post_duration_sec"),
    }


def exchange_code_for_token(code: str) -> dict:
    if not is_configured():
        raise TikTokNotConfiguredError("TikTok ist nicht konfiguriert.")
    resp = requests.post(
        TOKEN_URL,
        data={
            "client_key": env.tiktok_client_key,
            "client_secret": env.tiktok_client_secret,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": env.tiktok_redirect_uri,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )
    data = resp.json()
    if resp.status_code != 200 or "access_token" not in data:
        raise TikTokAPIError(f"Token-Austausch fehlgeschlagen: {data}")

    expires_at = (datetime.utcnow() + timedelta(seconds=int(data.get("expires_in", 3600)))).isoformat()
    database.save_tiktok_tokens(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", ""),
        expires_at=expires_at,
        open_id=data.get("open_id", ""),
    )
    logger.info("TikTok erfolgreich verbunden (offizielle OAuth-Autorisierung abgeschlossen).")
    return data


def _refresh_if_needed() -> Optional[str]:
    tokens = database.get_tiktok_tokens()
    if not tokens or not tokens.get("access_token"):
        return None
    expires_at = tokens.get("expires_at")
    if expires_at and datetime.fromisoformat(expires_at) > datetime.utcnow() + timedelta(minutes=5):
        return tokens["access_token"]

    if not tokens.get("refresh_token"):
        return tokens.get("access_token")

    try:
        resp = requests.post(
            TOKEN_URL,
            data={
                "client_key": env.tiktok_client_key,
                "client_secret": env.tiktok_client_secret,
                "grant_type": "refresh_token",
                "refresh_token": tokens["refresh_token"],
            },
            timeout=15,
        )
        data = resp.json()
        if resp.status_code == 200 and "access_token" in data:
            expires_at_new = (datetime.utcnow() + timedelta(seconds=int(data.get("expires_in", 3600)))).isoformat()
            database.save_tiktok_tokens(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token", tokens["refresh_token"]),
                expires_at=expires_at_new,
                open_id=tokens.get("open_id", ""),
            )
            return data["access_token"]
    except Exception as exc:
        logger.info(f"TikTok-Token-Refresh fehlgeschlagen: {exc}")
    return tokens.get("access_token")


def upload_video(video_path: Path, title: str, description: str) -> dict:
    """
    Lädt ein Video über die offizielle Content Posting API hoch (PULL_FROM_URL wird NICHT
    genutzt, da kein öffentlicher Server garantiert ist - stattdessen FILE_UPLOAD mit direktem
    Chunk-Upload, wie in der offiziellen Doku beschrieben).

    Ablauf (aktualisiert):
    1. Creator-Info abfragen (Pflichtschritt vor Direct Post) und daraus die
       tatsächlich erlaubten Privacy-/Interaktions-Einstellungen ableiten.
    2. Video-Upload initialisieren + hochladen.
    3. Den offiziellen Veröffentlichungsstatus abwarten/prüfen (wait_for_publish_result),
       statt den Erfolg allein aus einem HTTP-200 beim Hochladen anzunehmen.

    Wirft bei jedem Fehlschlag (Auth, Creator-Info, Init, Upload, oder wenn TikTok den
    Post letztlich als fehlgeschlagen meldet) eine Exception. Der Aufrufer
    (app.agent.run_single_job) fängt das ab und belässt den Job auf READY -
    das fertige Video geht dabei NIEMALS verloren und der Job gilt NICHT als
    komplett fehlgeschlagen (siehe README, Abschnitt 'Manueller Upload-Fallback').
    """
    if not is_connected():
        raise TikTokNotConfiguredError("TikTok ist nicht verbunden. Bitte zuerst im Dashboard autorisieren.")

    access_token = _refresh_if_needed()
    if not access_token:
        raise TikTokAPIError("Kein gültiger Access-Token vorhanden.")

    creator_info = query_creator_info(access_token)
    settings = _resolve_post_settings(creator_info)
    logger.info(
        f"TikTok Creator-Info abgefragt: privacy_level={settings['privacy_level']} "
        f"(erlaubte Optionen: {settings['allowed_privacy_options']}), "
        f"disable_comment={settings['disable_comment']}, disable_duet={settings['disable_duet']}, "
        f"disable_stitch={settings['disable_stitch']}"
    )

    file_size = video_path.stat().st_size
    init_resp = requests.post(
        VIDEO_INIT_URL,
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        json={
            "post_info": {
                "title": title[:150],
                "description": description[:2200],
                "privacy_level": settings["privacy_level"],
                "disable_duet": settings["disable_duet"],
                "disable_comment": settings["disable_comment"],
                "disable_stitch": settings["disable_stitch"],
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": file_size,
                "chunk_size": file_size,
                "total_chunk_count": 1,
            },
        },
        timeout=20,
    )
    init_data = init_resp.json()
    if init_resp.status_code != 200 or "data" not in init_data:
        raise TikTokAPIError(f"Upload-Init fehlgeschlagen: {init_data}")

    upload_url = init_data["data"]["upload_url"]
    publish_id = init_data["data"]["publish_id"]

    with open(video_path, "rb") as f:
        video_bytes = f.read()
    put_resp = requests.put(
        upload_url,
        headers={"Content-Type": "video/mp4", "Content-Range": f"bytes 0-{file_size - 1}/{file_size}"},
        data=video_bytes,
        timeout=120,
    )
    if put_resp.status_code not in (200, 201, 206):
        raise TikTokAPIError(f"Video-Upload fehlgeschlagen (HTTP {put_resp.status_code}): {put_resp.text[:300]}")

    logger.info(f"Video an TikTok übertragen. Publish-ID: {publish_id}. Warte auf Veröffentlichungsstatus...")

    final_status = wait_for_publish_result(publish_id)
    logger.info(f"TikTok-Veröffentlichungsstatus final: {final_status.get('resolved_status')}")
    return {"publish_id": publish_id, "status": final_status.get("resolved_status"), "raw": final_status}


def check_publish_status(publish_id: str) -> dict:
    access_token = _refresh_if_needed()
    if not access_token:
        raise TikTokAPIError("Kein gültiger Access-Token vorhanden.")
    resp = requests.post(
        STATUS_URL,
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        json={"publish_id": publish_id},
        timeout=15,
    )
    return resp.json()


# Status-Zeichenketten, die TikTok laut offizieller Doku für Direct-Post-Ergebnisse
# verwendet. Da kein echter Account zum Verifizieren zur Verfügung stand, wird
# defensiv auf Teilstrings geprüft (siehe query_creator_info-Docstring).
_STATUS_SUCCESS_MARKERS = ("PUBLISH_COMPLETE", "SUCCESS")
_STATUS_FAILURE_MARKERS = ("FAILED", "DOWNLOAD_FAILED", "REJECTED")


def wait_for_publish_result(publish_id: str, timeout_s: float = 90.0, poll_interval_s: float = 3.0) -> dict:
    """
    Fragt den offiziellen Veröffentlichungsstatus wiederholt ab, bis TikTok einen
    Endzustand meldet (Erfolg oder Fehlschlag) oder ein Timeout erreicht ist.

    Ein reiner HTTP-200 beim Hochladen bedeutet bei der TikTok-API NICHT, dass das
    Video bereits veröffentlicht ist - der tatsächliche Status muss separat über
    diesen Endpunkt abgefragt werden. Wird kein eindeutiger Endzustand erreicht,
    wird eine TikTokAPIError geworfen (der Job bleibt dadurch READY, das Video
    geht nicht verloren - siehe upload_video()).
    """
    start = time.time()
    last_raw: dict = {}
    while time.time() - start < timeout_s:
        last_raw = check_publish_status(publish_id)
        status_value = str(last_raw.get("data", {}).get("status", "")).upper()

        if any(marker in status_value for marker in _STATUS_SUCCESS_MARKERS):
            last_raw["resolved_status"] = "SUCCESS"
            return last_raw
        if any(marker in status_value for marker in _STATUS_FAILURE_MARKERS):
            raise TikTokAPIError(f"TikTok meldet einen fehlgeschlagenen Veröffentlichungsstatus: {last_raw}")

        time.sleep(poll_interval_s)

    raise TikTokAPIError(
        f"Zeitüberschreitung beim Warten auf den TikTok-Veröffentlichungsstatus "
        f"(Publish-ID {publish_id}, letzter bekannter Stand: {last_raw})"
    )


def disconnect() -> None:
    database.clear_tiktok_tokens()
    logger.info("TikTok-Verbindung getrennt.")
