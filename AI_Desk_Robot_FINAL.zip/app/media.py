"""
Video-Visuals (Master-Prompt Abschnitt 15).

Priorität:
1. Pexels API (kostenlos, API-Key optional in .env) - echtes Stock-Footage
2. Pixabay API (kostenlos, API-Key optional in .env)
3. Garantierter lokaler Fallback: FFmpeg erzeugt selbst einen hochwertigen animierten
   Hintergrund (weicher Farbverlauf mit Bewegung, passend zum dunklen Cyan-Design),
   damit die App NIEMALS wegen eines fehlenden API-Keys unbrauchbar wird.

Kein Pflicht-Key. Kein Absturz, wenn Keys fehlen.
"""
from __future__ import annotations
import subprocess
import requests
from pathlib import Path
from .config import env
from .logging_setup import logger


def _looks_like_valid_video(path: Path, min_bytes: int = 20_000) -> bool:
    """
    Prüft, ob eine heruntergeladene Datei tatsächlich ein gültiges, dekodierbares
    Video ist - nicht nur, dass der HTTP-Download 'erfolgreich' war.

    WICHTIG (echter Bug, per Audit gefunden): _try_pexels()/_try_pixabay() haben
    vorher jeden heruntergeladenen Byte-Inhalt ungeprüft übernommen und True
    zurückgegeben. Bei einem Netzwerkfehler, einer Rate-Limit-/Fehler-Antwort
    (z.B. JSON- oder HTML-Fehlerseite statt echtem Video) oder einem
    abgebrochenen Download wäre eine kaputte Datei als 'Erfolg' gewertet worden -
    das hätte die GESAMTE Pipeline beim späteren FFmpeg-Rendering zum Absturz
    gebracht, obwohl der zuverlässige lokale Fallback bereitsteht. Diese Prüfung
    stellt sicher, dass nur eine wirklich dekodierbare Videodatei akzeptiert wird.
    """
    if not path.exists() or path.stat().st_size < min_bytes:
        return False
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)],
            capture_output=True, timeout=15,
        )
        return probe.returncode == 0 and b"video" in probe.stdout
    except Exception:
        return False


def _try_pexels(query: str, out_path: Path, duration_s: float) -> bool:
    if not env.pexels_api_key:
        return False
    try:
        resp = requests.get(
            "https://api.pexels.com/videos/search",
            headers={"Authorization": env.pexels_api_key},
            params={"query": query, "orientation": "portrait", "per_page": 5},
            timeout=6,
        )
        resp.raise_for_status()
        videos = resp.json().get("videos", [])
        if not videos:
            return False
        files = videos[0].get("video_files", [])
        vertical = [f for f in files if f.get("height", 0) > f.get("width", 0)]
        chosen = (vertical or files)[0]
        video_resp = requests.get(chosen["link"], timeout=20)
        video_resp.raise_for_status()
        out_path.write_bytes(video_resp.content)
        if not _looks_like_valid_video(out_path):
            logger.info("Pexels-Download war keine gültige Videodatei. Nächste Quelle wird versucht.")
            out_path.unlink(missing_ok=True)
            return False
        return True
    except Exception as exc:
        logger.info(f"Pexels-Abfrage fehlgeschlagen ({exc}). Nächste Quelle wird versucht.")
        return False


def _try_pixabay(query: str, out_path: Path, duration_s: float) -> bool:
    if not env.pixabay_api_key:
        return False
    try:
        resp = requests.get(
            "https://pixabay.com/api/videos/",
            params={"key": env.pixabay_api_key, "q": query, "per_page": 5},
            timeout=6,
        )
        resp.raise_for_status()
        hits = resp.json().get("hits", [])
        if not hits:
            return False
        video_url = hits[0]["videos"].get("medium", {}).get("url") or hits[0]["videos"]["small"]["url"]
        video_resp = requests.get(video_url, timeout=20)
        video_resp.raise_for_status()
        out_path.write_bytes(video_resp.content)
        if not _looks_like_valid_video(out_path):
            logger.info("Pixabay-Download war keine gültige Videodatei. Nächste Quelle wird versucht.")
            out_path.unlink(missing_ok=True)
            return False
        return True
    except Exception as exc:
        logger.info(f"Pixabay-Abfrage fehlgeschlagen ({exc}). Nächste Quelle wird versucht.")
        return False


def _generate_local_background(out_path: Path, duration_s: float, width: int = 1080, height: int = 1920) -> None:
    """Garantierter Fallback: erzeugt lokal einen bewegten, hochwertig wirkenden
    dunklen Cyan-Farbverlauf-Hintergrund passend zum App-Design - komplett offline,
    keine externe Abhängigkeit außer FFmpeg selbst."""
    duration_s = max(1.0, duration_s)
    filter_expr = (
        f"gradients=s={width}x{height}:c0=0x061018:c1=0x0a2e33:x0=0:y0=0:"
        f"x1={width}:y1={height}:duration={duration_s}:speed=0.02,"
        f"format=yuv420p"
    )
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi", "-i", filter_expr,
        "-t", str(duration_s), "-r", "30",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
        str(out_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, timeout=120)
    if proc.returncode != 0 or not out_path.exists():
        # Falls das 'gradients'-Filter in dieser FFmpeg-Version fehlt: einfacherer, robusterer Fallback
        simple_cmd = [
            "ffmpeg", "-y", "-f", "lavfi",
            "-i", f"color=c=0x0a2e33:s={width}x{height}:d={duration_s}:r=30",
            "-vf", "format=yuv420p",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            str(out_path),
        ]
        proc2 = subprocess.run(simple_cmd, capture_output=True, timeout=120)
        if proc2.returncode != 0 or not out_path.exists():
            raise RuntimeError(f"Lokaler Hintergrund konnte nicht erzeugt werden: {proc2.stderr.decode('utf-8','ignore')[:300]}")


def get_background_video(topic: str, duration_s: float, out_dir: Path) -> tuple[Path, str]:
    """Liefert einen Hintergrundclip. Rückgabe: (pfad, quelle)."""
    out_dir.mkdir(parents=True, exist_ok=True)
    stock_path = out_dir / "background_stock.mp4"

    if _try_pexels(topic, stock_path, duration_s):
        return stock_path, "pexels"
    if _try_pixabay(topic, stock_path, duration_s):
        return stock_path, "pixabay"

    local_path = out_dir / "background_local.mp4"
    _generate_local_background(local_path, duration_s)
    return local_path, "lokal_generiert"
