"""
Zentrale Konfiguration für AI Desk Robot.

Lädt Werte in dieser Priorität:
1. Umgebungsvariablen / .env  (Secrets, Hosts, Ports, API-Keys)
2. config.yaml                (Verhaltens-Einstellungen, änderbar über UI)
3. eingebaute Standardwerte    (funktioniert auch ohne jede Konfiguration)

Keine Secrets im Code. Keine Pflicht-API-Keys.
"""
from __future__ import annotations
import os
import yaml
import threading
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "db" / "ai_desk_robot.sqlite3"
VIDEOS_DIR = DATA_DIR / "videos"
AUDIO_DIR = DATA_DIR / "audio"
LOG_DIR = DATA_DIR / "logs"
BACKUP_DIR = DATA_DIR / "backups"
CONFIG_YAML_PATH = BASE_DIR / "config.yaml"
ENV_PATH = BASE_DIR / ".env"

for d in (DATA_DIR, DATA_DIR / "db", VIDEOS_DIR, AUDIO_DIR, LOG_DIR, BACKUP_DIR):
    d.mkdir(parents=True, exist_ok=True)


def _load_dotenv(path: Path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        # Erlaubt einfache Inline-Kommentare (" # ...") hinter unquotierten Werten,
        # ohne quotierte Werte zu beschädigen - macht .env robuster gegen Tippfehler.
        if not (value.startswith('"') or value.startswith("'")) and " #" in value:
            value = value.split(" #", 1)[0].strip()
        value = value.strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


_load_dotenv(ENV_PATH)


def _safe_int(raw: str | None, default: int) -> int:
    """
    Wandelt einen String sicher in int um. Liefert bei fehlendem/ungültigem Wert
    den Default zurück, statt eine Exception zu werfen.

    WICHTIG (echter Bug, durch Audit gefunden): env.flask_port/upload_port/
    gpio_button_pin wurden vorher direkt mit int(os.environ.get(...)) berechnet -
    ein Tippfehler oder ein leerer/ungültiger Wert in .env (z.B. 'FLASK_PORT=' oder
    'FLASK_PORT=abc') hätte beim Programmstart (Modul-Import) eine ungefangene
    ValueError ausgelöst und DIE GESAMTE APP am Start gehindert. Das darf laut
    Anforderung ('fehlende/fehlerhafte Konfiguration darf nicht zum Absturz führen')
    nicht passieren.
    """
    if raw is None or str(raw).strip() == "":
        return default
    try:
        return int(str(raw).strip())
    except (ValueError, TypeError):
        return default


def _default_config() -> dict:
    return {
        "videos_per_day": 2,
        "language": "de",
        "min_hours_between_videos": 3,
        "video": {
            "width": 1080,
            "height": 1920,
            "fps": 30,
            "min_duration_s": 30,
            "max_duration_s": 60,
        },
        "topics": {
            "categories": [
                "Technik", "Wissenschaft", "Weltraum", "Natur", "Geschichte",
                "kuriose Fakten", "Tiere", "Psychologie", "Alltagsfakten",
                "Forschung", "Erfindungen", "Energie", "Computer", "KI",
                "Astronomie", "Geografie", "außergewöhnliche Ereignisse",
            ],
            "avoid_repeat_days": 21,
        },
        "llm": {
            "provider": "ollama",
            "ollama_host": "http://127.0.0.1:11434",
            "ollama_model": "llama3.2:3b",
            "timeout_s": 120,
        },
        "tts": {
            "provider": "piper",
            "piper_voice": "de_DE-thorsten-medium",
            "fallback_provider": "espeak",
        },
        "media": {
            "pexels_api_key_required": False,
            "pixabay_api_key_required": False,
        },
        "tiktok": {
            "enabled": False,
        },
        "weather": {
            "provider": "open-meteo",
            "latitude": 49.0069,
            "longitude": 8.4037,
            "city_label": "Karlsruhe",
        },
        "upload_server": {
            "port": 8765,
        },
    }


class Config:
    """Thread-sicherer Zugriff auf Konfiguration, aus config.yaml + ENV zusammengeführt."""

    _lock = threading.RLock()  # RLock: 'set()' ruft 'save()' auf, während der Lock noch gehalten wird

    def __init__(self):
        self._data = _default_config()
        self._load_yaml()

    def _load_yaml(self):
        if CONFIG_YAML_PATH.exists():
            try:
                loaded = yaml.safe_load(CONFIG_YAML_PATH.read_text(encoding="utf-8")) or {}
                self._deep_merge(self._data, loaded)
            except Exception:
                pass  # config.yaml defekt -> Standardwerte verwenden, App darf nicht abstürzen
        else:
            self.save()

    @staticmethod
    def _deep_merge(base: dict, override: dict):
        for k, v in override.items():
            if isinstance(v, dict) and isinstance(base.get(k), dict):
                Config._deep_merge(base[k], v)
            else:
                base[k] = v

    def save(self):
        with self._lock:
            CONFIG_YAML_PATH.write_text(
                yaml.dump(self._data, allow_unicode=True, sort_keys=False), encoding="utf-8"
            )

    def get(self, dotted_key: str, default=None):
        node = self._data
        for part in dotted_key.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return default
        return node

    def set(self, dotted_key: str, value):
        with self._lock:
            parts = dotted_key.split(".")
            node = self._data
            for part in parts[:-1]:
                node = node.setdefault(part, {})
            node[parts[-1]] = value
            self.save()

    def as_dict(self) -> dict:
        return dict(self._data)


config = Config()


@dataclass
class Env:
    """Secrets & Host-Einstellungen ausschließlich aus Umgebungsvariablen / .env."""
    flask_host: str = field(default_factory=lambda: os.environ.get("FLASK_HOST", "0.0.0.0"))
    flask_port: int = field(default_factory=lambda: _safe_int(os.environ.get("FLASK_PORT"), 8080))
    upload_port: int = field(default_factory=lambda: _safe_int(os.environ.get("UPLOAD_PORT"), 8765))
    secret_key: str = field(default_factory=lambda: os.environ.get("SECRET_KEY", "change-me-in-.env-please"))

    ollama_host: str = field(default_factory=lambda: os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434"))
    ollama_model: str = field(default_factory=lambda: os.environ.get("OLLAMA_MODEL", "llama3.2:3b"))

    piper_bin: str = field(default_factory=lambda: os.environ.get("PIPER_BIN", "piper"))
    piper_voice_path: str = field(default_factory=lambda: os.environ.get("PIPER_VOICE_PATH", ""))

    pexels_api_key: Optional[str] = field(default_factory=lambda: os.environ.get("PEXELS_API_KEY") or None)
    pixabay_api_key: Optional[str] = field(default_factory=lambda: os.environ.get("PIXABAY_API_KEY") or None)
    weather_api_key: Optional[str] = field(default_factory=lambda: os.environ.get("WEATHER_API_KEY") or None)

    tiktok_client_key: Optional[str] = field(default_factory=lambda: os.environ.get("TIKTOK_CLIENT_KEY") or None)
    tiktok_client_secret: Optional[str] = field(default_factory=lambda: os.environ.get("TIKTOK_CLIENT_SECRET") or None)
    tiktok_redirect_uri: Optional[str] = field(default_factory=lambda: os.environ.get("TIKTOK_REDIRECT_URI") or None)

    gpio_button_pin: Optional[int] = field(
        default_factory=lambda: _safe_int(os.environ.get("GPIO_BUTTON_PIN"), None)
        if os.environ.get("GPIO_BUTTON_PIN") else None
    )

    def tiktok_configured(self) -> bool:
        return bool(self.tiktok_client_key and self.tiktok_client_secret and self.tiktok_redirect_uri)


env = Env()
