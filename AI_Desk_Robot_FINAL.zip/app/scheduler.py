"""
Scheduler & Watchdog (Master-Prompt Abschnitt 35 + 47).

Der Scheduler läuft als Hintergrundthread und prüft periodisch:
- ist gerade schon ein Job aktiv? -> warten
- wurden heute schon genug Videos erzeugt? -> warten bis morgen
- ist der Mindestabstand zum letzten Job eingehalten? -> sonst warten
- sonst: neuen Job starten (agent.run_single_job in eigenem Thread)

Der Watchdog erkennt hängende Jobs (Laufzeit über einem Schwellwert) und markiert
sie als FAILED, damit der Scheduler danach einen neuen Versuch starten kann -
es gibt aber eine Job-eindeutige ID und keine Endlosschleife, die parallel neue
Jobs anstößt (Abschnitt 47/48).
"""
from __future__ import annotations
import threading
import time
from datetime import datetime, timedelta
from . import database, agent
from .config import config
from .logging_setup import logger

_WATCHDOG_MAX_JOB_MINUTES = 25  # ein Video-Job darf realistisch nicht länger als das dauern
_POLL_INTERVAL_S = 30

_scheduler_thread: threading.Thread | None = None
_watchdog_thread: threading.Thread | None = None
_stop_event = threading.Event()


def _should_start_new_job() -> bool:
    if agent.state.is_running:
        return False
    if database.active_job():
        return False  # es gibt noch einen unfertigen Job aus einem vorherigen Lauf (z.B. nach Neustart)

    # Defensiv gegen einen ungültigen config.yaml-Wert (z.B. durch manuelle Bearbeitung
    # oder einen fehlerhaften Client-Request) - siehe auch die Validierung in
    # app/web/routes.py:api_settings_post(). Ohne diese Absicherung würde ein
    # nicht-numerischer Wert hier eine TypeError auslösen und die gesamte
    # autonome Video-Erstellung dauerhaft lahmlegen.
    videos_per_day = config.get("videos_per_day", 2)
    if not isinstance(videos_per_day, int) or isinstance(videos_per_day, bool) or videos_per_day < 1:
        videos_per_day = 2
    if database.jobs_today_count() >= videos_per_day:
        return False

    min_hours = config.get("min_hours_between_videos", 3)
    if not isinstance(min_hours, (int, float)) or isinstance(min_hours, bool) or min_hours < 0:
        min_hours = 3
    last_created = database.last_job_created_at()
    if last_created and (datetime.utcnow() - last_created) < timedelta(hours=min_hours):
        return False

    return True


def _scheduler_loop():
    logger.info("Scheduler gestartet")
    while not _stop_event.is_set():
        try:
            if _should_start_new_job():
                # Atomare Reservierung UNMITTELBAR vor dem Thread-Start (siehe
                # agent.try_reserve_run_slot()) - schließt die Race Condition mit
                # einem gleichzeitigen manuellen 'Jetzt Video erstellen'-Klick.
                if agent.try_reserve_run_slot():
                    logger.info("Scheduler startet neuen Video-Job")
                    try:
                        job_thread = threading.Thread(target=agent.run_single_job, daemon=True)
                        job_thread.start()
                    except Exception:
                        # Thread-Start fehlgeschlagen: Reservierung freigeben, sonst bliebe
                        # der Agent fälschlich dauerhaft auf 'is_running=True' hängen.
                        with agent.state.lock:
                            agent.state.is_running = False
                        raise
                    job_thread.join()  # ein Job zur Zeit - kein paralleles Rendering auf dem Pi
        except Exception as exc:
            logger.info(f"Scheduler-Fehler (wird ignoriert, Betrieb läuft weiter): {exc}")
            database.log_event("ERROR", f"Scheduler-Fehler: {exc}")
        _stop_event.wait(_POLL_INTERVAL_S)


def _watchdog_loop():
    logger.info("Watchdog gestartet")
    while not _stop_event.is_set():
        try:
            job = database.active_job()
            if job:
                updated = datetime.fromisoformat(job["updated_at"])
                if datetime.utcnow() - updated > timedelta(minutes=_WATCHDOG_MAX_JOB_MINUTES):
                    logger.info(f"[{job['id']}] Watchdog: Job hängt seit über {_WATCHDOG_MAX_JOB_MINUTES} Minuten - als FAILED markiert")
                    database.update_job(job["id"], status="FAILED", error="Watchdog: Zeitüberschreitung")
                    database.log_event("ERROR", "Watchdog: Job wegen Zeitüberschreitung abgebrochen", job["id"])
                    with agent.state.lock:
                        agent.state.is_running = False
                        agent.state.current_job_id = None
        except Exception as exc:
            logger.info(f"Watchdog-Fehler (wird ignoriert): {exc}")
        _stop_event.wait(60)


def start():
    global _scheduler_thread, _watchdog_thread
    _stop_event.clear()
    if _scheduler_thread is None or not _scheduler_thread.is_alive():
        _scheduler_thread = threading.Thread(target=_scheduler_loop, daemon=True)
        _scheduler_thread.start()
    if _watchdog_thread is None or not _watchdog_thread.is_alive():
        _watchdog_thread = threading.Thread(target=_watchdog_loop, daemon=True)
        _watchdog_thread.start()


def stop():
    _stop_event.set()


def trigger_manual_run():
    """Erlaubt einen sofortigen Testlauf (z.B. über die Einstellungen), ignoriert Tageslimit NICHT,
    aber ignoriert den Mindestabstand - nützlich für Tests/Debugging."""
    if database.active_job():
        return False
    # Atomare Reservierung (siehe agent.try_reserve_run_slot()) statt separatem
    # Prüfen+Setzen - verhindert eine Race Condition mit dem Scheduler.
    if not agent.try_reserve_run_slot():
        return False
    try:
        thread = threading.Thread(target=agent.run_single_job, daemon=True)
        thread.start()
    except Exception:
        with agent.state.lock:
            agent.state.is_running = False
        raise
    return True
