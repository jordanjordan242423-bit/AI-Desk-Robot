"""
Faktprüfung (Master-Prompt Abschnitt 8, Schritt 8-9 sowie Abschnitt 9: 'keine erfundenen Zahlen/Quellen').

Vorgehen:
1. Deutsche Wikipedia-REST-API (kostenlos, kein Key, offizielle öffentliche API) wird
   genutzt, um eine Kurzzusammenfassung zum gewählten Thema zu holen.
2. Wenn Wikipedia keinen Treffer liefert: die ursprüngliche RSS-Beschreibung wird verwendet.
3. Wenn auch das fehlt: das Thema wird mit einem Hinweis ohne Detailfakten weitergegeben -
   der Skript-Generator formuliert dann bewusst vorsichtiger, statt Zahlen zu erfinden.

Es werden ausschließlich Sätze aus der abgerufenen Quelle übernommen (keine vom LLM
"erfundenen" Fakten werden hier eingespeist) - das Skript basiert auf echten Quellensätzen.
"""
from __future__ import annotations
import re
import requests
from dataclasses import dataclass, field
from typing import List
from .logging_setup import logger


@dataclass
class FactBase:
    topic: str
    facts: List[str] = field(default_factory=list)
    source_name: str = ""
    source_url: str = ""
    verified: bool = False


def _split_sentences(text: str) -> List[str]:
    text = re.sub(r"\s+", " ", text).strip()
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s.strip() for s in sentences if len(s.strip()) > 15]


def _wikipedia_summary(topic_title: str) -> FactBase | None:
    try:
        search_resp = requests.get(
            "https://de.wikipedia.org/w/api.php",
            params={
                "action": "query", "list": "search", "srsearch": topic_title,
                "format": "json", "srlimit": 1,
            },
            timeout=5, headers={"User-Agent": "AI-Desk-Robot/1.0 (lokales Recherche-Tool)"},
        )
        search_resp.raise_for_status()
        results = search_resp.json().get("query", {}).get("search", [])
        if not results:
            return None
        page_title = results[0]["title"]

        summary_resp = requests.get(
            f"https://de.wikipedia.org/api/rest_v1/page/summary/{requests.utils.quote(page_title)}",
            timeout=5, headers={"User-Agent": "AI-Desk-Robot/1.0 (lokales Recherche-Tool)"},
        )
        summary_resp.raise_for_status()
        data = summary_resp.json()
        extract = data.get("extract", "")
        if not extract:
            return None
        sentences = _split_sentences(extract)[:6]
        if not sentences:
            return None
        return FactBase(
            topic=topic_title,
            facts=sentences,
            source_name=f"Wikipedia: {page_title}",
            source_url=data.get("content_urls", {}).get("desktop", {}).get("page", ""),
            verified=True,
        )
    except Exception as exc:
        logger.info(f"Wikipedia-Abfrage fehlgeschlagen ({exc}).")
        return None


def build_fact_base(topic_title: str, fallback_summary: str = "") -> "FactBase | None":
    """
    Liefert eine geprüfte Faktenbasis für das Thema - oder None, wenn keine
    vertrauenswürdigen Fakten gefunden wurden.

    WICHTIG (aktualisierte Anforderung): Es werden NIEMALS generische Ersatzsätze
    ("... ist ein Thema, zu dem es viel zu entdecken gibt.") als Ersatz für echte
    Fakten verwendet. Wenn weder Wikipedia noch eine ausreichend substantielle
    Quellenbeschreibung vorliegen, wird None zurückgegeben - der Aufrufer (siehe
    app.topic_selector.select_topic_with_facts) verwirft das Thema dann und
    versucht einen anderen Kandidaten, statt ein Video auf Basis erfundener/
    generischer Inhalte zu bauen.
    """
    fb = _wikipedia_summary(topic_title)
    if fb:
        logger.info(f"Fakten via Wikipedia geprüft: {fb.source_name}")
        return fb

    if fallback_summary:
        sentences = _split_sentences(fallback_summary)
        # Mindestanforderung an Substanz: nicht nur ein einzelner sehr kurzer Satz.
        # Damit wird verhindert, dass eine dürftige RSS-Beschreibung ("Kurz." o.ä.)
        # fälschlich als ausreichende Faktenbasis akzeptiert wird.
        total_chars = sum(len(s) for s in sentences)
        if sentences and total_chars >= 60:
            logger.info("Wikipedia ohne Treffer - nutze ausreichend substantielle Beschreibung aus der Quelle.")
            return FactBase(topic=topic_title, facts=sentences[:5], source_name="Quellenbeschreibung", verified=False)

    logger.info(f"Keine vertrauenswürdigen Fakten für '{topic_title}' gefunden - Thema wird verworfen (kein Ersatztext).")
    return None
