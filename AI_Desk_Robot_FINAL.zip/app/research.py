"""
Recherche-Modul (Master-Prompt Abschnitt 10).

Priorität:
1. öffentliche RSS-/Atom-Feeds (kostenlos, legal, kein Login/Captcha-Umgehen)
2. lokaler Themenpool als Fallback, falls kein Feed erreichbar ist

Es wird ausschließlich XML aus RSS-Feeds geparst (kein HTML-Scraping,
kein Umgehen von Zugriffsschutz). Wenn eine Quelle nicht erreichbar ist,
wird die nächste versucht; scheitert alles, springt der lokale Fallback-Pool ein,
damit der Agent niemals steckenbleibt.
"""
from __future__ import annotations
import html
import re
import requests
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import List
from .config import config
from .logging_setup import logger

_HTML_TAG_RE = re.compile(r"<[^>]+>")


def _clean_feed_text(text: str) -> str:
    """
    Bereinigt Text aus RSS-/Atom-Feldern: entfernt HTML-Tags und wandelt
    HTML-Entities in normale Zeichen um.

    WICHTIG (echter Bug, per Audit gefunden): RSS-<description>-Felder enthalten
    in der Praxis sehr häufig rohes HTML (z.B. '<p>...</p>', '&amp;', eingebettete
    <img>-Tags). Ohne diese Bereinigung wären HTML-Tags/Entities direkt in die
    Faktenbasis, das gesprochene Skript und die eingebrannten Untertitel
    gelangt, sobald echte RSS-Feeds erreichbar sind (z.B. hörbares "kleiner p
    größer" oder sichtbare Tags im Video).
    """
    if not text:
        return ""
    text = _HTML_TAG_RE.sub(" ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# Ausschließlich seriöse, öffentlich zugängliche RSS-Feeds ohne Login/Paywall-Umgehung.
_FEEDS = {
    "Wissenschaft": [
        "https://www.spektrum.de/alias/rss/spektrum-de-rss-feed/996406",
        "https://www.scinexx.de/feed/",
    ],
    "Technik": [
        "https://www.heise.de/rss/heise-atom.xml",
    ],
    "Weltraum": [
        "https://www.raumfahrer.net/news/feed/",
    ],
    "Natur": [
        "https://www.scinexx.de/feed/",
    ],
}

# Lokaler Fallback-Themenpool: (Kategorie, Titel, echte kurze Faktenbeschreibung).
# Die Beschreibung ist bewusst KEIN generischer Platzhaltersatz, sondern ein echter,
# geprüfter Kurzfakt (allgemein bekanntes, unstrittiges Wissen, keine erfundenen Zahlen).
# So liefert der Fact-Checker auch ohne Internet/Wikipedia-Zugriff eine ausreichend
# substantielle, ehrliche Faktenbasis statt eines Ersatztexts (siehe app.fact_checker).
_FALLBACK_POOL = [
    ("Weltraum", "Warum die Venus rückwärts rotiert",
     "Die Venus dreht sich als einziger der großen Planeten entgegengesetzt zu ihrer Umlaufrichtung um die eigene Achse. "
     "Ein Venustag dauert dabei rund 243 Erdtage - länger als ein Venusjahr."),
    ("Technik", "Wie ein Quantencomputer sich von einem klassischen Computer unterscheidet",
     "Klassische Computer rechnen mit Bits, die entweder 0 oder 1 sind. Quantencomputer nutzen Qubits, "
     "die durch Superposition und Verschränkung mehrere Zustände gleichzeitig darstellen können."),
    ("Natur", "Warum manche Bäume tausende Jahre alt werden können",
     "Grannenkiefern in Kalifornien zählen zu den ältesten bekannten Einzelbäumen der Erde, manche sind über 4.800 Jahre alt. "
     "Ihr extrem langsames Wachstum in kargen Hochgebirgslagen schützt sie vor Schädlingen und Fäulnis."),
    ("Geschichte", "Wie die Bibliothek von Alexandria die Wissenschaft prägte",
     "Die antike Bibliothek von Alexandria in Ägypten war eines der bedeutendsten Gelehrtenzentren der Antike. "
     "Wissenschaftler wie Eratosthenes und Euklid wirkten dort, bevor die Bibliothek über Jahrhunderte hinweg unterging."),
    ("kuriose Fakten", "Warum Honig praktisch nicht verdirbt",
     "Honig hat einen sehr geringen Wassergehalt und einen niedrigen pH-Wert, was Bakterien das Wachstum erschwert. "
     "Archäologen haben in altägyptischen Gräbern Honig gefunden, der nach Jahrtausenden noch genießbar war."),
    ("Tiere", "Wie Zugvögel sich über tausende Kilometer orientieren",
     "Zugvögel orientieren sich unter anderem am Erdmagnetfeld, am Sonnenstand und an Sternbildern. "
     "Manche Arten legen dabei jährlich mehrere tausend Kilometer zwischen Brut- und Überwinterungsgebiet zurück."),
    ("Psychologie", "Warum das Gehirn Muster in zufälligem Rauschen erkennt",
     "Das menschliche Gehirn ist darauf trainiert, schnell Muster zu erkennen, da das evolutionär oft überlebenswichtig war. "
     "Dieser als Apophänie bezeichnete Effekt führt manchmal dazu, dass auch in echtem Zufall vermeintliche Muster gesehen werden."),
    ("Alltagsfakten", "Warum heißes Wasser manchmal schneller gefriert als kaltes",
     "Der sogenannte Mpemba-Effekt beschreibt die Beobachtung, dass heißes Wasser unter bestimmten Bedingungen schneller "
     "gefrieren kann als kaltes. Die genauen physikalischen Ursachen werden bis heute in der Forschung diskutiert."),
    ("Forschung", "Wie Forschende die Tiefsee mit Drucksensoren erkunden",
     "Tauchroboter und U-Boote für die Tiefsee sind mit Drucksensoren ausgestattet, die dem enormen Wasserdruck standhalten. "
     "Damit lassen sich selbst Regionen wie der Marianengraben in mehreren tausend Metern Tiefe vermessen."),
    ("Erfindungen", "Wie der Zufall bei der Entdeckung des Post-it beteiligt war",
     "Der Chemiker Spencer Silver entwickelte 1968 bei 3M versehentlich einen schwachen, wiederverwendbaren Klebstoff, "
     "als er eigentlich einen besonders starken Kleber herstellen wollte. Erst Jahre später fand ein Kollege dafür die Idee des Klebezettels."),
    ("Energie", "Wie Perowskit-Solarzellen die Solartechnik verändern könnten",
     "Perowskit-Solarzellen gelten als vielversprechende Ergänzung zu klassischen Silizium-Solarzellen, da sie "
     "potenziell günstiger herzustellen sind. Ihre Langzeitstabilität ist allerdings noch Gegenstand aktiver Forschung."),
    ("Computer", "Wie Fehlerkorrektur Daten auf einer beschädigten CD retten kann",
     "CDs speichern Daten mit zusätzlichen Fehlerkorrektur-Codes nach dem Reed-Solomon-Verfahren. "
     "Dadurch können auch bei kleineren Kratzern oder Beschädigungen die ursprünglichen Daten oft noch rekonstruiert werden."),
    ("KI", "Wie neuronale Netze von echten Nervenzellen inspiriert wurden",
     "Künstliche neuronale Netze orientieren sich locker an der Funktionsweise biologischer Nervenzellen, "
     "die Signale über gewichtete Verbindungen weitergeben. Technisch sind sie dabei aber deutlich einfacher als echte Gehirne."),
    ("Astronomie", "Warum der Nachthimmel nicht komplett schwarz ist",
     "Obwohl das Universum unzählige Sterne enthält, ist der Nachthimmel nicht durchgängig hell erleuchtet. "
     "Das liegt unter anderem daran, dass das Universum ein endliches Alter hat und Licht sehr weit entfernter Sterne uns noch nicht erreicht hat."),
    ("Geografie", "Warum es am Äquator keine ausgeprägten Jahreszeiten gibt",
     "Am Äquator trifft die Sonne das ganze Jahr über in einem ähnlichen Winkel auf die Erdoberfläche. "
     "Dadurch bleiben Tageslänge und Temperaturen dort deutlich konstanter als in höheren Breitengraden."),
    ("außergewöhnliche Ereignisse", "Wie das Tunguska-Ereignis bis heute erforscht wird",
     "Im Jahr 1908 zerstörte eine gewaltige Explosion über Sibirien rund 2.000 Quadratkilometer Wald. "
     "Vermutlich handelte es sich um die Explosion eines Meteoroiden oder Kometenfragments in der Atmosphäre, ein eindeutiger Krater wurde nie gefunden."),
]


@dataclass
class TopicCandidate:
    category: str
    title: str
    summary: str
    source: str


def _fetch_feed(url: str, timeout: float = 5.0) -> List[TopicCandidate]:
    candidates = []
    try:
        resp = requests.get(url, timeout=timeout, headers={"User-Agent": "AI-Desk-Robot/1.0"})
        resp.raise_for_status()
        root = ET.fromstring(resp.content)
        items = root.findall(".//item") or root.findall(".//{http://www.w3.org/2005/Atom}entry")
        for item in items[:10]:
            # WICHTIG (echter Bug, per Audit gefunden): 'item.find(a) or item.find(b)' ist hier
            # FALSCH - ElementTree-Elemente werten als bool() über ihre Kind-ELEMENTE aus
            # (len(element) > 0), NICHT über ihren Textinhalt. Ein ganz normales <title>Text</title>
            # ohne Kind-Tags gilt damit als 'falsy', wodurch 'or' fälschlich auf den zweiten
            # (meist erfolglosen) Atom-Fallback auswich und der Titel praktisch IMMER leer blieb,
            # sobald echte RSS-Feeds erreichbar sind. Korrekt ist ein expliziter is-None-Check.
            title_el = item.find("title")
            if title_el is None:
                title_el = item.find("{http://www.w3.org/2005/Atom}title")
            desc_el = item.find("description")
            if desc_el is None:
                desc_el = item.find("{http://www.w3.org/2005/Atom}summary")
            title = (title_el.text or "").strip() if title_el is not None else ""
            desc = _clean_feed_text(desc_el.text or "") if desc_el is not None else ""
            title = _clean_feed_text(title)
            if title:
                candidates.append(TopicCandidate(category="", title=title, summary=desc, source=url))
    except Exception as exc:
        logger.info(f"RSS-Feed nicht erreichbar ({url}): {exc}")
    return candidates


def gather_topics(max_candidates: int = 25) -> List[TopicCandidate]:
    """Sammelt Themenkandidaten aus RSS-Feeds; fällt auf den lokalen Pool zurück,
    wenn kein Feed erreichbar war (Master-Prompt: 'App darf nicht komplett abstürzen')."""
    collected: List[TopicCandidate] = []
    for category, urls in _FEEDS.items():
        for url in urls:
            items = _fetch_feed(url)
            for it in items:
                it.category = category
                collected.append(it)
            if len(collected) >= max_candidates:
                break
        if len(collected) >= max_candidates:
            break

    if not collected:
        logger.info("Keine RSS-Feeds erreichbar. Nutze lokalen Fallback-Themenpool.")
        for category, title, summary in _FALLBACK_POOL:
            collected.append(TopicCandidate(category=category, title=title, summary=summary, source="lokaler_pool"))

    return collected[:max_candidates]
