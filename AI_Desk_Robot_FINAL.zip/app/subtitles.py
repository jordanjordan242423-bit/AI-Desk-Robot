"""
Untertitel-Erzeugung (Master-Prompt Abschnitt 16).

Teilt das Skript in kurze, gut lesbare Segmente auf und verteilt sie zeitlich
proportional über die tatsächliche Audiodauer (nicht nur Schätzung), damit die
Untertitel synchron zur echten TTS-Ausgabe laufen.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import List, Tuple

_MAX_CHARS_PER_SEGMENT = 42  # gut lesbar auf Handy/TikTok, siehe Abschnitt 16


def _split_into_segments(text: str) -> List[str]:
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    segments: List[str] = []
    for sentence in sentences:
        words = sentence.split()
        current = ""
        for word in words:
            candidate = (current + " " + word).strip()
            if len(candidate) > _MAX_CHARS_PER_SEGMENT and current:
                segments.append(current)
                current = word
            else:
                current = candidate
        if current:
            segments.append(current)
    return [s for s in segments if s.strip()]


def _format_srt_time(seconds: float) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def generate_srt(full_text: str, total_duration_s: float, out_path: Path) -> Path:
    segments = _split_into_segments(full_text)
    if not segments:
        segments = [full_text.strip() or "..."]

    total_chars = sum(len(s) for s in segments) or 1
    lines = []
    cursor = 0.0
    for i, seg in enumerate(segments, start=1):
        share = len(seg) / total_chars
        seg_duration = max(0.8, total_duration_s * share)
        start = cursor
        end = min(total_duration_s, cursor + seg_duration)
        cursor = end
        lines.append(f"{i}\n{_format_srt_time(start)} --> {_format_srt_time(end)}\n{seg}\n")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


def _format_ass_time(seconds: float) -> str:
    cs = int(round(seconds * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h:d}:{m:02d}:{s:02d}.{cs:02d}"


def generate_ass(full_text: str, total_duration_s: float, out_path: Path,
                  video_width: int = 1080, video_height: int = 1920) -> Path:
    """
    Erzeugt eine eigenständige .ass-Untertiteldatei mit EXPLIZIT gesetzter PlayResX/PlayResY.

    Hintergrund (echter Testbefund in dieser Umgebung, siehe auch README/Troubleshooting):
    Wird eine reine .srt-Datei zusammen mit 'force_style' an FFmpegs 'subtitles'-Filter
    übergeben, wendet die hier verwendete libass-Version einen unvorhersehbaren internen
    Referenz-Skalierungsfaktor auf FontSize/Alignment/MarginV an (Ergebnis in Tests:
    Untertitel viel zu groß, falsch positioniert, teils über den Bildrand hinauslaufend).
    Mit einer selbst geschriebenen .ass-Datei, die PlayResX/PlayResY exakt auf die reale
    Videoauflösung setzt, kennt libass die Zielauflösung von Anfang an und rendert
    Schriftgröße/Position exakt in echten Pixeln - reproduzierbar getestet und verifiziert
    (siehe Testfotos in der Entwicklungsdokumentation).
    """
    segments = _split_into_segments(full_text)
    if not segments:
        segments = [full_text.strip() or "..."]

    total_chars = sum(len(s) for s in segments) or 1
    font_size = max(34, min(64, round(video_width / 18)))  # proportional zur Breite, TikTok-typisch lesbar
    margin_v = round(video_height * 0.14)  # ca. 14% Abstand vom unteren Rand -> TikTok-Safe-Zone
    margin_lr = round(video_width * 0.06)

    header = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {video_width}\n"
        f"PlayResY: {video_height}\n"
        "ScaledBorderAndShadow: yes\n"
        "WrapStyle: 0\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
        "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
        "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Default,DejaVu Sans,{font_size},&H00FFFFFF,&H000000FF,&H00101010,&H00000000,"
        f"1,0,0,0,100,100,0,0,1,3,1,2,{margin_lr},{margin_lr},{margin_v},1\n\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )

    lines = []
    cursor = 0.0
    for seg in segments:
        share = len(seg) / total_chars
        seg_duration = max(0.8, total_duration_s * share)
        start = cursor
        end = min(total_duration_s, cursor + seg_duration)
        cursor = end
        safe_text = seg.replace("\n", " ").replace("{", "(").replace("}", ")")
        lines.append(f"Dialogue: 0,{_format_ass_time(start)},{_format_ass_time(end)},Default,,0,0,0,,{safe_text}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(header + "\n".join(lines) + "\n", encoding="utf-8")
    return out_path


def ass_subtitle_filter(ass_path: Path) -> str:
    escaped = str(ass_path).replace(":", "\\:").replace("'", "\\'")
    return f"subtitles='{escaped}'"
