"""
Haupteinstiegspunkt der App (Master-Prompt Abschnitt 20 + 46).

Startreihenfolge:
1. Logging initialisieren
2. Datenbank initialisieren (Tabellen anlegen, falls nicht vorhanden)
3. Scheduler + Watchdog als Hintergrundthreads starten
4. manueller Upload-Server (eigener Port) als Hintergrundthread starten
5. Haupt-Flask-App starten (blockierend - wird von systemd verwaltet)

Wird von systemd als Service gestartet; bei Absturz startet systemd den Prozess
automatisch neu (siehe systemd/ai-desk-robot-backend.service).
"""
from __future__ import annotations
import threading
from flask import Flask

from .config import env, BASE_DIR
from .logging_setup import logger
from . import database, scheduler
from .web.routes import bp as main_bp
from .web.upload_server import upload_app


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(BASE_DIR / "templates"),
        static_folder=str(BASE_DIR / "static"),
    )
    app.config["SECRET_KEY"] = env.secret_key
    app.register_blueprint(main_bp)

    @app.errorhandler(404)
    def not_found(e):
        return {"error": "not_found"}, 404

    @app.errorhandler(500)
    def server_error(e):
        logger.info(f"Interner Serverfehler: {e}")
        return {"error": "internal_server_error"}, 500

    return app


def _run_upload_server():
    try:
        upload_app.run(host="0.0.0.0", port=env.upload_port, threaded=True, use_reloader=False)
    except Exception as exc:
        logger.info(f"Upload-Server konnte nicht gestartet werden: {exc}")


def main():
    logger.info("AI Desk Robot startet...")
    database.init_db()
    logger.info("Datenbank bereit")

    scheduler.start()
    logger.info("Scheduler und Watchdog gestartet")

    upload_thread = threading.Thread(target=_run_upload_server, daemon=True)
    upload_thread.start()
    logger.info(f"Manueller Upload-Server gestartet auf Port {env.upload_port}")

    app = create_app()
    logger.info(f"Dashboard erreichbar auf Port {env.flask_port}")
    app.run(host=env.flask_host, port=env.flask_port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
