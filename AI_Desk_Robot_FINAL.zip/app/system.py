"""
Systemmonitoring (Master-Prompt Abschnitt 45).

Liefert Live-Werte für CPU, RAM, Disk, Temperatur, Uptime, Internetstatus,
Ollama-Status, TTS-Status, TikTok-Status - alles mit sauberem Fallback,
falls ein Wert auf einer bestimmten Plattform (z.B. Entwicklungsrechner statt Pi)
nicht auslesbar ist.
"""
from __future__ import annotations
import os
import psutil
import socket
import shutil
import time
import subprocess
from pathlib import Path
from .config import env, config, VIDEOS_DIR

_BOOT_TIME = psutil.boot_time()
psutil.cpu_percent(interval=None)  # Erster (verworfener) Kalibrierungsaufruf - siehe get_cpu_percent()


def get_cpu_percent() -> float:
    """
    Liefert die CPU-Auslastung NICHT-blockierend (interval=None: Vergleich seit
    dem letzten Aufruf statt aktivem Warten).

    WICHTIG (echter Performance-Bug, per Audit gefunden): Mit 'interval=0.2'
    blockierte dieser Aufruf jeden einzelnen /api/status-Request 200ms - bei
    einem Dashboard-Poll alle 2 Sekunden eine unnötige, spürbare Verzögerung
    auf einem Raspberry Pi. 'interval=None' ist für genau diesen Anwendungsfall
    (wiederholtes Polling) der von psutil empfohlene, nicht-blockierende Weg.
    """
    return psutil.cpu_percent(interval=None)


def get_ram() -> dict:
    vm = psutil.virtual_memory()
    return {"used_mb": round(vm.used / 1024 / 1024), "total_mb": round(vm.total / 1024 / 1024), "percent": vm.percent}


def get_disk() -> dict:
    du = shutil.disk_usage(str(VIDEOS_DIR))
    return {
        "used_gb": round(du.used / 1024 ** 3, 1),
        "total_gb": round(du.total / 1024 ** 3, 1),
        "free_gb": round(du.free / 1024 ** 3, 1),
        "percent": round(du.used / du.total * 100, 1),
    }


def get_temperature_c() -> float | None:
    """Liest die CPU-Temperatur. Funktioniert auf dem Raspberry Pi über vcgencmd
    oder /sys/class/thermal. Auf anderen Systemen ggf. nicht verfügbar -> None."""
    thermal_path = Path("/sys/class/thermal/thermal_zone0/temp")
    try:
        if thermal_path.exists():
            raw = thermal_path.read_text().strip()
            return round(int(raw) / 1000.0, 1)
    except Exception:
        pass
    try:
        out = subprocess.run(
            ["vcgencmd", "measure_temp"], capture_output=True, text=True, timeout=2
        )
        if out.returncode == 0 and "=" in out.stdout:
            val = out.stdout.split("=")[1].split("'")[0]
            return round(float(val), 1)
    except Exception:
        pass
    return None


def get_uptime_s() -> float:
    return time.time() - _BOOT_TIME


def format_uptime(seconds: float) -> str:
    days, rem = divmod(int(seconds), 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    parts.append(f"{hours}h")
    parts.append(f"{minutes}m")
    return " ".join(parts)


_internet_cache = {"value": None, "ts": 0.0}
_INTERNET_CACHE_TTL_S = 15  # verhindert, dass jeder 2-Sekunden-Dashboard-Poll erneut prüft


def check_internet(timeout: float = 1.0) -> bool:
    """Prüft Internetkonnektivität mit kurzen Timeouts und Zwischenspeicherung.

    WICHTIG (echter Performance-Bug, per Test gefunden): Ohne Caching und mit zu
    langen Timeouts würde diese Funktion bei jedem einzelnen Dashboard-Poll
    (alle 2 Sekunden!) bis zu mehrere Sekunden blockieren, wenn kein Internet
    verfügbar ist (sequenzielle Verbindungsversuche zu mehreren Hosts, die bei
    gefiltertem/blockiertem Netzwerk eher in ein Timeout laufen als in eine
    sofortige Ablehnung). Das machte das gesamte Dashboard spürbar träge.
    Ergebnis wird daher kurz zwischengespeichert und Timeouts wurden reduziert.
    """
    now = time.time()
    if _internet_cache["value"] is not None and (now - _internet_cache["ts"]) < _INTERNET_CACHE_TTL_S:
        return _internet_cache["value"]

    result = False
    for host, port in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            socket.create_connection((host, port), timeout=timeout).close()
            result = True
            break
        except Exception:
            continue

    _internet_cache["value"] = result
    _internet_cache["ts"] = now
    return result


def check_ollama() -> bool:
    import requests
    try:
        r = requests.get(f"{env.ollama_host}/api/tags", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


_piper_functional_cache = {"value": None, "ts": 0.0}
_PIPER_FUNCTIONAL_CACHE_TTL_S = 600  # 10 Minuten - ein echter Synthese-Testlauf ist teurer als ein simpler Datei-Check


def check_piper() -> bool:
    """
    Piper gilt NUR dann als 'Bereit', wenn:
    1. die konfigurierte Binary tatsächlich existiert und ausführbar ist,
    2. die konfigurierte deutsche Stimmdatei tatsächlich existiert und nicht leer ist, UND
    3. ein echter (zwischengespeicherter) Funktionstest wirklich hörbare Audioausgabe liefert.

    WICHTIG (korrigierter Bug): vorher wurde bereits ein bloß gesetzter
    PIPER_VOICE_PATH-String als 'bereit' gewertet, selbst wenn die Datei gar
    nicht existierte oder Piper nie wirklich funktionierte. Das gab ein
    irreführendes 'Bereit' im Dashboard, obwohl in Wahrheit nichts funktionierte.
    Der Funktionstest wird aus Performance-Gründen nur alle 10 Minuten wirklich
    ausgeführt (nicht bei jedem 2-Sekunden-Dashboard-Poll), das Ergebnis wird
    zwischengespeichert.
    """
    binary_path = shutil.which(env.piper_bin)
    if not binary_path or not os.access(binary_path, os.X_OK):
        return False

    voice_path = env.piper_voice_path
    if not voice_path:
        return False
    voice_file = Path(voice_path)
    if not voice_file.exists() or voice_file.stat().st_size == 0:
        return False

    now = time.time()
    if _piper_functional_cache["value"] is not None and (now - _piper_functional_cache["ts"]) < _PIPER_FUNCTIONAL_CACHE_TTL_S:
        return _piper_functional_cache["value"]

    result = False
    try:
        import tempfile
        from .providers import tts_provider
        with tempfile.TemporaryDirectory() as tmp:
            test_path = Path(tmp) / "piper_status_check.wav"
            tts_provider._run_piper("Dies ist ein Statustest.", test_path)
            result = True
    except Exception:
        result = False

    _piper_functional_cache["value"] = result
    _piper_functional_cache["ts"] = now
    return result


def check_tiktok_connected() -> bool:
    from . import database
    tokens = database.get_tiktok_tokens()
    return bool(tokens and tokens.get("access_token"))


def full_status() -> dict:
    return {
        "cpu_percent": get_cpu_percent(),
        "ram": get_ram(),
        "disk": get_disk(),
        "temperature_c": get_temperature_c(),
        "uptime_s": get_uptime_s(),
        "uptime_label": format_uptime(get_uptime_s()),
        "internet": check_internet(),
        "ollama": check_ollama(),
        "piper": check_piper(),
        "tiktok_connected": check_tiktok_connected(),
    }
