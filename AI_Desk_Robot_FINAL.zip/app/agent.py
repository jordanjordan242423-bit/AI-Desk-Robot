"""
Agent-Orchestrierung (Master-Prompt Abschnitt 8, 36, 48).

Der Agent ist eine Zustandsmaschine, die vollständig autonom einen Job von
QUEUED bis PUBLISHED/READY/FAILED durchläuft, ohne dass der Nutzer eingreifen muss.

Zusätzlich liefert der Agent den aktuellen "Face State" (für das Robotergesicht im
Frontend) sowie eine strukturierte Prozessliste (für die rechte Dashboard-Spalte).

Fehlerbehandlung: jeder Schritt ist einzeln try/except-abgesichert, Fehler werden
geloggt und der Job wird mit Retry (max. 2 Versuche) oder als FAILED markiert -
der Agent selbst hängt sich dabei niemals auf, sondern macht nach kurzer Pause weiter.
"""
from __future__ import annotations
import re
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

from . import database
from .config import config, VIDEOS_DIR, AUDIO_DIR
from .logging_setup import logger
from .topic_selector import select_topic_with_facts_and_script
from .providers import tts_provider
from . import media, subtitles, video, tiktok

PIPELINE_STEPS = [
    ("RESEARCHING", "Recherche"),
    ("SELECTING", "Thema auswählen"),
    ("FACTCHECK", "Quellen prüfen"),
    ("SCRIPTING", "Skript erstellen"),
    ("TTS", "TTS erzeugen"),
    ("MEDIA", "Bildmaterial vorbereiten"),
    ("RENDERING", "Video erstellen"),
    ("SUBTITLES", "Untertitel erzeugen"),
    ("QC", "Qualitätsprüfung"),
    ("READY", "Video bereit"),
    ("UPLOADING", "Upload"),
    ("PUBLISHED", "Veröffentlicht"),
]

_STEP_ORDER = [s[0] for s in PIPELINE_STEPS]

MAX_RETRIES = 2


@dataclass
class AgentState:
    face_state: str = "IDLE"      # siehe static/js/face.js für alle Zustände
    face_emotion: str = "neutral"
    current_job_id: Optional[str] = None
    current_step: Optional[str] = None
    message: str = "Bereit."
    is_running: bool = False
    lock: threading.Lock = field(default_factory=threading.Lock)


state = AgentState()


def try_reserve_run_slot() -> bool:
    """
    Reserviert den 'läuft-gerade'-Zustand ATOMAR (Prüfen + Setzen unter demselben
    Lock).

    WICHTIG (echte Race Condition, per Audit gefunden): Scheduler (_scheduler_loop)
    und der manuelle 'Jetzt Video erstellen'-Button (trigger_manual_run) prüften
    vorher UNABHÄNGIG voneinander 'state.is_running' und 'database.active_job()',
    bevor jeweils ein neuer Job-Thread gestartet wurde, der ERST NACH dem Start
    intern 'state.is_running = True' setzte. Lagen beide Prüfungen zeitlich nah
    genug beieinander (z.B. ein Nutzer klickt den Button genau in dem Moment, in
    dem der Scheduler ohnehin einen Lauf startet), konnten beide Aufrufer die
    Prüfung 'läuft nichts' gleichzeitig als wahr sehen und JEWEILS einen Job-Thread
    starten - zwei parallele FFmpeg-/TTS-Prozesse auf einem Raspberry Pi mit
    begrenzten Ressourcen. Diese Funktion schließt die Lücke: Prüfen und Reservieren
    passiert als eine einzige atomare Operation unter 'state.lock'.

    Rückgabe: True, wenn der Slot erfolgreich reserviert wurde (Aufrufer darf jetzt
    einen Job-Thread starten); False, wenn bereits ein Job läuft.
    """
    with state.lock:
        if state.is_running:
            return False
        state.is_running = True
        return True


def get_process_list(job: Optional[dict]) -> list[dict]:
    """Baut die Häkchen-Liste für die rechte Dashboard-Spalte (Abschnitt 7)."""
    if not job:
        return [{"key": k, "label": label, "status": "pending"} for k, label in PIPELINE_STEPS]

    current_status = job.get("status", "QUEUED")
    try:
        current_idx = _STEP_ORDER.index(current_status)
    except ValueError:
        current_idx = -1

    result = []
    for i, (key, label) in enumerate(PIPELINE_STEPS):
        if current_status == "FAILED":
            step_status = "failed" if i == max(current_idx, 0) else ("done" if i < current_idx else "pending")
        elif i < current_idx:
            step_status = "done"
        elif i == current_idx:
            step_status = "active"
        else:
            step_status = "pending"
        result.append({"key": key, "label": label, "status": step_status})
    return result


def _set_face(face_state: str, emotion: str = "neutral", message: str = ""):
    with state.lock:
        state.face_state = face_state
        state.face_emotion = emotion
        if message:
            state.message = message


def _slugify(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9\s-]", "", text).strip().lower()
    return re.sub(r"[\s]+", "-", text)[:40] or "video"


def run_single_job() -> None:
    """Führt genau einen kompletten Video-Job aus. Wird vom Scheduler periodisch aufgerufen."""
    job_id = f"JOB-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:4]}"
    work_dir = VIDEOS_DIR / job_id
    work_dir.mkdir(parents=True, exist_ok=True)

    with state.lock:
        state.is_running = True
        state.current_job_id = job_id

    try:
        # 1. RESEARCH + SELECT + FACTCHECK + SCRIPT -----------------------------
        # Diese vier Schritte werden gemeinsam über select_topic_with_facts_and_script()
        # abgewickelt: Kandidaten ohne vertrauenswürdige Fakten oder mit einem
        # qualitativ unzureichenden Skript werden dabei verworfen und der nächste
        # Kandidat wird versucht - es wird NIEMALS mit generischen Skripten/Fakten
        # weitergemacht (siehe app.topic_selector, app.fact_checker, app.script_generator).
        database.create_job(job_id, category="")
        database.update_job(job_id, status="RESEARCHING")
        _set_face("RESEARCH", "focused", "Recherche läuft...")
        logger.info(f"[{job_id}] Recherche gestartet")

        database.update_job(job_id, status="SELECTING")
        _set_face("THINKING", "focused", "Themen werden geprüft...")
        candidate, fact_base, script = select_topic_with_facts_and_script()
        if candidate is None:
            database.update_job(
                job_id, status="FAILED",
                error="Kein Thema mit vertrauenswürdigen Fakten und ausreichender Skriptqualität gefunden",
            )
            database.log_event(
                "ERROR",
                "Kein geeignetes Thema gefunden (alle Kandidaten hatten unzureichende Fakten oder Skriptqualität)",
                job_id,
            )
            logger.info(f"[{job_id}] Kein geeignetes Thema gefunden, Job übersprungen")
            return

        database.update_job(job_id, topic=candidate.title, category=candidate.category)
        logger.info(f"[{job_id}] Thema ausgewählt: {candidate.title}")

        database.update_job(job_id, status="FACTCHECK", sources=fact_base.source_name)
        logger.info(f"[{job_id}] Quellen geprüft ({fact_base.source_name})")

        database.update_job(
            job_id, status="SCRIPTING", script=script.full_text, title=script.title,
            description=script.description, hashtags=",".join(script.hashtags),
            duration_s=script.estimated_duration_s,
        )
        logger.info(f"[{job_id}] Skript erstellt ({script.estimated_duration_s:.0f}s geschätzt, Quelle: {script.llm_source})")

        # 2. TTS ------------------------------------------------------------------
        database.update_job(job_id, status="TTS")
        _set_face("TTS", "neutral", "Stimme wird erzeugt...")
        audio_path = AUDIO_DIR / f"{job_id}.wav"
        # tts_provider.synthesize() wirft eine TTSError, wenn WEDER Piper NOCH espeak-ng
        # eine echte, hörbare Ausgabe erzeugen können - es gibt keinen stillen
        # Notfall-Erfolg mehr. Die Exception läuft bewusst bis zum äußeren
        # except-Block durch, der den Job korrekt als FAILED markiert.
        audio_path, tts_engine = tts_provider.synthesize(script.full_text, audio_path, estimated_duration_s=script.estimated_duration_s)
        real_duration = tts_provider.get_wav_duration_s(audio_path) or script.estimated_duration_s
        database.update_job(job_id, tts_file=str(audio_path), duration_s=real_duration)
        logger.info(f"[{job_id}] TTS erstellt (Engine: {tts_engine}, Dauer: {real_duration:.1f}s)")

        # 5. MEDIA ------------------------------------------------------------------
        database.update_job(job_id, status="MEDIA")
        _set_face("VIDEO", "focused", "Bildmaterial wird vorbereitet...")
        bg_path, media_source = media.get_background_video(candidate.title, real_duration, work_dir)
        logger.info(f"[{job_id}] Hintergrundmaterial: {media_source}")

        # 6. SUBTITLES ---------------------------------------------------------------
        database.update_job(job_id, status="SUBTITLES")
        ass_path = work_dir / "subtitles.ass"
        subtitles.generate_ass(script.full_text, real_duration, ass_path)
        # Zusätzlich eine .srt als lesbares Referenzformat ablegen (z.B. für externe Tools/Archiv)
        srt_path = work_dir / "subtitles.srt"
        subtitles.generate_srt(script.full_text, real_duration, srt_path)
        database.update_job(job_id, subtitle_file=str(ass_path))
        logger.info(f"[{job_id}] Untertitel erzeugt")

        # 7. RENDER --------------------------------------------------------------------
        database.update_job(job_id, status="RENDERING")
        _set_face("VIDEO", "focused", "Video wird gerendert...")
        final_path = work_dir / f"{_slugify(candidate.title)}.mp4"
        video.build_video(bg_path, audio_path, ass_path, final_path, real_duration)
        database.update_job(job_id, video_file=str(final_path))
        logger.info(f"[{job_id}] Video gerendert")

        # 8. QC ----------------------------------------------------------------------------
        database.update_job(job_id, status="QC")
        qc = video.quality_check(final_path)
        database.update_job(job_id, filesize_bytes=qc.filesize_bytes, duration_s=qc.duration_s)
        if not qc.passed:
            database.update_job(job_id, status="FAILED", error="; ".join(qc.reasons), retry_count=1)
            database.log_event("ERROR", f"Qualitätsprüfung fehlgeschlagen: {'; '.join(qc.reasons)}", job_id)
            _set_face("ERROR", "concerned", "Qualitätsprüfung fehlgeschlagen.")
            logger.info(f"[{job_id}] Qualitätsprüfung FEHLGESCHLAGEN: {qc.reasons}")
            return
        logger.info(f"[{job_id}] Qualitätsprüfung OK ({qc.duration_s:.1f}s, {qc.width}x{qc.height})")

        database.add_used_topic(candidate.title, candidate.category)

        # 9. READY -----------------------------------------------------------------------
        database.update_job(job_id, status="READY")
        _set_face("SUCCESS", "happy", "Video bereit.")
        logger.info(f"[{job_id}] Video bereit")

        # 10. UPLOAD (nur wenn offiziell verbunden) ---------------------------------------
        if tiktok.is_connected():
            database.update_job(job_id, status="UPLOADING")
            _set_face("UPLOAD", "focused", "Video wird hochgeladen...")
            try:
                result = tiktok.upload_video(final_path, script.title, f"{script.description} " + " ".join(script.hashtags))
                database.update_job(
                    job_id, status="PUBLISHED", published_at=datetime.utcnow().isoformat(),
                    tiktok_video_id=result.get("publish_id", ""),
                )
                logger.info(f"[{job_id}] Erfolgreich an TikTok übertragen")
                _set_face("SUCCESS", "happy", "Video veröffentlicht.")
            except Exception as exc:
                database.update_job(job_id, status="READY", error=f"Upload fehlgeschlagen: {exc}")
                database.log_event("ERROR", f"TikTok-Upload fehlgeschlagen: {exc}", job_id)
                logger.info(f"[{job_id}] TikTok-Upload fehlgeschlagen, Video bleibt READY für manuellen Upload: {exc}")
        else:
            logger.info(f"[{job_id}] TikTok nicht verbunden - Video steht für manuellen Upload bereit")

    except Exception as exc:
        logger.info(f"[{job_id}] Unerwarteter Fehler in der Pipeline: {exc}")
        database.log_event("ERROR", f"Unerwarteter Pipeline-Fehler: {exc}", job_id)
        try:
            database.update_job(job_id, status="FAILED", error=str(exc))
        except Exception:
            pass
        _set_face("ERROR", "concerned", "Ein Fehler ist aufgetreten.")
    finally:
        with state.lock:
            state.is_running = False
            state.current_job_id = None
        time.sleep(1)
        _set_face("IDLE", "neutral", "Bereit.")


def get_agent_snapshot() -> dict:
    job = database.get_job(state.current_job_id) if state.current_job_id else database.active_job()
    with state.lock:
        snapshot = {
            "face_state": state.face_state,
            "face_emotion": state.face_emotion,
            "message": state.message,
            "is_running": state.is_running,
        }
    snapshot["job"] = job
    snapshot["process"] = get_process_list(job)
    return snapshot
