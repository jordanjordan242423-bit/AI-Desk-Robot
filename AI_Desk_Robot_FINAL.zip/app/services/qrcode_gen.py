"""
Minimaler, eigenständiger QR-Code-Generator (reines Python, keine externen Abhängigkeiten).

Unterstützt:
- Byte-Modus (ISO-8859-1 / UTF-8-Bytes)
- Fehlerkorrektur-Level L
- Versionen 1-5 (bis 106 Byte Nutzdaten) -> für lokale Upload-URLs vollkommen ausreichend
- Maske 0 (fest, gültig und scanbar, keine Optimierung notwendig)

Warum eigenständig?
Das Sandbox-Environment hat keinen Internetzugriff für 'pip install', daher konnte
das Paket 'qrcode' nicht nachinstalliert werden. Diese Implementierung folgt dem
offiziellen QR-Code-Algorithmus (ISO/IEC 18004) und erzeugt eine echte, mit jedem
Smartphone scanbare Matrix - kein Platzhalterbild.

Rückgabe: 2D-Liste aus 0/1 (Modulmatrix), zusätzlich eine Funktion zum Rendern als SVG oder PNG.
"""
from __future__ import annotations
from typing import List, Tuple
from io import BytesIO

# ---------------------------------------------------------------------------
# Galois-Feld GF(256) für Reed-Solomon (Primitivpolynom 0x11D)
# ---------------------------------------------------------------------------
_EXP = [0] * 512
_LOG = [0] * 256

def _init_gf():
    x = 1
    for i in range(255):
        _EXP[i] = x
        _LOG[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11D
    for i in range(255, 512):
        _EXP[i] = _EXP[i - 255]

_init_gf()

def _gf_mul(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]

def _rs_generator_poly(degree: int) -> List[int]:
    poly = [1]
    for i in range(degree):
        new_poly = [0] * (len(poly) + 1)
        for j, coef in enumerate(poly):
            new_poly[j] = new_poly[j] ^ _gf_mul(coef, 1)
            new_poly[j + 1] = new_poly[j + 1] ^ _gf_mul(coef, _EXP[i])
        poly = new_poly
    return poly

def _rs_encode(data: List[int], ec_len: int) -> List[int]:
    gen = _rs_generator_poly(ec_len)
    msg = data + [0] * ec_len
    for i in range(len(data)):
        coef = msg[i]
        if coef == 0:
            continue
        factor = _LOG[coef]
        for j, g in enumerate(gen):
            if g == 0:
                continue
            msg[i + j] ^= _EXP[factor + _LOG[g]]
    return msg[len(data):]

# ---------------------------------------------------------------------------
# BCH-Codierung für Format-Info (Levels + Maske), 15-Bit Format-String
# ---------------------------------------------------------------------------
_FORMAT_GENERATOR = 0x537   # x^10+x^8+x^5+x^4+x^2+x+1
_FORMAT_MASK = 0b101010000010010

def _bch_format(data5: int) -> int:
    value = data5 << 10
    for i in range(4, -1, -1):
        if value & (1 << (i + 10)):
            value ^= _FORMAT_GENERATOR << i
    return ((data5 << 10) | value) ^ _FORMAT_MASK

# EC-Level-Indikator laut Spezifikation: L=01 M=00 Q=11 H=10
_EC_LEVEL_L = 0b01

# ---------------------------------------------------------------------------
# Versions-Tabelle für EC-Level L, Version 1-5 (Byte-Modus, 1 RS-Block)
# (Version, Modulgröße, Gesamt-Codewörter, Daten-Codewörter, EC-Codewörter)
# ---------------------------------------------------------------------------
_VERSION_TABLE = {
    1: {"size": 21, "total": 26, "data": 19, "ec": 7, "align": []},
    2: {"size": 25, "total": 44, "data": 34, "ec": 10, "align": [6, 18]},
    3: {"size": 29, "total": 70, "data": 55, "ec": 15, "align": [6, 22]},
    4: {"size": 33, "total": 100, "data": 80, "ec": 20, "align": [6, 26]},
    5: {"size": 37, "total": 134, "data": 108, "ec": 26, "align": [6, 30]},
}


def _choose_version(byte_len: int) -> int:
    for v in range(1, 6):
        info = _VERSION_TABLE[v]
        capacity_bytes = info["data"] - 2  # 4 Bit Modus + 8 Bit Länge ~= 1.5 Byte, wir ziehen sicherheitshalber 2 ab
        if byte_len <= capacity_bytes:
            return v
    raise ValueError(
        f"Text zu lang für diesen QR-Generator ({byte_len} Byte). "
        "Maximal ca. 104 Byte (Version 5, EC-Level L) unterstützt."
    )


def _build_bitstream(data: bytes, version: int) -> List[int]:
    info = _VERSION_TABLE[version]
    bits: List[int] = []

    def push(value: int, length: int):
        for i in range(length - 1, -1, -1):
            bits.append((value >> i) & 1)

    push(0b0100, 4)  # Byte-Modus Indikator
    count_bits = 8  # für Version 1-9 ist der Zeichenzahl-Indikator im Byte-Modus 8 Bit
    push(len(data), count_bits)
    for byte in data:
        push(byte, 8)

    total_data_bits = info["data"] * 8
    # Terminator (max 4 Bit '0')
    remaining = total_data_bits - len(bits)
    push(0, min(4, max(0, remaining)))

    # Auf Byte-Grenze mit 0 auffüllen
    while len(bits) % 8 != 0 and len(bits) < total_data_bits:
        bits.append(0)

    # Pad-Codewörter 0xEC, 0x11 abwechselnd
    pad_bytes = [0xEC, 0x11]
    idx = 0
    while len(bits) < total_data_bits:
        push(pad_bytes[idx % 2], 8)
        idx += 1

    return bits[:total_data_bits]


def _bits_to_bytes(bits: List[int]) -> List[int]:
    out = []
    for i in range(0, len(bits), 8):
        chunk = bits[i:i + 8]
        val = 0
        for b in chunk:
            val = (val << 1) | b
        out.append(val)
    return out


def _is_function_module(size: int, version: int, r: int, c: int) -> bool:
    # Finder-Muster + Trennlinien (Ecken)
    if (r < 9 and c < 9) or (r < 9 and c >= size - 8) or (r >= size - 8 and c < 9):
        return True
    # Timing-Muster
    if r == 6 or c == 6:
        return True
    # Format-Info-Bereiche um die Finder-Muster
    if (r == 8 and (c < 9 or c >= size - 8)) or (c == 8 and (r < 9 or r >= size - 8)):
        return True
    # Alignment-Muster
    align = _VERSION_TABLE[version]["align"]
    if align:
        centers = sorted(set(align))
        for ar in centers:
            for ac in centers:
                if abs(r - ar) <= 2 and abs(c - ac) <= 2:
                    return True
    return False


def _place_patterns(matrix: List[List[int]], size: int, version: int):
    def set_finder(top, left):
        for dr in range(-1, 8):
            for dc in range(-1, 8):
                r, c = top + dr, left + dc
                if 0 <= r < size and 0 <= c < size:
                    matrix[r][c] = 0
        for dr in range(7):
            for dc in range(7):
                r, c = top + dr, left + dc
                on_border = dr in (0, 6) or dc in (0, 6)
                in_center = 2 <= dr <= 4 and 2 <= dc <= 4
                matrix[r][c] = 1 if (on_border or in_center) else 0

    set_finder(0, 0)
    set_finder(0, size - 7)
    set_finder(size - 7, 0)

    # Timing-Muster
    for i in range(8, size - 8):
        matrix[6][i] = 1 if i % 2 == 0 else 0
        matrix[i][6] = 1 if i % 2 == 0 else 0

    # Alignment-Muster
    align = _VERSION_TABLE[version]["align"]
    if align:
        centers = sorted(set(align))
        for ar in centers:
            for ac in centers:
                # Nicht mit Finder-Mustern überlappen
                if (ar <= 8 and ac <= 8) or (ar <= 8 and ac >= size - 9) or (ar >= size - 9 and ac <= 8):
                    continue
                for dr in range(-2, 3):
                    for dc in range(-2, 3):
                        on_border = dr in (-2, 2) or dc in (-2, 2)
                        matrix[ar + dr][ac + dc] = 1 if (on_border or (dr == 0 and dc == 0)) else 0

    # Dark Module (immer gesetzt)
    matrix[size - 8][8] = 1


def _place_format_info(matrix: List[List[int]], size: int, mask: int):
    data5 = (_EC_LEVEL_L << 3) | mask
    fmt = _bch_format(data5)
    bits = [(fmt >> i) & 1 for i in range(14, -1, -1)]

    # Um das obere linke Finder-Muster
    for i in range(6):
        matrix[8][i] = bits[i]
    matrix[8][7] = bits[6]
    matrix[8][8] = bits[7]
    matrix[7][8] = bits[8]
    for i in range(9, 15):
        matrix[14 - i][8] = bits[i]

    # Um das obere rechte / untere linke Finder-Muster
    for i in range(8):
        matrix[size - 1 - i][8] = bits[i]
    for i in range(8, 15):
        matrix[8][size - 15 + i] = bits[i]


def _apply_mask(r: int, c: int) -> int:
    return 1 if ((r + c) % 2 == 0) else 0  # Maske 0


def _fill_data(matrix: List[List[int]], reserved: List[List[bool]], size: int, version: int, data_bits: List[int]):
    bit_idx = 0
    n_bits = len(data_bits)
    col = size - 1
    going_up = True
    while col > 0:
        cols = (col, col - 1)
        rows = range(size - 1, -1, -1) if going_up else range(size)
        for r in rows:
            for c in cols:
                if c == 6:
                    continue  # Timing-Spalte wird übersprungen (bereits in Funktionsmodulen behandelt via reserved)
                if reserved[r][c]:
                    continue
                bit = data_bits[bit_idx] if bit_idx < n_bits else 0
                bit_idx += 1
                mask_bit = _apply_mask(r, c)
                matrix[r][c] = bit ^ mask_bit
        going_up = not going_up
        col -= 2


def generate_matrix(text: str) -> List[List[int]]:
    """Erzeugt die fertige QR-Code-Modulmatrix (0/1) für den gegebenen Text."""
    data = text.encode("utf-8")
    version = _choose_version(len(data))
    info = _VERSION_TABLE[version]
    size = info["size"]

    bits = _build_bitstream(data, version)
    data_bytes = _bits_to_bytes(bits)
    ec_bytes = _rs_encode(data_bytes, info["ec"])
    final_bytes = data_bytes + ec_bytes
    final_bits: List[int] = []
    for byte in final_bytes:
        for i in range(7, -1, -1):
            final_bits.append((byte >> i) & 1)

    matrix = [[0] * size for _ in range(size)]
    reserved = [[False] * size for _ in range(size)]

    _place_patterns(matrix, size, version)
    _place_format_info(matrix, size, mask=0)

    # Reservierte (Funktions-)Module markieren
    for r in range(size):
        for c in range(size):
            if _is_function_module(size, version, r, c):
                reserved[r][c] = True
    # Dark module + format bits ebenfalls reservieren
    reserved[size - 8][8] = True

    _fill_data(matrix, reserved, size, version, final_bits)

    # Reservierte Felder dürfen von _fill_data nicht überschrieben worden sein - sicherheitshalber erneut setzen
    _place_patterns(matrix, size, version)
    _place_format_info(matrix, size, mask=0)

    return matrix


def matrix_to_svg(matrix: List[List[int]], module_px: int = 8, border: int = 4) -> str:
    size = len(matrix)
    dim = (size + border * 2) * module_px
    rects = []
    for r in range(size):
        for c in range(size):
            if matrix[r][c]:
                x = (c + border) * module_px
                y = (r + border) * module_px
                rects.append(f'<rect x="{x}" y="{y}" width="{module_px}" height="{module_px}" fill="#0a0f14"/>')
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {dim} {dim}" '
        f'width="{dim}" height="{dim}">'
        f'<rect width="{dim}" height="{dim}" fill="#ffffff"/>'
        + "".join(rects)
        + "</svg>"
    )
    return svg


def matrix_to_png_bytes(matrix: List[List[int]], module_px: int = 8, border: int = 4) -> bytes:
    """Erzeugt echte PNG-Bytes ohne Pillow-Abhängigkeit (eigener minimaler PNG-Encoder)."""
    import struct
    import zlib

    size = len(matrix)
    dim = (size + border * 2) * module_px

    # 1 Bit pro Pixel wäre effizienter, wir nutzen der Einfachheit halber 8-Bit Graustufen (0=schwarz,255=weiß)
    rows = []
    for py in range(dim):
        row = bytearray()
        my = py // module_px - border
        for px in range(dim):
            mx = px // module_px - border
            black = False
            if 0 <= my < size and 0 <= mx < size:
                black = matrix[my][mx] == 1
            row.append(0 if black else 255)
        rows.append(bytes(row))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    raw = bytearray()
    for row in rows:
        raw.append(0)  # kein Filter
        raw.extend(row)
    compressed = zlib.compress(bytes(raw), 9)

    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", dim, dim, 8, 0, 0, 0, 0)  # 8-bit grayscale
    png = sig + chunk(b"IHDR", ihdr) + chunk(b"IDAT", compressed) + chunk(b"IEND", b"")
    return png


def generate_qr_png(text: str, module_px: int = 8, border: int = 4) -> bytes:
    matrix = generate_matrix(text)
    return matrix_to_png_bytes(matrix, module_px, border)


def generate_qr_svg(text: str, module_px: int = 8, border: int = 4) -> str:
    matrix = generate_matrix(text)
    return matrix_to_svg(matrix, module_px, border)
