#!/usr/bin/env bash
# ==============================================================================
# launcher.sh - startet Chromium im Kiosk-Modus für das AI Desk Robot Dashboard.
#
# Wird von systemd (ai-desk-robot-kiosk.service) beim grafischen Login gestartet.
# Wartet, bis das Backend erreichbar ist (kann nach einem Neustart einige
# Sekunden dauern), und startet Chromium danach im Vollbild-Kiosk-Modus.
# Stürzt Chromium ab, wird es automatisch neu gestartet (Abschnitt 20).
# ==============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# .env laden, um FLASK_PORT zu kennen (Standard 8080)
if [ -f "$SCRIPT_DIR/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  source "$SCRIPT_DIR/.env"
  set +a
fi
PORT="${FLASK_PORT:-8080}"
URL="http://127.0.0.1:${PORT}/"

echo "[launcher] Warte auf Backend unter $URL ..."
for i in $(seq 1 60); do
  if curl -fs "$URL" > /dev/null 2>&1; then
    echo "[launcher] Backend ist erreichbar."
    break
  fi
  sleep 2
done

# Chromium-Binary ermitteln (heißt je nach Raspberry Pi OS Version unterschiedlich)
CHROMIUM_BIN=""
for candidate in chromium-browser chromium chromium-browser-stable; do
  if command -v "$candidate" > /dev/null 2>&1; then
    CHROMIUM_BIN="$candidate"
    break
  fi
done

if [ -z "$CHROMIUM_BIN" ]; then
  echo "[launcher] FEHLER: Kein Chromium gefunden. Bitte 'chromium-browser' installieren."
  echo "[launcher] Das Backend läuft trotzdem weiter und ist unter $URL erreichbar."
  # Endlosschleife, damit systemd den Dienst nicht als 'failed' markiert und wild neu startet
  while true; do sleep 3600; done
fi

# Bildschirmschoner/Energiesparen deaktivieren, falls vorhanden (kein Hard-Fail wenn fehlend)
xset s off 2>/dev/null || true
xset s noblank 2>/dev/null || true
xset -dpms 2>/dev/null || true
unclutter -idle 0.5 -root &>/dev/null &

echo "[launcher] Starte Chromium im Kiosk-Modus ($CHROMIUM_BIN) ..."
while true; do
  "$CHROMIUM_BIN" \
    --kiosk \
    --noerrdialogs \
    --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-translate \
    --no-first-run \
    --start-fullscreen \
    --overscroll-history-navigation=0 \
    --autoplay-policy=no-user-gesture-required \
    --check-for-update-interval=31536000 \
    --touch-events=enabled \
    --window-position=0,0 \
    "$URL" >> "$SCRIPT_DIR/data/logs/kiosk-chromium.log" 2>&1

  echo "[launcher] Chromium wurde beendet/ist abgestürzt - Neustart in 3 Sekunden..."
  sleep 3
done
